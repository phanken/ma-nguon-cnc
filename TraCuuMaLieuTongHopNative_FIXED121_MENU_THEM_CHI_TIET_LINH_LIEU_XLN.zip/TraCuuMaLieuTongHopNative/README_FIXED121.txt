FIXED121
- Menu chuột phải thêm lại:
  + Chi tiết lĩnh liệu
  + Chi tiết chuyển XLN
- Vẫn giữ:
  + Chi Tiết Công Đơn
  + Sao Chép Tóm Tắt Công Đơn
  + In công đơn SFT
  + Cấu hình SFT...
- Giữ Tổng KG chuyển XLN trong Chi Tiết Công Đơn của FIXED120.
- Dashboard vẫn bỏ.
- Không build lại SftPdfViewer.exe.
