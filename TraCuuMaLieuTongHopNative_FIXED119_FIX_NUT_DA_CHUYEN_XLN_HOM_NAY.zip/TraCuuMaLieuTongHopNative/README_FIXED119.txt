FIXED119
- Sửa lỗi nút "Đã Chuyển XLN hôm nay" sau khi bỏ Dashboard.
- Nút giờ nằm đúng bên phải tiêu đề "TRA CỨU MÃ LIỆU TỔNG HỢP" như trước.
- Không còn mảng xanh/nút bị dính ở góc trái.
- Dashboard vẫn được loại bỏ hoàn toàn.
- Giữ toàn bộ chức năng FIXED118/FIXED117.
- Không build lại SftPdfViewer.exe.
