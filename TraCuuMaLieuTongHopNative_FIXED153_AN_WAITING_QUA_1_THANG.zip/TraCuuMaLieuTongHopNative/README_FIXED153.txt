FIXED153
- Giữ nguyên FIXED152.
- Trong danh sách công đơn cùng mã liệu: công đơn WAITING có lịch xuất cũ hơn 1 tháng tính từ ngày hiện tại sẽ không hiển thị.
- Công đơn WAITING không có lịch xuất hợp lệ vẫn được giữ lại.
- Logic cảnh báo công đơn WAITING có lịch xuất gần hơn cũng bỏ qua các đơn đã quá mốc 1 tháng.
- Không rebuild SftPdfViewer.exe.
