using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

public sealed class GitHubSyncSettings
{
    public string Owner { get; set; } = "kendevill";
    public string Repo { get; set; } = "chamcong-data";
    public string Branch { get; set; } = "main";
    public string Path { get; set; } = "data.json";
    public string Token { get; set; } = "";
    public bool Enabled { get; set; }
}

public static class GitHubSync
{
    static readonly HttpClient Http = new HttpClient();
    static string Api(GitHubSyncSettings s) => $"https://api.github.com/repos/{s.Owner}/{s.Repo}/contents/{s.Path}";
    static void Headers(HttpRequestMessage req, GitHubSyncSettings s)
    {
        req.Headers.UserAgent.ParseAdd("ChamCongTinhLuong/5.0");
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.github+json"));
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", s.Token);
        req.Headers.Add("X-GitHub-Api-Version", "2022-11-28");
    }
    public static async Task DownloadAsync(GitHubSyncSettings s, string localPath)
    {
        using var req=new HttpRequestMessage(HttpMethod.Get, Api(s)+"?ref="+Uri.EscapeDataString(s.Branch)); Headers(req,s);
        using var res=await Http.SendAsync(req).ConfigureAwait(false); res.EnsureSuccessStatusCode();
        using var doc=JsonDocument.Parse(await res.Content.ReadAsStringAsync().ConfigureAwait(false));
        var b64=doc.RootElement.GetProperty("content").GetString()!.Replace("\n","");
        File.WriteAllBytes(localPath,Convert.FromBase64String(b64));
    }
    public static async Task UploadAsync(GitHubSyncSettings s, string localPath)
    {
        string? sha=null;
        using(var get=new HttpRequestMessage(HttpMethod.Get,Api(s)+"?ref="+Uri.EscapeDataString(s.Branch))) { Headers(get,s); using var r=await Http.SendAsync(get).ConfigureAwait(false); if(r.IsSuccessStatusCode){using var d=JsonDocument.Parse(await r.Content.ReadAsStringAsync().ConfigureAwait(false)); sha=d.RootElement.GetProperty("sha").GetString();}}
        var payload=new { message="Update attendance data", content=Convert.ToBase64String(File.ReadAllBytes(localPath)), branch=s.Branch, sha=sha };
        using var put=new HttpRequestMessage(HttpMethod.Put,Api(s)); Headers(put,s); put.Content=new StringContent(JsonSerializer.Serialize(payload),Encoding.UTF8,"application/json");
        using var res=await Http.SendAsync(put).ConfigureAwait(false); res.EnsureSuccessStatusCode();
    }

    public static async Task<string> DownloadTextAsync(GitHubSyncSettings s)
    {
        using var req=new HttpRequestMessage(HttpMethod.Get, Api(s)+"?ref="+Uri.EscapeDataString(s.Branch)); Headers(req,s);
        using var res=await Http.SendAsync(req).ConfigureAwait(false); res.EnsureSuccessStatusCode();
        using var doc=JsonDocument.Parse(await res.Content.ReadAsStringAsync().ConfigureAwait(false));
        var b64=doc.RootElement.GetProperty("content").GetString()!.Replace("\n","");
        return Encoding.UTF8.GetString(Convert.FromBase64String(b64));
    }
    public static async Task UploadTextAsync(GitHubSyncSettings s, string json)
    {
        string? sha=null;
        using(var get=new HttpRequestMessage(HttpMethod.Get,Api(s)+"?ref="+Uri.EscapeDataString(s.Branch)))
        { Headers(get,s); using var r=await Http.SendAsync(get).ConfigureAwait(false); if(r.IsSuccessStatusCode){using var d=JsonDocument.Parse(await r.Content.ReadAsStringAsync().ConfigureAwait(false)); sha=d.RootElement.GetProperty("sha").GetString();} }
        var payload=new { message="Update attendance data", content=Convert.ToBase64String(Encoding.UTF8.GetBytes(json)), branch=s.Branch, sha=sha };
        using var put=new HttpRequestMessage(HttpMethod.Put,Api(s)); Headers(put,s); put.Content=new StringContent(JsonSerializer.Serialize(payload),Encoding.UTF8,"application/json");
        using var res=await Http.SendAsync(put).ConfigureAwait(false); res.EnsureSuccessStatusCode();
    }
}
