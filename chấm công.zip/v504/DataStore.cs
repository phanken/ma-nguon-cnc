using System;
using System.IO;
using System.Collections.Generic;
using System.Text.Json;
namespace ChamCongTinhLuong;
public sealed class DataStore
{
    readonly string _folder=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"ChamCongTinhLuong");
    public string FilePath=>"GitHub: kendevill/chamcong-data/data.json";
    public string GitHubSettingsPath=>Path.Combine(_folder,"github_sync.json");
    readonly JsonSerializerOptions _json=new(){WriteIndented=true};
    public AppData Load()=>LoadAsync().GetAwaiter().GetResult();
    public async System.Threading.Tasks.Task<AppData> LoadAsync()
    {
        var c=LoadGitHubSettings();
        if(string.IsNullOrWhiteSpace(c.Token)) throw new InvalidOperationException("Chưa cấu hình GitHub token. Vào Cài đặt → Đồng bộ GitHub.");
        try
        {
            var json=await GitHubSync.DownloadTextAsync(c);
            var d=JsonSerializer.Deserialize<AppData>(json,_json)??NewData();
            Normalize(d);
            return d;
        }
        catch(Exception ex)
        {
            throw new InvalidOperationException("Không tải được dữ liệu từ GitHub. App không dùng data.json local để tránh lệch dữ liệu.\n\n"+ex.Message,ex);
        }
    }
    public void Save(AppData d)=>SaveAsync(d).GetAwaiter().GetResult();
    public async System.Threading.Tasks.Task SaveAsync(AppData d)
    {
        var c=LoadGitHubSettings();
        if(string.IsNullOrWhiteSpace(c.Token)) throw new InvalidOperationException("Chưa cấu hình GitHub token.");
        var json=JsonSerializer.Serialize(d,_json);
        await GitHubSync.UploadTextAsync(c,json).ConfigureAwait(false);
    }
    public string ExportJson(AppData d)=>JsonSerializer.Serialize(d,_json);
    public AppData ImportJson(string j){var d=JsonSerializer.Deserialize<AppData>(j,_json)??NewData();Normalize(d);return d;}
    static void Normalize(AppData d){if(d.Employees.Count==0)d.Employees.Add(new Employee());d.Settings??=new AppSettings();d.LeaveAccruals??=new List<LeaveAccrualRecord>();foreach(var r in d.Attendance)if(r.Type==AttendanceType.OvertimeOnly&&!string.IsNullOrWhiteSpace(r.Note)&&r.Note.StartsWith("Nghỉ lễ",StringComparison.OrdinalIgnoreCase)){r.Type=AttendanceType.Holiday;r.OvertimeHours=0;if(r.PaidDayUnits<=0)r.PaidDayUnits=1;}}
    static AppData NewData()=>new(){Employees={new Employee()}};
    public GitHubSyncSettings LoadGitHubSettings(){Directory.CreateDirectory(_folder);try{var s=File.Exists(GitHubSettingsPath)?JsonSerializer.Deserialize<GitHubSyncSettings>(File.ReadAllText(GitHubSettingsPath)):null;s??=new();if(string.IsNullOrWhiteSpace(s.Owner))s.Owner="kendevill";if(string.IsNullOrWhiteSpace(s.Repo))s.Repo="chamcong-data";if(string.IsNullOrWhiteSpace(s.Branch))s.Branch="main";if(string.IsNullOrWhiteSpace(s.Path))s.Path="data.json";s.Enabled=true;return s;}catch{return new(){Owner="kendevill",Repo="chamcong-data",Branch="main",Path="data.json",Enabled=true};}}
    public void SaveGitHubSettings(GitHubSyncSettings s){Directory.CreateDirectory(_folder);s.Enabled=true;File.WriteAllText(GitHubSettingsPath,JsonSerializer.Serialize(s,new JsonSerializerOptions{WriteIndented=true}));}
    public async System.Threading.Tasks.Task<bool> PullGitHubAsync(){var s=LoadGitHubSettings();if(string.IsNullOrWhiteSpace(s.Token))return false;await GitHubSync.DownloadTextAsync(s);return true;}
    public async System.Threading.Tasks.Task PushGitHubAsync(){return;}
}
