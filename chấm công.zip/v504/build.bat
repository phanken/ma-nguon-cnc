@echo off
setlocal
cd /d "%~dp0"
where dotnet >nul 2>nul || (echo CAN CAI .NET 8 SDK & pause & exit /b 1)
dotnet restore || goto :err
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true || goto :err
echo.
echo BUILD THANH CONG
echo EXE: bin\Release\net8.0-windows\win-x64\publish\ChamCongTinhLuong.exe
pause
exit /b 0
:err
echo.
echo BUILD THAT BAI
pause
exit /b 1
