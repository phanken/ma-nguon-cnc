@echo off
setlocal EnableExtensions
title Reset Chrome Profile Number - Keep Default

echo ==============================================
echo RESET CHROME PROFILE NUMBER
echo KEEP DEFAULT
echo ==============================================
echo.
echo Based on your Local State:
echo   profiles_created = 21
echo   metrics.next_bucket_index = 33
echo.
echo This resets profiles_created to 1.
echo It keeps the Default profile and its data.
echo.
pause

taskkill /F /IM chrome.exe >nul 2>&1
timeout /t 2 /nobreak >nul

set "UD=%LOCALAPPDATA%\Google\Chrome\User Data"
set "LS=%UD%\Local State"
set "BAK=%UD%\Local State.before_number_reset.bak"
set "PS1=%TEMP%\chrome_number_reset_%RANDOM%.ps1"

if not exist "%UD%\Default" (
  echo ERROR: Default folder not found.
  pause
  exit /b 1
)

if not exist "%LS%" (
  echo ERROR: Local State not found.
  pause
  exit /b 1
)

echo.
echo [1/3] Backing up Local State...
copy /Y "%LS%" "%BAK%" >nul

echo [2/3] Removing Profile X folders...
for /D %%D in ("%UD%\Profile *") do (
  echo Removing %%~nxD
  rd /S /Q "%%D"
)

echo [3/3] Resetting profiles_created...

> "%PS1%" echo $ErrorActionPreference = 'Stop'
>>"%PS1%" echo $p = Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data\Local State'
>>"%PS1%" echo $raw = [IO.File]::ReadAllText($p, [Text.Encoding]::UTF8)
>>"%PS1%" echo $pattern = '"profiles_created"\s*:\s*\d+'
>>"%PS1%" echo $m = [regex]::Match($raw, $pattern)
>>"%PS1%" echo if (-not $m.Success) { throw 'profiles_created was not found' }
>>"%PS1%" echo Write-Host ('Found: ' + $m.Value)
>>"%PS1%" echo $raw = [regex]::Replace($raw, $pattern, '"profiles_created":1', 1)
>>"%PS1%" echo $utf8 = New-Object Text.UTF8Encoding($false)
>>"%PS1%" echo [IO.File]::WriteAllText($p, $raw, $utf8)
>>"%PS1%" echo $check = [IO.File]::ReadAllText($p, [Text.Encoding]::UTF8)
>>"%PS1%" echo if ($check -notmatch '"profiles_created"\s*:\s*1') { throw 'Verification failed' }
>>"%PS1%" echo Write-Host 'Verified: profiles_created = 1'

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
set "RC=%ERRORLEVEL%"
del /Q "%PS1%" >nul 2>&1

if not "%RC%"=="0" (
  echo.
  echo ERROR: Reset failed. Restoring Local State...
  copy /Y "%BAK%" "%LS%" >nul
  echo Backup restored.
  pause
  exit /b 1
)

echo.
echo ==============================================
echo DONE
echo ==============================================
echo Default was kept.
echo profiles_created is now 1.
echo.
echo IMPORTANT:
echo Open Chrome normally first.
echo Then create ONE new Chrome profile.
echo Check User Data - it should create Profile 1.
echo.
echo Backup:
echo %BAK%
echo ==============================================
pause
endlocal
