FIXED122
- Ô tìm kiếm đổi thành: Công đơn / Khách hàng / Quy cách.
- Có thể nhập Quy cách để tìm các công đơn có Quy cách chứa chuỗi đã nhập.
- Không phân biệt hoa/thường.
- Giữ tìm Công đơn và Khách hàng như trước, gồm logic khách hàng kiểu mkt-246.
- Giữ toàn bộ chức năng FIXED121.
- Dashboard vẫn bỏ.
- Không build lại SftPdfViewer.exe.
