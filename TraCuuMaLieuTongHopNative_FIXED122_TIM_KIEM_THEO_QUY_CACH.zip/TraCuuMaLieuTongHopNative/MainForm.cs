﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Security.Cryptography;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

namespace TraCuuMaLieuTongHopNative
{
    public class MainForm : Form
    {
        TextBox txtSearch, txtKg, txtPcs, txtCheckQty, txtManualRate;
        Label lblFile, lblMaterial, lblCustomer, lblSpec, lblStatus, lblOrder, lblInput, lblIssued, lblTransfer, lblNg, lblNotOk, lblMissingIssue, lblShipping, lblRate, lblQtyCheck, lblQtyCheckIssued;
        Label lblCanTransfer;
        StatusStrip statusBar;
        ToolStripStatusLabel stFile, stCount, stLoaded, stChange;
        Button btnRefresh;
        System.Windows.Forms.Timer excelWatchTimer;
        System.Windows.Forms.Timer searchDebounceTimer;
        DateTime currentFileWriteTime = DateTime.MinValue;
        DateTime pendingFileWriteTime = DateTime.MinValue;
        DateTime pendingFileChangeSince = DateTime.MinValue;
        string lastSmartNoticeWorkOrder = "";
        bool loadingFile = false;
DataGridView grid;
        ContextMenuStrip rowMenu;
        List<WorkOrderRow> rows = new List<WorkOrderRow>();
        List<IssueRow> issues = new List<IssueRow>();
        List<ReceiptRow> receipts = new List<ReceiptRow>();
        WorkOrderRow currentOrder;
        string lastFinishNoticeWorkOrder = "";
        string lastMissingIssueNoticeWorkOrder = "";
        string lastExtraIssueNoticeWorkOrder = "";
        bool overInputWarningShown = false;
        bool clearingLinkedInputs = false;
        bool conversionUpdating;
        double currentRate;
        string lastNoRatePopupWorkOrder = "";
        string currentFile = "";
        const string RegistryPath = @"Software\TraCuuMaLieuTongHopNative\CNC5102";
        const string RegistryExcelValue = "ExcelPath";
        const string RegistrySftUser = "SftUser";
        const string RegistrySftPassword = "SftPassword";
        const string RegistrySftCompany = "SftCompany";
        FlowLayoutPanel recentRatesPanel;

        public MainForm()
        {
            Text = "Chia Đơn 5102";
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch { }
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;
            MinimumSize = new Size(1100, 720);
            Font = new Font("Segoe UI", 10F);
            BackColor = Color.FromArgb(244,247,251);
            BuildUi();
            Shown += delegate { LoadSavedFile(); txtSearch.Focus(); };
        }

        void BuildUi()
        {
            var top = new Panel { Dock = DockStyle.Top, Height = 84, BackColor = Color.White, Padding = new Padding(22,14,22,10) };
            StyleRounded(top,12);
            var title = new Label { Text = "TRA CỨU MÃ LIỆU TỔNG HỢP", AutoSize = true, Font = new Font("Segoe UI Semibold", 18F), ForeColor = Color.FromArgb(24,35,52), Location = new Point(22,12) };
            var btnFile = new Button { Text = "Chọn Excel", Width = 115, Height = 34, Anchor = AnchorStyles.Top|AnchorStyles.Right, BackColor = Color.FromArgb(41,98,255), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            // Nút thao tác giữ khung vuông/ổn định để FlatStyle không bị Region cắt viền.
            btnFile.FlatAppearance.BorderSize = 0;
            btnRefresh = new Button { Text = "Làm mới", Width = 96, Height = 34, Anchor = AnchorStyles.Top|AnchorStyles.Right, BackColor = Color.White, ForeColor = Color.FromArgb(41,98,255), FlatStyle = FlatStyle.Flat };
            btnRefresh.FlatAppearance.BorderColor=Color.FromArgb(41,98,255);
            btnRefresh.FlatAppearance.BorderSize=1;

            btnFile.Click += delegate { ChooseFile(); };
            btnRefresh.Click += delegate { RefreshExcel(); };
            top.Controls.Add(title);


            var btnTodayXln = new Button { Text="Đã Chuyển XLN hôm nay", Width=190, Height=34, BackColor=Color.FromArgb(0,123,167), ForeColor=Color.White, FlatStyle=FlatStyle.Flat };
            btnTodayXln.FlatAppearance.BorderSize=0;
            btnTodayXln.Click += delegate { ShowTodayXln(); };
            top.Controls.Add(btnTodayXln);

            // Sau khi bỏ Dashboard, nút "Đã Chuyển XLN hôm nay" đứng ngay bên phải tiêu đề.
            // Phải đặt vị trí riêng, nếu không WinForms mặc định để nút ở (0,0) và che lên tiêu đề.
            Action placeHeaderActions = delegate {
                btnTodayXln.Left = title.Right + 24;
                btnTodayXln.Top = title.Top + Math.Max(0, (title.Height - btnTodayXln.Height) / 2);
            };
            title.SizeChanged += delegate { placeHeaderActions(); };
            top.Resize += delegate { placeHeaderActions(); };
            placeHeaderActions();

            var btnCopyWo = new Button { Text="Copy Công đơn", Width=112, Height=30, Anchor=AnchorStyles.Top|AnchorStyles.Right, FlatStyle=FlatStyle.Flat, BackColor=Color.White };
            var btnCopyMat = new Button { Text="Copy Mã liệu", Width=112, Height=30, Anchor=AnchorStyles.Top|AnchorStyles.Right, FlatStyle=FlatStyle.Flat, BackColor=Color.White };
            var btnCopyCan = new Button { Text="Copy SL chuyển", Width=118, Height=30, Anchor=AnchorStyles.Top|AnchorStyles.Right, FlatStyle=FlatStyle.Flat, BackColor=Color.White };
            btnCopyWo.FlatAppearance.BorderColor=Color.FromArgb(210,218,230);
            btnCopyMat.FlatAppearance.BorderColor=Color.FromArgb(210,218,230);
            btnCopyCan.FlatAppearance.BorderColor=Color.FromArgb(210,218,230);
            btnCopyWo.FlatAppearance.BorderSize=1;
            btnCopyMat.FlatAppearance.BorderSize=1;
            btnCopyCan.FlatAppearance.BorderSize=1;
            btnCopyWo.Click += delegate { CopyText(currentOrder==null ? "" : currentOrder.WorkOrder, "công đơn"); };
            btnCopyMat.Click += delegate { CopyText(currentOrder==null ? "" : currentOrder.Material, "mã liệu"); };
            btnCopyCan.Click += delegate { CopyText(currentOrder==null ? "" : F(CanTransferQty(currentOrder)), "SL có thể chuyển"); };
            top.Controls.Add(btnCopyWo); top.Controls.Add(btnCopyMat); top.Controls.Add(btnCopyCan);
            Action placeCopyButtons = delegate {
                btnCopyCan.Left=top.ClientSize.Width-btnCopyCan.Width-18;
                btnCopyMat.Left=btnCopyCan.Left-btnCopyMat.Width-8;
                btnCopyWo.Left=btnCopyMat.Left-btnCopyWo.Width-8;
                btnCopyWo.Top=21; btnCopyMat.Top=21; btnCopyCan.Top=21;
            };
            top.Resize += delegate { placeCopyButtons(); };
            placeCopyButtons();
            Controls.Add(top);


            var searchPanel = new Panel { Dock = DockStyle.Top, Height = 94, BackColor = Color.FromArgb(244,247,251), Padding = new Padding(22,14,22,8) };
            StyleRounded(searchPanel,12);
            searchPanel.Controls.Add(new Label { Text="Công đơn / Khách hàng / Quy cách", AutoSize=true, Font=new Font("Segoe UI Semibold",10F), Location=new Point(18,8) });
            txtSearch = new TextBox { Font = new Font("Segoe UI",16F), Height=40, Width=420, Location=new Point(22,31) };
            searchDebounceTimer=new System.Windows.Forms.Timer();
            searchDebounceTimer.Interval=450;
            searchDebounceTimer.Tick += delegate
            {
                searchDebounceTimer.Stop();
                Search();
            };

            txtSearch.TextChanged += delegate
            {
                if(searchDebounceTimer!=null) searchDebounceTimer.Stop();

                string raw=(txtSearch.Text??"").Trim();
                if(raw.Length==0)
                {
                    Search();
                    return;
                }

                bool allDigits=true;
                for(int i=0;i<raw.Length;i++)
                {
                    if(!char.IsDigit(raw[i])) { allDigits=false; break; }
                }

                // Công đơn: chỉ tìm khi đủ 9 số.
                if(allDigits)
                {
                    if(raw.Length>=9) Search();
                    return;
                }

                // Khách hàng/chữ: chỉ tìm sau khi dừng gõ.
                searchDebounceTimer.Start();
            };

            txtSearch.KeyDown += delegate(object sender,KeyEventArgs e)
            {
                if(e.KeyCode==Keys.Enter)
                {
                    if(searchDebounceTimer!=null) searchDebounceTimer.Stop();
                    Search();
                    e.SuppressKeyPress=true;
                }
            };
            searchPanel.Controls.Add(txtSearch);
            lblFile = new Label { Text="Chưa chọn file Excel", AutoSize=false, TextAlign=ContentAlignment.MiddleLeft, ForeColor=Color.DimGray, Location=new Point(465,33), Size=new Size(600,32) };
            searchPanel.Controls.Add(lblFile);
            searchPanel.Controls.Add(btnRefresh);
            searchPanel.Controls.Add(btnFile);
            btnFile.Location = new Point(searchPanel.ClientSize.Width - btnFile.Width - 18, 31);
            btnRefresh.Location = new Point(btnFile.Left - btnRefresh.Width - 8, 31);
            searchPanel.Resize += delegate {
                btnFile.Left = searchPanel.ClientSize.Width - btnFile.Width - 18;
                btnRefresh.Left = btnFile.Left - btnRefresh.Width - 8;
            };
            Controls.Add(searchPanel);

            var cards = new FlowLayoutPanel { Dock=DockStyle.Top, Height=168, Padding=new Padding(18,4,18,8), WrapContents=true, BackColor=Color.FromArgb(244,247,251) };
            lblMaterial = AddCard(cards,"Mã liệu","-");
            lblCustomer = AddCard(cards,"Khách hàng","-");
            lblSpec = AddCard(cards,"Quy cách","-");
            lblStatus = AddCard(cards,"Trạng thái","-");
            lblOrder = AddCard(cards,"SL đơn hàng","-");
            lblInput = AddCard(cards,"SL đầu vào","-");
            lblIssued = AddCard(cards,"Đã lĩnh liệu","-");
            lblTransfer = AddCard(cards,"Chuyển KH","-");
            lblNg = AddCard(cards,"NG","-");
            lblNotOk = AddCard(cards,"SL chưa OK","-");
            lblCanTransfer = AddCard(cards,"SL có thể chuyển","-");
            lblMissingIssue = AddCard(cards,"Lĩnh liệu thiếu","-");
            lblShipping = AddCard(cards,"Lịch xuất hàng","-");
            Controls.Add(cards);


            var qtyConvertRow = new Panel { Dock=DockStyle.Top, Height=100, BackColor=Color.FromArgb(244,247,251), Padding=new Padding(22,8,22,8) };
            var qtyCheck = new Panel { Dock=DockStyle.Left, Width=760, BackColor=Color.FromArgb(244,247,251), Padding=new Padding(0) };
            var convert = new Panel { Dock=DockStyle.Fill, BackColor=Color.FromArgb(244,247,251), Padding=new Padding(0) };
            qtyConvertRow.Controls.Add(convert);
            qtyConvertRow.Controls.Add(qtyCheck);
            convert.Controls.Add(new Label { Text="QUY ĐỔI KG ↔ PCS", AutoSize=true, Font=new Font("Segoe UI Semibold",10F), ForeColor=Color.FromArgb(24,35,52), Location=new Point(16,10) });
            var rateCaption = new Label { Text="Quy đổi cột Q", AutoSize=false, ForeColor=Color.DimGray, Location=new Point(16,43), Size=new Size(105,28), TextAlign=ContentAlignment.MiddleLeft };
            convert.Controls.Add(rateCaption);
            lblRate = new Label { Text="-", AutoSize=false, Font=new Font("Segoe UI Semibold",13F), ForeColor=Color.FromArgb(41,98,255), Location=new Point(125,39), Size=new Size(85,28), TextAlign=ContentAlignment.MiddleCenter };
            convert.Controls.Add(lblRate);
            txtManualRate = new TextBox { Font=new Font("Segoe UI Semibold",13F), ForeColor=Color.FromArgb(41,98,255), BackColor=Color.FromArgb(255,250,220), Location=new Point(125,37), Width=85, Height=30, TextAlign=HorizontalAlignment.Center, Visible=false };
            txtManualRate.TextChanged += delegate { UpdateManualConversionRate(); };
            convert.Controls.Add(txtManualRate);
            convert.Controls.Add(new Label { Text="KG", AutoSize=true, Font=new Font("Segoe UI Semibold",10F), Location=new Point(240,43) });
            txtKg = new TextBox { Font=new Font("Segoe UI",13F), Location=new Point(272,37), Width=125, Height=30 };
            convert.Controls.Add(txtKg);
            convert.Controls.Add(new Label { Text="PCS", AutoSize=true, Font=new Font("Segoe UI Semibold",10F), Location=new Point(420,43) });
            txtPcs = new TextBox { Font=new Font("Segoe UI",13F), Location=new Point(458,37), Width=135, Height=30 };
            convert.Controls.Add(txtPcs);
            var recentCaption = new Label { Text="5 quy đổi gần nhất:", AutoSize=true, ForeColor=Color.DimGray, Location=new Point(615,43) };
            convert.Controls.Add(recentCaption);
            recentRatesPanel = new FlowLayoutPanel { Location=new Point(735,34), Size=new Size(360,38), FlowDirection=FlowDirection.LeftToRight, WrapContents=false, BackColor=Color.Transparent, Padding=new Padding(0), Margin=new Padding(0) };
            convert.Controls.Add(recentRatesPanel);
            txtKg.TextChanged += delegate { ConvertFromKg(); };
            txtPcs.TextChanged += delegate { ConvertFromPcs(); };
qtyCheck.Controls.Add(new Label { Text="Nhập SL", AutoSize=true, Font=new Font("Segoe UI Semibold",10F), Location=new Point(18,43) });
            txtCheckQty = new TextBox { Font=new Font("Segoe UI",13F), Location=new Point(92,37), Width=150, Height=30 };
            qtyCheck.Controls.Add(txtCheckQty);

            qtyCheck.Controls.Add(new Label { Text="Theo đơn hàng:", AutoSize=true, Font=new Font("Segoe UI Semibold",10F), Location=new Point(275,12) });
            lblQtyCheck = new Label { Text="Nhập SL để kiểm tra", AutoSize=false, Font=new Font("Segoe UI Semibold",12F), ForeColor=Color.DimGray, Location=new Point(390,7), Size=new Size(270,28), TextAlign=ContentAlignment.MiddleLeft };
            qtyCheck.Controls.Add(lblQtyCheck);

            qtyCheck.Controls.Add(new Label { Text="Theo lĩnh liệu:", AutoSize=true, Font=new Font("Segoe UI Semibold",10F), Location=new Point(275,47) });
            lblQtyCheckIssued = new Label { Text="Nhập SL để kiểm tra", AutoSize=false, Font=new Font("Segoe UI Semibold",12F), ForeColor=Color.DimGray, Location=new Point(390,42), Size=new Size(270,28), TextAlign=ContentAlignment.MiddleLeft };
            qtyCheck.Controls.Add(lblQtyCheckIssued);


            txtCheckQty.TextChanged += delegate { UpdateQuantityCheck(); };
            txtKg.TextChanged += delegate {
                if(!clearingLinkedInputs && string.IsNullOrWhiteSpace(txtKg.Text)) ClearLinkedQuantityInputs();
            };
            txtPcs.TextChanged += delegate {
                if(!clearingLinkedInputs && string.IsNullOrWhiteSpace(txtPcs.Text)) ClearLinkedQuantityInputs();
            };
            txtCheckQty.TextChanged += delegate {
                if(!clearingLinkedInputs && string.IsNullOrWhiteSpace(txtCheckQty.Text)) ClearLinkedQuantityInputs();
            };
            Controls.Add(qtyConvertRow);



            var body = new Panel { Dock=DockStyle.Fill, Padding=new Padding(22,8,22,20) };
            StyleRounded(body,12);
            var heading = new Label { Text="Các công đơn cùng mã liệu  •  Chuột phải vào công đơn để xem chi tiết", Dock=DockStyle.Top, Height=34, Font=new Font("Segoe UI Semibold",12F) };
            grid = new DataGridView { Dock=DockStyle.Fill, ReadOnly=true, AllowUserToAddRows=false, AllowUserToDeleteRows=false, AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill, BackgroundColor=Color.White, BorderStyle=BorderStyle.FixedSingle, RowHeadersVisible=false, SelectionMode=DataGridViewSelectionMode.FullRowSelect, MultiSelect=false };
            grid.Columns.Add("status","Trạng thái"); grid.Columns.Add("wo","Công đơn"); grid.Columns.Add("mat","Mã liệu"); grid.Columns.Add("customer","Khách hàng"); grid.Columns.Add("spec","Quy cách"); grid.Columns.Add("shipping","Lịch xuất hàng"); grid.Columns.Add("order","SL đơn"); grid.Columns.Add("issued","Đã lĩnh"); grid.Columns.Add("transfer","Chuyển KH"); grid.Columns.Add("ng","NG"); grid.Columns.Add("notok","Chưa OK"); grid.Columns.Add("cantransfer","SL có thể chuyển"); grid.Columns.Add("missing","Thiếu lĩnh");
            grid.EnableHeadersVisualStyles=false;
            grid.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(236,242,252);
            grid.ColumnHeadersDefaultCellStyle.ForeColor=Color.FromArgb(36,49,73);
            grid.ColumnHeadersDefaultCellStyle.Font=new Font("Segoe UI Semibold",9F);
            grid.GridColor=Color.FromArgb(225,230,238);
            BuildContextMenu();
            grid.MouseDown += GridMouseDown;
            grid.CellDoubleClick += delegate(object sender, DataGridViewCellEventArgs e) {
                if(e.RowIndex<0) return;
                object v=grid.Rows[e.RowIndex].Cells["wo"].Value;
                if(v==null) return;
                string wo=Convert.ToString(v).Trim();
                if(wo.Length==0) return;
                txtSearch.Text=wo;
                txtSearch.SelectionStart=txtSearch.Text.Length;
                txtSearch.Focus();
            };
            body.Controls.Add(grid); body.Controls.Add(heading); Controls.Add(body);
            body.BringToFront();

            statusBar = new StatusStrip();
            statusBar.SizingGrip=false;
            statusBar.BackColor=Color.White;
            stFile=new ToolStripStatusLabel("Excel: chưa chọn");
            stCount=new ToolStripStatusLabel("Công đơn: 0");
            stLoaded=new ToolStripStatusLabel("Nạp lúc: -");
            stChange=new ToolStripStatusLabel("");
            stFile.Spring=true; stFile.TextAlign=ContentAlignment.MiddleLeft;
            statusBar.Items.Add(stFile);
            statusBar.Items.Add(new ToolStripStatusLabel(" | "));
            statusBar.Items.Add(stCount);
            statusBar.Items.Add(new ToolStripStatusLabel(" | "));
            statusBar.Items.Add(stLoaded);
            statusBar.Items.Add(new ToolStripStatusLabel(" | "));
            statusBar.Items.Add(stChange);
            Controls.Add(statusBar);
            statusBar.BringToFront();

            excelWatchTimer=new System.Windows.Forms.Timer();
            excelWatchTimer.Interval=3000;
            excelWatchTimer.Tick += delegate { CheckExcelChanged(); };
            excelWatchTimer.Start();
        }

        void BuildContextMenu()
        {
            rowMenu = new ContextMenuStrip();
            ToolStripMenuItem miSft=new ToolStripMenuItem("In công đơn SFT");
            ToolStripMenuItem miSftConfig=new ToolStripMenuItem("Cấu hình SFT...");
            var miIssue = new ToolStripMenuItem("Chi tiết lĩnh liệu");
            var miReceipt = new ToolStripMenuItem("Chi tiết chuyển XLN");
            var miTimeline = new ToolStripMenuItem("Chi Tiết Công Đơn");
            var miCopySummary = new ToolStripMenuItem("Sao Chép Tóm Tắt Công Đơn");
            miIssue.Click += delegate { ShowIssueDetails(SelectedWorkOrder()); };
            miReceipt.Click += delegate { ShowReceiptDetails(SelectedWorkOrder()); };
            miTimeline.Click += delegate { ShowWorkOrderTimeline(SelectedWorkOrder()); };
            miCopySummary.Click += delegate { CopyWorkOrderSummary(SelectedWorkOrder()); };
            
            miSft.Click += delegate
            {
                string wo=GetSelectedWorkOrder();
                if(wo.Length==0) return;
                OpenSftForWorkOrder(wo);
            };
            miSftConfig.Click += delegate { ConfigureSft(true); };
            rowMenu.Items.Add(miIssue);
            rowMenu.Items.Add(miReceipt);
            rowMenu.Items.Add(miTimeline);
            rowMenu.Items.Add(miCopySummary);
            rowMenu.Items.Add(new ToolStripSeparator());
            rowMenu.Items.Add(miSft);
            rowMenu.Items.Add(miSftConfig);
            grid.ContextMenuStrip = rowMenu;
        }


        void CopyWorkOrderSummary(string workOrder)
        {
            if(string.IsNullOrWhiteSpace(workOrder)) return;
            WorkOrderRow wo=rows==null ? null :
                rows.FirstOrDefault(x=>x.WorkOrder.Equals(workOrder,StringComparison.OrdinalIgnoreCase));
            if(wo==null) return;

            string ship=string.IsNullOrWhiteSpace(wo.ShippingDate) ? "-" : wo.ShippingDate;
            string status=string.IsNullOrWhiteSpace(wo.Status) ? "-" : wo.Status;
            string text=
                "TÓM TẮT CÔNG ĐƠN\r\n"+
                "Công đơn: "+wo.WorkOrder+"\r\n"+
                "Mã liệu: "+wo.Material+"\r\n"+
                "Khách hàng: "+wo.Customer+"\r\n"+
                "Quy cách: "+wo.Spec+"\r\n"+
                "Trạng thái: "+status+"\r\n"+
                "Lịch xuất hàng: "+ship+"\r\n\r\n"+
                "SL đơn hàng: "+F(wo.OrderQty)+" PCS\r\n"+
                "SL đầu vào: "+F(wo.InputQty)+" PCS\r\n"+
                "Đã lĩnh liệu: "+F(wo.IssuedQty)+" PCS\r\n"+
                "Đã chuyển XLN: "+F(wo.TransferQty)+" PCS\r\n"+
                "NG: "+F(wo.NgQty)+" PCS\r\n"+
                (wo.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase)
                    ? "SL dư: "+F(wo.NotOkQty)+" PCS\r\n"
                    : "SL chưa OK: "+F(wo.NotOkQty)+" PCS\r\n")+
                "SL có thể chuyển: "+F(CanTransferQty(wo))+" PCS";

            try
            {
                Clipboard.SetText(text);
                MessageBox.Show(this,"Đã sao chép tóm tắt công đơn "+wo.WorkOrder+
                    ".\r\nCó thể dán trực tiếp vào Zalo, Teams hoặc tin nhắn.",
                    "Sao Chép Tóm Tắt",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch(Exception ex)
            {
                MessageBox.Show(this,"Không thể sao chép vào Clipboard.\r\n"+ex.Message,
                    "Sao Chép Tóm Tắt",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
        }

        void ShowNoConversionPopupIfNeeded(string workOrder, double rate)
        {
            if(rate>0 || string.IsNullOrWhiteSpace(workOrder)) return;
            if(lastNoRatePopupWorkOrder.Equals(workOrder,StringComparison.OrdinalIgnoreCase)) return;

            lastNoRatePopupWorkOrder=workOrder;
            MessageBox.Show(this,
                "Công đơn này chưa có số quy đổi ở cột Q.\r\n\r\n"+
                "Có thể nhập tay số quy đổi tại phần Quy Đổi để tiếp tục chia đơn.",
                "Chưa Có Quy Đổi",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        void ShowWorkOrderTimeline(string workOrder)
        {
            if(string.IsNullOrWhiteSpace(workOrder)) return;
            WorkOrderRow wo=rows.FirstOrDefault(x=>x.WorkOrder.Equals(workOrder,StringComparison.OrdinalIgnoreCase));
            if(wo==null) return;

            Form f=new Form { Text="CHI TIẾT CÔNG ĐƠN - "+workOrder, StartPosition=FormStartPosition.CenterParent,
                Size=new Size(1050,680), MinimumSize=new Size(850,520), Font=new Font("Segoe UI",10F),
                BackColor=Color.FromArgb(244,247,251) };

            Label head=new Label { Dock=DockStyle.Top, Height=92, Padding=new Padding(18,12,0,0),
                BackColor=Color.White, ForeColor=Color.FromArgb(24,35,52),
                Font=new Font("Segoe UI Semibold",11F),
                Text="CHI TIẾT CÔNG ĐƠN: "+workOrder+"\r\nMã liệu: "+wo.Material+
                     "     Khách hàng: "+wo.Customer+"     Quy cách: "+wo.Spec+
                     "\r\nSL đơn: "+F(wo.OrderQty)+"     Đã lĩnh: "+F(wo.IssuedQty)+
                     "     Chuyển XLN: "+F(wo.TransferQty)+"     NG: "+F(wo.NgQty) };

            DataGridView g=new DataGridView { Dock=DockStyle.Fill, ReadOnly=true, AllowUserToAddRows=false,
                AllowUserToDeleteRows=false, RowHeadersVisible=false, SelectionMode=DataGridViewSelectionMode.FullRowSelect,
                MultiSelect=false, BackgroundColor=Color.White, BorderStyle=BorderStyle.None,
                AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill };
            g.DefaultCellStyle.ForeColor=Color.Black; g.DefaultCellStyle.SelectionBackColor=Color.White;
            g.DefaultCellStyle.SelectionForeColor=Color.Black; g.RowTemplate.Height=31;
            string[] hs={"Thời gian","Sự kiện","Số lượng","KG","Chi tiết"};
            foreach(string h in hs) g.Columns.Add("c"+g.Columns.Count,h);
            g.Columns[0].FillWeight=90; g.Columns[1].FillWeight=100; g.Columns[2].FillWeight=70;
            g.Columns[3].FillWeight=60; g.Columns[4].FillWeight=250;

            var evs=new List<Tuple<DateTime,string,string,string,string>>();
            foreach(var x in issues.Where(x=>x.WorkOrder.Equals(workOrder,StringComparison.OrdinalIgnoreCase)))
                evs.Add(Tuple.Create(ParseTimelineDate(x.Date),"Lĩnh liệu",F(x.IssuedQty),FormatKgCompact(x.Kg),
                    string.IsNullOrWhiteSpace(x.ErpNote) ? x.Material : x.Material+" | "+x.ErpNote));
            foreach(var x in receipts.Where(x=>x.WorkOrder.Equals(workOrder,StringComparison.OrdinalIgnoreCase)))
            {
                string detail=x.Status;
                if(!string.IsNullOrWhiteSpace(x.Note)) detail+=(detail.Length>0?" | ":"")+x.Note;
                if(x.PcsPerKg>0) detail+=(detail.Length>0?" | ":"")+"Quy đổi: "+
                    RoundConversionRate(x.PcsPerKg).ToString("0.#",CultureInfo.GetCultureInfo("vi-VN"));
                evs.Add(Tuple.Create(ParseTimelineDate(x.Date),"Chuyển XLN",F(x.Qty),FormatKgCompact(x.Kg),detail));
            }
            foreach(var e in evs.OrderBy(x=>x.Item1==DateTime.MinValue?DateTime.MaxValue:x.Item1))
                g.Rows.Add(e.Item1==DateTime.MinValue?"":e.Item1.ToString("dd/MM/yyyy HH:mm"),
                    e.Item2,e.Item3,e.Item4,e.Item5);

            string now=wo.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase) ? "Công đơn đã FINISH" :
                "WAITING | SL chưa OK: "+F(wo.NotOkQty)+" | SL có thể chuyển: "+F(CanTransferQty(wo));
            int ri=g.Rows.Add("HIỆN TẠI","Trạng thái",wo.Status,"",now);
            g.Rows[ri].DefaultCellStyle.Font=new Font("Segoe UI Semibold",10F,FontStyle.Bold);
            g.Rows[ri].DefaultCellStyle.ForeColor=wo.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase)?Color.SeaGreen:Color.Firebrick;

            double totalXlnKg=receipts
                .Where(x=>x.WorkOrder.Equals(workOrder,StringComparison.OrdinalIgnoreCase))
                .Sum(x=>x.Kg);

            Label sum=new Label { Dock=DockStyle.Bottom, Height=42, Padding=new Padding(18,11,0,0),
                BackColor=Color.White, Font=new Font("Segoe UI Semibold",10F),
                Text="Tổng sự kiện: "+evs.Count+
                     "     Lĩnh liệu: "+evs.Count(x=>x.Item2=="Lĩnh liệu")+
                     "     Chuyển XLN: "+evs.Count(x=>x.Item2=="Chuyển XLN")+
                     "     Tổng KG chuyển XLN: "+FormatKgCompact(totalXlnKg) };
            f.Controls.Add(g); f.Controls.Add(sum); f.Controls.Add(head); f.ShowDialog(this);
        }

        DateTime ParseTimelineDate(string value)
        {
            if(string.IsNullOrWhiteSpace(value)) return DateTime.MinValue;
            DateTime d;
            if(DateTime.TryParse(value,CultureInfo.GetCultureInfo("vi-VN"),DateTimeStyles.None,out d)) return d;
            if(DateTime.TryParse(value,CultureInfo.InvariantCulture,DateTimeStyles.None,out d)) return d;
            return DateTime.MinValue;
        }

        void ShowAllXlnForSelectedMaterial()
        {
            if(grid==null || grid.CurrentRow==null) return;

            string material="";
            try
            {
                object v=grid.CurrentRow.Cells["mat"].Value;
                material=v==null ? "" : Convert.ToString(v).Trim();
            }
            catch
            {
                // Fallback theo công đơn đang chọn nếu tên cột thay đổi.
                string wo=SelectedWorkOrder();
                WorkOrderRow selected=rows.FirstOrDefault(x=>x.WorkOrder.Equals(wo,StringComparison.OrdinalIgnoreCase));
                if(selected!=null) material=selected.Material;
            }

            if(string.IsNullOrWhiteSpace(material)) return;

            var list=receipts
                .Where(x=>x.Material.Equals(material,StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(x=>x.RowNumber)
                .ToList();

            Form f=new Form();
            f.Text="ALL CHUYỂN XLN - MÃ LIỆU "+material;
            f.StartPosition=FormStartPosition.CenterParent;
            f.Size=new Size(1180,650);
            f.MinimumSize=new Size(900,500);
            f.Font=new Font("Segoe UI",10F);
            f.BackColor=Color.FromArgb(244,247,251);

            Label head=new Label();
            head.Dock=DockStyle.Top;
            head.Height=54;
            head.Padding=new Padding(18,15,0,0);
            head.Font=new Font("Segoe UI Semibold",14F);
            head.ForeColor=Color.FromArgb(24,35,52);
            head.BackColor=Color.White;
            head.Text="ALL CHUYỂN XLN - MÃ LIỆU: "+material;

            Label sum=new Label();
            sum.Dock=DockStyle.Bottom;
            sum.Height=46;
            sum.Padding=new Padding(18,12,0,0);
            sum.Font=new Font("Segoe UI Semibold",10.5F);
            sum.BackColor=Color.White;
            sum.ForeColor=Color.FromArgb(24,35,52);

            DataGridView g=new DataGridView();
            g.Dock=DockStyle.Fill;
            g.ReadOnly=true;
            g.AllowUserToAddRows=false;
            g.AllowUserToDeleteRows=false;
            g.RowHeadersVisible=false;
            g.SelectionMode=DataGridViewSelectionMode.FullRowSelect;
            g.MultiSelect=false;
            g.BackgroundColor=Color.White;
            g.BorderStyle=BorderStyle.None;
            g.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;
            g.DefaultCellStyle.SelectionBackColor=Color.White;
            g.DefaultCellStyle.SelectionForeColor=Color.Black;
            g.DefaultCellStyle.ForeColor=Color.Black;

            string[] headers={"Ngày chuyển","Công đơn","Mã liệu","Quy cách","SL chuyển XLN","KG","Trạng thái","Quy đổi PCS/KG","Ghi chú"};
            foreach(string h in headers) g.Columns.Add("c"+g.Columns.Count.ToString(),h);

            foreach(DataGridViewColumn c in g.Columns) c.MinimumWidth=45;
            for(int ci=0;ci<g.Columns.Count;ci++)
            {
                DataGridViewColumn c=g.Columns[ci];
                if(c.HeaderText=="Ngày chuyển")          c.FillWeight=80F;
                else if(c.HeaderText=="Công đơn")       c.FillWeight=135F;
                else if(c.HeaderText=="Mã liệu")        c.FillWeight=155F;
                else if(c.HeaderText=="Quy cách")       c.FillWeight=145F;
                else if(c.HeaderText=="SL chuyển XLN")  c.FillWeight=90F;
                else if(c.HeaderText=="KG")             c.FillWeight=65F;
                else if(c.HeaderText=="Trạng thái")     { c.FillWeight=175F; c.MinimumWidth=175; }
                else if(c.HeaderText=="Quy đổi PCS/KG") c.FillWeight=85F;
                else if(c.HeaderText=="Ghi chú")        c.FillWeight=95F;
            }

            foreach(var x in list)
            {
                WorkOrderRow wo=rows==null?null:rows.FirstOrDefault(r=>r.WorkOrder.Equals(x.WorkOrder,StringComparison.OrdinalIgnoreCase));
                string xlnStatus=x.Status;
                if(wo!=null)
                {
                    double missing=Math.Max(0,-wo.NotOkQty);
                    if(wo.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase) || missing<=0)
                        xlnStatus="FINISH";
                    else
                        xlnStatus="Còn thiếu: "+F(missing)+" PCS";
                }

                int ri=g.Rows.Add(
                    x.Date, x.WorkOrder, x.Material, x.Spec, F(x.Qty), FormatKgCompact(x.Kg),
                    xlnStatus,
                    x.PcsPerKg>0 ? RoundConversionRate(x.PcsPerKg).ToString("0.#",CultureInfo.GetCultureInfo("vi-VN")) : "",
                    x.Note
                );
                DataGridViewCell statusCell=g.Rows[ri].Cells[6];
                if(string.Equals(xlnStatus,"FINISH",StringComparison.OrdinalIgnoreCase))
                {
                    statusCell.Style.ForeColor=Color.SeaGreen;
                    statusCell.Style.Font=new Font("Segoe UI Semibold",10F,FontStyle.Bold);
                }
                else if(xlnStatus.StartsWith("Còn thiếu:",StringComparison.OrdinalIgnoreCase))
                {
                    statusCell.Style.ForeColor=Color.Firebrick;
                    statusCell.Style.Font=new Font("Segoe UI Semibold",10F,FontStyle.Bold);
                }
            }

            int workOrderCount=list.Select(x=>x.WorkOrder).Where(x=>!string.IsNullOrWhiteSpace(x))
                                   .Distinct(StringComparer.OrdinalIgnoreCase).Count();
            sum.Text="Mã liệu: "+material+
                     "     Công đơn: "+workOrderCount.ToString("N0",CultureInfo.GetCultureInfo("vi-VN"))+
                     "     Dòng chuyển: "+list.Count.ToString("N0",CultureInfo.GetCultureInfo("vi-VN"))+
                     "     Tổng SL chuyển: "+F(list.Sum(x=>x.Qty))+" PCS"+
                     "     Tổng KG: "+F3(list.Sum(x=>x.Kg));

            f.Controls.Add(g);
            f.Controls.Add(sum);
            f.Controls.Add(head);
            f.ShowDialog(this);
        }

        void ShowTodayXln()
        {
            if(receipts==null || receipts.Count==0)
            {
                MessageBox.Show(this,"Chưa có dữ liệu sheet 入库-转包装-转生管. Hãy chọn/đọc lại Excel trước.","Đã Chuyển XLN",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }

            ShowXlnByDate(DateTime.Today);
        }

        void ShowXlnByDate(DateTime initialDate)
        {
            Form f=new Form();
            f.Text="ĐÃ CHUYỂN XLN - "+initialDate.ToString("dd/MM/yyyy");
            f.StartPosition=FormStartPosition.CenterParent;
            f.Size=new Size(1180,650);
            f.MinimumSize=new Size(900,500);
            f.Font=new Font("Segoe UI",10F);
            f.BackColor=Color.FromArgb(244,247,251);

            Panel top=new Panel();
            top.Dock=DockStyle.Top;
            top.Height=58;
            top.BackColor=Color.White;

            Label head=new Label();
            head.AutoSize=true;
            head.Font=new Font("Segoe UI Semibold",15F);
            head.ForeColor=Color.FromArgb(24,35,52);
            head.Location=new Point(18,16);

            Label lblDate=new Label();
            lblDate.Text="Chọn ngày:";
            lblDate.AutoSize=true;
            lblDate.Font=new Font("Segoe UI Semibold",10F);
            lblDate.ForeColor=Color.FromArgb(70,80,95);
            lblDate.Anchor=AnchorStyles.Top|AnchorStyles.Right;
            lblDate.Location=new Point(top.Width-275,19);

            DateTimePicker picker=new DateTimePicker();
            picker.Format=DateTimePickerFormat.Custom;
            picker.CustomFormat="dd/MM/yyyy";
            picker.Value=initialDate.Date;
            picker.Width=125;
            picker.Font=new Font("Segoe UI",10F);
            picker.Anchor=AnchorStyles.Top|AnchorStyles.Right;
            picker.Location=new Point(top.Width-145,14);

            top.Resize += delegate
            {
                picker.Left=top.ClientSize.Width-picker.Width-18;
                lblDate.Left=picker.Left-lblDate.Width-10;
            };

            top.Controls.Add(head);
            top.Controls.Add(lblDate);
            top.Controls.Add(picker);

            Label sum=new Label();
            sum.Dock=DockStyle.Bottom;
            sum.Height=46;
            sum.Padding=new Padding(18,12,0,0);
            sum.Font=new Font("Segoe UI Semibold",10.5F);
            sum.BackColor=Color.White;
            sum.ForeColor=Color.FromArgb(24,35,52);

            DataGridView g=new DataGridView();
            g.Dock=DockStyle.Fill;
            g.ReadOnly=true;
            g.AllowUserToAddRows=false;
            g.AllowUserToDeleteRows=false;
            g.RowHeadersVisible=false;
            g.SelectionMode=DataGridViewSelectionMode.FullRowSelect;
            g.MultiSelect=false;
            g.BackgroundColor=Color.White;
            g.BorderStyle=BorderStyle.None;
            g.AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill;
            g.DefaultCellStyle.SelectionBackColor=Color.White;
            g.DefaultCellStyle.SelectionForeColor=Color.Black;
            g.DefaultCellStyle.ForeColor=Color.Black;

            string[] headers={"Ngày chuyển","Công đơn","Mã liệu","Quy cách","SL chuyển XLN","KG","Trạng thái","Quy đổi PCS/KG","Ghi chú"};
            foreach(string h in headers) g.Columns.Add("c"+g.Columns.Count.ToString(),h);

            foreach(DataGridViewColumn c in g.Columns) c.MinimumWidth=45;
            for(int ci=0;ci<g.Columns.Count;ci++)
            {
                DataGridViewColumn c=g.Columns[ci];
                if(c.HeaderText=="Ngày chuyển")          c.FillWeight=80F;
                else if(c.HeaderText=="Công đơn")       c.FillWeight=135F;
                else if(c.HeaderText=="Mã liệu")        c.FillWeight=155F;
                else if(c.HeaderText=="Quy cách")       c.FillWeight=145F;
                else if(c.HeaderText=="SL chuyển XLN")  c.FillWeight=90F;
                else if(c.HeaderText=="KG")             c.FillWeight=65F;
                else if(c.HeaderText=="Trạng thái")     { c.FillWeight=175F; c.MinimumWidth=175; }
                else if(c.HeaderText=="Quy đổi PCS/KG") c.FillWeight=85F;
                else if(c.HeaderText=="Ghi chú")        c.FillWeight=95F;
            }

            f.Controls.Add(g);
            f.Controls.Add(sum);
            f.Controls.Add(top);

            Action<DateTime> loadDate=delegate(DateTime selectedDate)
            {
                DateTime selected=selectedDate.Date;
                var list=receipts.Where(x=>IsSameDate(x.Date,selected))
                                 .OrderBy(x=>x.WorkOrder)
                                 .ThenBy(x=>x.RowNumber)
                                 .ToList();

                g.Rows.Clear();

                foreach(var x in list)
                {
                    WorkOrderRow wo=rows==null?null:rows.FirstOrDefault(r=>r.WorkOrder.Equals(x.WorkOrder,StringComparison.OrdinalIgnoreCase));
                    string xlnStatus=x.Status;

                    if(wo!=null)
                    {
                        double missing=Math.Max(0,-wo.NotOkQty);
                        if(wo.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase) || missing<=0)
                            xlnStatus="FINISH";
                        else
                            xlnStatus="Còn thiếu: "+F(missing)+" PCS";
                    }

                    int ri=g.Rows.Add(
                        x.Date,
                        x.WorkOrder,
                        x.Material,
                        x.Spec,
                        F(x.Qty),
                        FormatKgCompact(x.Kg),
                        xlnStatus,
                        x.PcsPerKg>0 ? Math.Round(x.PcsPerKg,1,MidpointRounding.AwayFromZero).ToString("0.#",CultureInfo.GetCultureInfo("vi-VN")) : "",
                        x.Note
                    );

                    DataGridViewCell statusCell=g.Rows[ri].Cells[6];
                    if(string.Equals(xlnStatus,"FINISH",StringComparison.OrdinalIgnoreCase))
                    {
                        statusCell.Style.ForeColor=Color.SeaGreen;
                        statusCell.Style.Font=new Font("Segoe UI Semibold",10F,FontStyle.Bold);
                    }
                    else if(xlnStatus.StartsWith("Còn thiếu:",StringComparison.OrdinalIgnoreCase))
                    {
                        statusCell.Style.ForeColor=Color.Firebrick;
                        statusCell.Style.Font=new Font("Segoe UI Semibold",10F,FontStyle.Bold);
                    }
                }

                int workOrderCount=list.Select(x=>x.WorkOrder)
                                       .Where(x=>!string.IsNullOrWhiteSpace(x))
                                       .Distinct(StringComparer.OrdinalIgnoreCase)
                                       .Count();
                double totalQty=list.Sum(x=>x.Qty);
                double totalKg=list.Sum(x=>x.Kg);

                head.Text="ĐÃ CHUYỂN XLN - "+selected.ToString("dd/MM/yyyy");
                f.Text=head.Text;
                sum.Text="Ngày: "+selected.ToString("dd/MM/yyyy")+
                         "     Công đơn: "+workOrderCount.ToString("N0",CultureInfo.GetCultureInfo("vi-VN"))+
                         "     Dòng chuyển: "+list.Count.ToString("N0",CultureInfo.GetCultureInfo("vi-VN"))+
                         "     Tổng SL chuyển: "+F(totalQty)+" PCS"+
                         "     Tổng KG: "+F3(totalKg);
            };

            picker.ValueChanged += delegate
            {
                loadDate(picker.Value);
            };

            loadDate(initialDate);
            f.ShowDialog(this);
        }

        bool IsSameDate(string value, DateTime target)
        {
            if(string.IsNullOrWhiteSpace(value)) return false;
            DateTime d;
            string v=value.Trim();
            string[] formats={"dd/MM/yyyy","d/M/yyyy","dd-MM-yyyy","d-M-yyyy","yyyy-MM-dd","yyyy/M/d","MM/dd/yyyy"};
            if(DateTime.TryParseExact(v,formats,CultureInfo.InvariantCulture,DateTimeStyles.None,out d)) return d.Date==target.Date;
            if(DateTime.TryParse(v,CultureInfo.GetCultureInfo("vi-VN"),DateTimeStyles.None,out d)) return d.Date==target.Date;
            return false;
        }

        string GetSelectedWorkOrder()
        {
            if(grid==null || grid.CurrentRow==null) return "";
            try
            {
                object v=grid.CurrentRow.Cells["wo"].Value;
                return v==null ? "" : Convert.ToString(v).Trim();
            }
            catch { return ""; }
        }

        void OpenSftForWorkOrder(string workOrder)
        {
            if(string.IsNullOrWhiteSpace(workOrder)) return;

            SftSettings settings=LoadSftSettings();
            if(settings==null || !settings.IsComplete)
            {
                settings=ConfigureSft(false);
                if(settings==null || !settings.IsComplete) return;
            }

            if(stChange!=null)
            {
                stChange.Text="SFT: đang tạo PDF công đơn "+workOrder+"...";
                stChange.ForeColor=Color.DarkOrange;
            }

            SftSettings runSettings=settings;
            ThreadPool.QueueUserWorkItem(delegate
            {
                try
                {
                    string pdfPath=SftClient.CreateAndDownloadPdf(runSettings,workOrder);
                    BeginInvoke((MethodInvoker)delegate
                    {
                        try { using(SftPdfViewerForm viewer=new SftPdfViewerForm(pdfPath,workOrder)) viewer.ShowDialog(this); }
                        catch(Exception openEx)
                        {
                            MessageBox.Show(this,"Đã tạo PDF nhưng không mở được file.\r\n"+pdfPath+"\r\n"+openEx.Message,"SFT",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                        }
                        if(stChange!=null)
                        {
                            stChange.Text="SFT: đã tạo PDF công đơn "+workOrder;
                            stChange.ForeColor=Color.SeaGreen;
                        }
                    });
                }
                catch(Exception ex)
                {
                    BeginInvoke((MethodInvoker)delegate
                    {
                        if(stChange!=null)
                        {
                            stChange.Text="SFT: tạo PDF thất bại";
                            stChange.ForeColor=Color.Firebrick;
                        }
                        MessageBox.Show(this,
                            "Không tạo được công đơn SFT.\r\n\r\n"+ex.Message+"\r\n\r\nNếu tài khoản/mật khẩu đã đổi, chuột phải → Cấu hình SFT... để nhập lại.",
                            "Lỗi SFT",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
                    });
                }
            });
        }

        SftSettings LoadSftSettings()
        {
            try
            {
                using(RegistryKey key=Registry.CurrentUser.OpenSubKey(RegistryPath))
                {
                    if(key==null) return new SftSettings { CompanyId="EXWIN2026" };
                    string user=Convert.ToString(key.GetValue(RegistrySftUser,""));
                    string company=Convert.ToString(key.GetValue(RegistrySftCompany,"EXWIN2026"));
                    string enc=Convert.ToString(key.GetValue(RegistrySftPassword,""));
                    string pass="";
                    if(!string.IsNullOrWhiteSpace(enc))
                    {
                        try
                        {
                            byte[] protectedBytes=Convert.FromBase64String(enc);
                            byte[] clear=ProtectedData.Unprotect(protectedBytes,null,DataProtectionScope.CurrentUser);
                            pass=Encoding.UTF8.GetString(clear);
                        }
                        catch { pass=""; }
                    }
                    return new SftSettings { UserId=user,Password=pass,CompanyId=string.IsNullOrWhiteSpace(company)?"EXWIN2026":company };
                }
            }
            catch { return new SftSettings { CompanyId="EXWIN2026" }; }
        }

        void SaveSftSettings(SftSettings settings)
        {
            if(settings==null) return;
            using(RegistryKey key=Registry.CurrentUser.CreateSubKey(RegistryPath))
            {
                if(key==null) return;
                key.SetValue(RegistrySftUser,settings.UserId??"",RegistryValueKind.String);
                key.SetValue(RegistrySftCompany,string.IsNullOrWhiteSpace(settings.CompanyId)?"EXWIN2026":settings.CompanyId,RegistryValueKind.String);
                string enc="";
                if(!string.IsNullOrEmpty(settings.Password))
                {
                    byte[] clear=Encoding.UTF8.GetBytes(settings.Password);
                    byte[] protectedBytes=ProtectedData.Protect(clear,null,DataProtectionScope.CurrentUser);
                    enc=Convert.ToBase64String(protectedBytes);
                }
                key.SetValue(RegistrySftPassword,enc,RegistryValueKind.String);
            }
        }

        SftSettings ConfigureSft(bool showSavedNotice)
        {
            SftSettings old=LoadSftSettings();
            using(Form f=new Form())
            {
                f.Text="Cấu hình SFT";
                f.StartPosition=FormStartPosition.CenterParent;
                f.FormBorderStyle=FormBorderStyle.FixedDialog;
                f.MaximizeBox=false; f.MinimizeBox=false;
                f.ClientSize=new Size(430,230);
                f.Font=new Font("Segoe UI",10F);
                f.BackColor=Color.White;

                Label l1=new Label { Text="Tài khoản SFT",AutoSize=true,Location=new Point(24,26) };
                Label l2=new Label { Text="Mật khẩu",AutoSize=true,Location=new Point(24,76) };
                Label l3=new Label { Text="Công ty",AutoSize=true,Location=new Point(24,126) };
                TextBox tUser=new TextBox { Location=new Point(145,21),Width=245,Text=old.UserId??"" };
                TextBox tPass=new TextBox { Location=new Point(145,71),Width=245,UseSystemPasswordChar=true,Text=old.Password??"" };
                TextBox tCompany=new TextBox { Location=new Point(145,121),Width=245,Text=string.IsNullOrWhiteSpace(old.CompanyId)?"EXWIN2026":old.CompanyId };
                CheckBox showPass=new CheckBox { Text="Hiện mật khẩu",AutoSize=true,Location=new Point(145,151) };
                showPass.CheckedChanged += delegate { tPass.UseSystemPasswordChar=!showPass.Checked; };
                Button ok=new Button { Text="Lưu",DialogResult=DialogResult.OK,Width=90,Height=32,Location=new Point(205,185) };
                Button cancel=new Button { Text="Hủy",DialogResult=DialogResult.Cancel,Width=90,Height=32,Location=new Point(300,185) };
                f.AcceptButton=ok; f.CancelButton=cancel;
                f.Controls.AddRange(new Control[]{l1,l2,l3,tUser,tPass,tCompany,showPass,ok,cancel});

                if(f.ShowDialog(this)!=DialogResult.OK) return null;
                SftSettings result=new SftSettings { UserId=tUser.Text.Trim(),Password=tPass.Text,CompanyId=tCompany.Text.Trim() };
                if(!result.IsComplete)
                {
                    MessageBox.Show(this,"Hãy nhập đủ tài khoản, mật khẩu và công ty SFT.","SFT",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    return null;
                }
                SaveSftSettings(result);
                if(showSavedNotice) MessageBox.Show(this,"Đã lưu cấu hình SFT cho tài khoản Windows hiện tại.","SFT",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return result;
            }
        }

        void GridMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right) return;
            DataGridView.HitTestInfo hit = grid.HitTest(e.X, e.Y);
            if (hit.RowIndex >= 0)
            {
                grid.ClearSelection();
                grid.Rows[hit.RowIndex].Selected = true;
                grid.CurrentCell = grid.Rows[hit.RowIndex].Cells[0];
            }
        }

        string SelectedWorkOrder()
        {
            if (grid.CurrentRow == null || grid.CurrentRow.Cells["wo"].Value == null) return "";
            return Convert.ToString(grid.CurrentRow.Cells["wo"].Value).Trim();
        }


        void RoundControl(Control control, int radius)
        {
            if(control==null || control.Width<=0 || control.Height<=0) return;
            Rectangle r=new Rectangle(0,0,control.Width,control.Height);
            using(GraphicsPath path=RoundedRect(r,radius))
            {
                if(control.Region!=null) control.Region.Dispose();
                control.Region=new Region(path);
            }
        }

        GraphicsPath RoundedRect(Rectangle r, int radius)
        {
            int d=radius*2;
            GraphicsPath path=new GraphicsPath();
            path.StartFigure();
            path.AddArc(r.X,r.Y,d,d,180,90);
            path.AddArc(r.Right-d,r.Y,d,d,270,90);
            path.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);
            path.AddArc(r.X,r.Bottom-d,d,d,90,90);
            path.CloseFigure();
            return path;
        }

        void StyleRounded(Control control, int radius)
        {
            if(control==null) return;
            RoundControl(control,radius);
            control.Resize += delegate { RoundControl(control,radius); };
        }

        Label AddCard(FlowLayoutPanel p, string caption, string value)
        {
            var panel = new Panel { Width=205, Height=70, BackColor=Color.White, Margin=new Padding(5), Padding=new Padding(12) };
            StyleRounded(panel,10);
            var c = new Label { Text=caption, AutoSize=true, ForeColor=Color.DimGray, Location=new Point(11,8) };
            var v = new Label { Text=value, AutoEllipsis=true, Size=new Size(183,30), Font=new Font("Segoe UI Semibold",14F), ForeColor=Color.FromArgb(23,32,51), Location=new Point(10,32) };
            panel.Controls.Add(c); panel.Controls.Add(v); p.Controls.Add(panel); return v;
        }

        void ChooseFile()
        {
            using (var d = new OpenFileDialog { Filter="Excel (*.xlsx)|*.xlsx", Title="Chọn file CNC 5102" })
                if (d.ShowDialog(this)==DialogResult.OK) LoadFile(d.FileName, true);
        }

        void LoadSavedFile()
        {
            try
            {
                string p = "";
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(RegistryPath))
                {
                    if (key != null) p = Convert.ToString(key.GetValue(RegistryExcelValue, "")).Trim();
                }

                // Tự chuyển cấu hình cũ excel.cfg sang Windows Registry một lần rồi xóa file cũ.
                if (string.IsNullOrEmpty(p))
                {
                    string oldConfig = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "excel.cfg");
                    if (File.Exists(oldConfig))
                    {
                        p = File.ReadAllText(oldConfig).Trim();
                        if (!string.IsNullOrEmpty(p)) SaveExcelPathToRegistry(p);
                        try { File.Delete(oldConfig); } catch { }
                    }
                }

                if (File.Exists(p)) LoadFile(p, false);
            }
            catch { }
        }

        void SaveExcelPathToRegistry(string path)
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(RegistryPath))
            {
                if (key != null) key.SetValue(RegistryExcelValue, path ?? "", RegistryValueKind.String);
            }
        }

        void LoadFile(string path, bool save)
        {
            if(loadingFile) return;
            try
            {
                loadingFile=true;
                Cursor=Cursors.WaitCursor;
                WorkbookData data=XlsxReader.ReadAll(path);
                rows=data.WorkOrders; issues=data.Issues; receipts=data.Receipts;
                currentFile=path;
                try { currentFileWriteTime=File.GetLastWriteTime(path); } catch { currentFileWriteTime=DateTime.MinValue; }
                pendingFileWriteTime=DateTime.MinValue;
                pendingFileChangeSince=DateTime.MinValue;
                lblFile.Text=Path.GetFileName(path)+"  •  "+rows.Count.ToString("N0")+" công đơn";
                if(stFile!=null) stFile.Text="Excel: "+Path.GetFileName(path);
                if(stCount!=null) stCount.Text="Công đơn: "+rows.Count.ToString("N0");
                if(stLoaded!=null) stLoaded.Text="Nạp lúc: "+DateTime.Now.ToString("HH:mm:ss");
                if(stChange!=null) { stChange.Text="Đã cập nhật"; stChange.ForeColor=Color.SeaGreen; }
                if(save) SaveExcelPathToRegistry(path);
                Search();
            }
            catch(Exception ex)
            {
                if(stChange!=null) { stChange.Text="Lỗi đọc Excel"; stChange.ForeColor=Color.Firebrick; }
                MessageBox.Show("Không đọc được Excel:\n"+ex.Message,"Lỗi",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally { Cursor=Cursors.Default; loadingFile=false; }
        }

        void RefreshExcel()
        {
            if(string.IsNullOrWhiteSpace(currentFile) || !File.Exists(currentFile))
            {
                MessageBox.Show(this,"Chưa có file Excel để làm mới.","Thông báo",MessageBoxButtons.OK,MessageBoxIcon.Information);
                return;
            }
            LoadFile(currentFile,false);
        }

        void CheckExcelChanged()
        {
            if(loadingFile || string.IsNullOrWhiteSpace(currentFile) || !File.Exists(currentFile)) return;
            DateTime wt;
            try { wt=File.GetLastWriteTime(currentFile); } catch { return; }
            if(wt==currentFileWriteTime) { pendingFileWriteTime=DateTime.MinValue; pendingFileChangeSince=DateTime.MinValue; return; }

            if(pendingFileWriteTime!=wt)
            {
                pendingFileWriteTime=wt;
                pendingFileChangeSince=DateTime.Now;
                if(stChange!=null) { stChange.Text="Excel vừa thay đổi..."; stChange.ForeColor=Color.DarkOrange; }
                return;
            }

            // Chờ file ổn định vài giây rồi tự nạp lại, tránh đúng lúc Excel đang ghi file.
            if(pendingFileChangeSince!=DateTime.MinValue && (DateTime.Now-pendingFileChangeSince).TotalSeconds>=2)
            {
                string keepSearch=txtSearch==null ? "" : txtSearch.Text;
                LoadFile(currentFile,false);
                if(txtSearch!=null && txtSearch.Text!=keepSearch) txtSearch.Text=keepSearch;
            }
        }

        void Search()
        {
            if(searchDebounceTimer!=null) searchDebounceTimer.Stop();
            string q=(txtSearch.Text??"").Trim();
            if(rows.Count==0 || q.Length==0)
            {
                currentOrder=null;
                lastFinishNoticeWorkOrder="";
                lastMissingIssueNoticeWorkOrder="";
                lastExtraIssueNoticeWorkOrder="";
                lastSmartNoticeWorkOrder="";
                ClearDetails();
                ResetQuantityCheck();
                grid.Rows.Clear();
                SetConversionRate(0);
                return;
            }

            // Ưu tiên tìm theo công đơn như trước.
            WorkOrderRow found=rows.FirstOrDefault(x=>x.WorkOrder.Equals(q,StringComparison.OrdinalIgnoreCase));
            if(found==null)
                found=rows.FirstOrDefault(x=>x.WorkOrder.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0);

            bool customerSearch=false;
            List<WorkOrderRow> resultRows=null;

            // Nếu không khớp công đơn thì chuyển sang tìm theo Khách hàng.
            if(found==null)
            {
                if(q.Length<2)
                {
                    currentOrder=null;
                    ClearDetails();
                    grid.Rows.Clear();
                    SetConversionRate(0);
                    return;
                }

                resultRows=rows
                    .Where(x=>(CustomerMatches(x.Customer,q) || (!string.IsNullOrWhiteSpace(x.Spec) && x.Spec.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0)))
                    .OrderByDescending(x=>x.Status=="WAITING")
                    .ThenBy(x=>ShippingSortKey(x.ShippingDate))
                    .ThenBy(x=>x.Customer)
                    .ThenBy(x=>x.WorkOrder)
                    .ToList();

                if(resultRows.Count>0)
                {
                    customerSearch=true;
                    found=resultRows[0];

                    // Tìm khách hàng là chế độ nhiều kết quả:
                    // đổ thẳng danh sách ra grid, không gọi ShowDetails/ResetQuantityCheck
                    // để tránh các event của ô nhập xóa lại grid.
                    currentOrder=null;
                    lastSmartNoticeWorkOrder="";
                    ClearDetails();
                    SetConversionRate(0);
                    grid.Rows.Clear();

                    foreach(var x in resultRows)
                    {
                        int i=grid.Rows.Add(x.Status,x.WorkOrder,x.Material,x.Customer,x.Spec,x.ShippingDate,
                            F(x.OrderQty),F(x.IssuedQty),F(x.TransferQty),F(x.NgQty),F(x.NotOkQty),
                            F(CanTransferQty(x)),F(x.MissingIssueQty));

                        Color rowColor=Color.White;
                        if(x.Status.Equals("WAITING",StringComparison.OrdinalIgnoreCase))
                            rowColor=Color.FromArgb(255,245,225);
                        else if(x.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase))
                            rowColor=Color.FromArgb(235,250,240);

                        grid.Rows[i].DefaultCellStyle.BackColor=rowColor;
                        grid.Rows[i].DefaultCellStyle.SelectionBackColor=rowColor;
                        grid.Rows[i].DefaultCellStyle.SelectionForeColor=Color.Black;

                        DataGridViewCell canCell=grid.Rows[i].Cells["cantransfer"];
                        double can=CanTransferQty(x);
                        canCell.Style.Font=new Font("Segoe UI Semibold",9F,FontStyle.Bold);
                        if(can>0) canCell.Style.ForeColor=Color.SeaGreen;
                        else if(can<0) canCell.Style.ForeColor=Color.Firebrick;
                        else canCell.Style.ForeColor=Color.DimGray;
                    }

                    if(stChange!=null)
                    {
                        stChange.Text="Tìm khách hàng: "+q+" • "+resultRows.Count+" công đơn";
                        stChange.ForeColor=Color.SeaGreen;
                    }
                    return;
                }
            }

            if(found==null)
            {
                currentOrder=null;
                lastFinishNoticeWorkOrder="";
                lastMissingIssueNoticeWorkOrder="";
                lastExtraIssueNoticeWorkOrder="";
                lastSmartNoticeWorkOrder="";
                ClearDetails();
                ResetQuantityCheck();
                grid.Rows.Clear();
                SetConversionRate(0);
                if(stChange!=null)
                {
                    stChange.Text="Không tìm thấy: "+q;
                    stChange.ForeColor=Color.Firebrick;
                }
                return;
            }

            currentOrder=found;
            ResetQuantityCheck();
            ShowDetails(found);

            // Chỉ hiện thông báo thông minh khi đang tra theo công đơn.
            if(!customerSearch && q.Length>=9)
            {
                if(!lastSmartNoticeWorkOrder.Equals(found.WorkOrder,StringComparison.OrdinalIgnoreCase))
                {
                    lastSmartNoticeWorkOrder=found.WorkOrder;
                    ShowSmartOrderNotice(found);
                }
            }
            else
            {
                lastSmartNoticeWorkOrder="";
            }

            SetConversionRate(CalculateRate(found.Material));

            if(!customerSearch)
            {
                resultRows=rows.Where(x=>x.Material==found.Material)
                    .OrderByDescending(x=>x.Status=="WAITING")
                    .ThenBy(x=>ShippingSortKey(x.ShippingDate))
                    .ThenBy(x=>x.WorkOrder)
                    .ToList();
            }

            grid.Rows.Clear();
            foreach(var x in resultRows)
            {
                int i=grid.Rows.Add(x.Status,x.WorkOrder,x.Material,x.Customer,x.Spec,x.ShippingDate,F(x.OrderQty),F(x.IssuedQty),F(x.TransferQty),F(x.NgQty),F(x.NotOkQty),F(CanTransferQty(x)),F(x.MissingIssueQty));
                Color rowColor=Color.White;
                if(x.Status.Equals("WAITING",StringComparison.OrdinalIgnoreCase)) rowColor=Color.FromArgb(255,245,225);
                else if(x.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase)) rowColor=Color.FromArgb(235,250,240);
                grid.Rows[i].DefaultCellStyle.BackColor=rowColor;
                grid.Rows[i].DefaultCellStyle.SelectionBackColor=rowColor;
                grid.Rows[i].DefaultCellStyle.SelectionForeColor=Color.Black;

                DataGridViewCell canCell=grid.Rows[i].Cells["cantransfer"];
                double can=CanTransferQty(x);
                canCell.Style.Font=new Font("Segoe UI Semibold",9F,FontStyle.Bold);
                if(can>0) canCell.Style.ForeColor=Color.SeaGreen;
                else if(can<0) canCell.Style.ForeColor=Color.Firebrick;
                else canCell.Style.ForeColor=Color.DimGray;
            }

            if(customerSearch && stChange!=null)
            {
                stChange.Text="Tìm khách hàng: "+q+" • "+resultRows.Count+" công đơn";
                stChange.ForeColor=Color.SeaGreen;
            }
        }

        bool CustomerMatches(string customer,string query)
        {
            if(string.IsNullOrWhiteSpace(customer) || string.IsNullOrWhiteSpace(query)) return false;

            string c=customer.Trim();
            string q=query.Trim();

            // Khớp trực tiếp trước.
            if(c.IndexOf(q,StringComparison.OrdinalIgnoreCase)>=0) return true;

            // Cho phép cách gõ rút gọn theo từng phần.
            // Ví dụ: "mkt-246" vẫn khớp "222MKT-PI-246".
            // Tương tự với các mã khách hàng có phần chen giữa.
            string[] parts=q.Split(new[]{'-','_',' ','/','\\'},StringSplitOptions.RemoveEmptyEntries);
            if(parts.Length<2) return false;

            int pos=0;
            foreach(string raw in parts)
            {
                string part=raw.Trim();
                if(part.Length==0) continue;
                int hit=c.IndexOf(part,pos,StringComparison.OrdinalIgnoreCase);
                if(hit<0) return false;
                pos=hit+part.Length;
            }
            return true;
        }

        double CanTransferQty(WorkOrderRow x)
        {
            if(x==null) return 0;
            return x.IssuedQty - x.TransferQty - x.NgQty;
        }

        void ApplyCanTransferColor()
        {
            if(lblCanTransfer==null || currentOrder==null) return;
            double v=CanTransferQty(currentOrder);
            if(v>0) lblCanTransfer.ForeColor=Color.SeaGreen;
            else if(v<0) lblCanTransfer.ForeColor=Color.Firebrick;
            else lblCanTransfer.ForeColor=Color.DimGray;
            lblCanTransfer.Font=new Font("Segoe UI Semibold",14F,FontStyle.Bold);
        }

        void CopyText(string value, string name)
        {
            if(string.IsNullOrWhiteSpace(value) || value=="-")
            {
                if(stChange!=null) { stChange.Text="Chưa có "+name+" để copy"; stChange.ForeColor=Color.DimGray; }
                return;
            }
            try
            {
                Clipboard.SetText(value);
                if(stChange!=null) { stChange.Text="Đã copy "+name; stChange.ForeColor=Color.SeaGreen; }
            }
            catch
            {
                if(stChange!=null) { stChange.Text="Không copy được"; stChange.ForeColor=Color.Firebrick; }
            }
        }

        void ShowSmartOrderNotice(WorkOrderRow x)
        {
            if(x==null) return;
            List<string> lines=new List<string>();
            if(x.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase))
            {
                lines.Add("CÔNG ĐƠN ĐÃ FINISH");
                lines.Add("Đơn này đang dư " + F(x.NotOkQty) + " PCS.");
            }

            if(x.MissingIssueQty<0)
            {
                lines.Add("Công đơn chưa lĩnh đủ liệu.");
                lines.Add("Số lượng còn thiếu là " + F(Math.Abs(x.MissingIssueQty)) + " PCS");
                lines.Add("Chia Liệu Chú Ý Nhé !");
            }
            else if(x.MissingIssueQty>0)
            {
                lines.Add("Đơn Này Có Lĩnh Bù Liệu");
                lines.Add("Số Lượng là " + F(Math.Abs(x.MissingIssueQty)) + " PCS");
            }

            double can=CanTransferQty(x);
            lines.Add("SL có thể chuyển: " + F(can) + " PCS");

            if(lines.Count==1 && !x.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase) && x.MissingIssueQty==0) return;

            using(Form dlg=new Form())
            {
                dlg.Text="Thông báo công đơn";
                dlg.StartPosition=FormStartPosition.CenterParent;
                dlg.FormBorderStyle=FormBorderStyle.FixedDialog;
                dlg.MaximizeBox=false;
                dlg.MinimizeBox=false;
                dlg.ShowInTaskbar=false;
                dlg.ClientSize=new Size(650,240);

                PictureBox icon=new PictureBox();
                icon.Image=(x.MissingIssueQty!=0 ? SystemIcons.Warning : SystemIcons.Information).ToBitmap();
                icon.SizeMode=PictureBoxSizeMode.CenterImage;
                icon.Location=new Point(24,52);
                icon.Size=new Size(48,48);

                Label msg=new Label();
                msg.Text=string.Join("\r\n",lines.ToArray());
                msg.Font=new Font("Segoe UI",14F,FontStyle.Bold);
                msg.ForeColor=(x.MissingIssueQty!=0 ? Color.Firebrick : Color.FromArgb(24,35,52));
                msg.TextAlign=ContentAlignment.MiddleLeft;
                msg.AutoSize=false;
                msg.Location=new Point(88,22);
                msg.Size=new Size(535,155);

                Button ok=new Button();
                ok.Text="OK";
                ok.DialogResult=DialogResult.OK;
                ok.Size=new Size(90,30);
                ok.Location=new Point((dlg.ClientSize.Width-ok.Width)/2,190);

                dlg.Controls.Add(icon); dlg.Controls.Add(msg); dlg.Controls.Add(ok);
                dlg.AcceptButton=ok; dlg.CancelButton=ok;
                dlg.ShowDialog(this);
            }
        }

        double CalculateRate(string material)
        {
            // Quy đổi chỉ lấy từ cột Q của sheet 入库-转包装-转生管.
            // Tra theo MÃ LIỆU của công đơn đang tìm và lấy lần chuyển gần nhất
            // (dòng phát sinh nằm dưới cùng trong sheet).
            if(string.IsNullOrWhiteSpace(material)) return 0;
            ReceiptRow latest=receipts
                .Where(x=>x.Material.Equals(material,StringComparison.OrdinalIgnoreCase) && x.PcsPerKg>0)
                .OrderByDescending(x=>x.RowNumber)
                .FirstOrDefault();
            return latest==null ? 0 : latest.PcsPerKg;
        }

        double RoundConversionRate(double value)
        {
            if(value<=0) return value;

            // Giong dinh dang Excel #,##0.0: lam tron thong thuong 1 chu so thap phan.
            // 14.692 -> 14.7; 14.71 -> 14.7; 14.75 -> 14.8; 14.64 -> 14.6.
            return Math.Round(value,1,MidpointRounding.AwayFromZero);
        }

        List<double> GetRecentRates(string material)
        {
            if(string.IsNullOrWhiteSpace(material) || receipts==null) return new List<double>();
            return receipts
                .Where(x=>x.Material.Equals(material,StringComparison.OrdinalIgnoreCase) && x.PcsPerKg>0)
                .OrderByDescending(x=>x.RowNumber)
                .Select(x=>RoundConversionRate(x.PcsPerKg))
                .Take(5)
                .ToList();
        }

        void RefreshRecentRates()
        {
            if(recentRatesPanel==null) return;
            recentRatesPanel.Controls.Clear();
            if(currentOrder==null) return;

            foreach(double rate in GetRecentRates(currentOrder.Material))
            {
                double selectedRate=rate;
                Button b=new Button();
                b.Text=selectedRate.ToString("0.#",CultureInfo.GetCultureInfo("vi-VN"));
                b.Size=new Size(62,30);
                b.Margin=new Padding(2,0,2,0);
                b.FlatStyle=FlatStyle.Flat;
                b.FlatAppearance.BorderSize=1;
                b.Font=new Font("Segoe UI Semibold",9F);
                b.Cursor=Cursors.Hand;
                bool active=Math.Abs(selectedRate-currentRate)<0.0001;
                b.BackColor=active ? Color.FromArgb(41,98,255) : Color.White;
                b.ForeColor=active ? Color.White : Color.FromArgb(24,35,52);
                b.Click += delegate
                {
                    currentRate=selectedRate;
                    lblRate.Text=currentRate.ToString("0.#",CultureInfo.GetCultureInfo("vi-VN"));
                    if(txtManualRate!=null) txtManualRate.Visible=false;
                    lblRate.Visible=true;
                    conversionUpdating=true;
                    txtKg.Text="";
                    txtPcs.Text="";
                    conversionUpdating=false;
                    RefreshRecentRates();
                };
                recentRatesPanel.Controls.Add(b);
            }
        }

        void SetConversionRate(double rate)
        {
            // Chỉ hiện ô nhập tay khi đã nhập/chọn đúng công đơn và công đơn đó không có Q.
            // Khi chưa nhập công đơn, tìm khách hàng hoặc reset màn hình: giữ giao diện cũ.
            currentRate=rate>0 ? Math.Round(rate,1,MidpointRounding.AwayFromZero) : 0;

            bool hasWorkOrder=currentOrder!=null && !string.IsNullOrWhiteSpace(currentOrder.WorkOrder);
            bool manual=hasWorkOrder && currentRate<=0;

            lblRate.Visible=!manual;
            lblRate.Text=currentRate>0
                ? currentRate.ToString("0.#",CultureInfo.GetCultureInfo("vi-VN"))
                : "-";

            if(txtManualRate!=null)
            {
                conversionUpdating=true;
                txtManualRate.Text="";
                txtManualRate.Visible=manual;
                conversionUpdating=false;
                if(manual) txtManualRate.BringToFront();
            }

            RefreshRecentRates();

            conversionUpdating=true;
            txtKg.Text="";
            txtPcs.Text="";
            conversionUpdating=false;

            // Popup cũng chỉ hiện khi đúng công đơn đang chọn thực sự không có Q.
            if(manual)
                ShowNoConversionPopupIfNeeded(currentOrder.WorkOrder,currentRate);
        }

        void UpdateManualConversionRate()
        {
            if(conversionUpdating || txtManualRate==null || !txtManualRate.Visible) return;

            double rate;
            if(!TryNumber(txtManualRate.Text,out rate) || rate<=0)
            {
                currentRate=0;
                conversionUpdating=true;
                txtKg.Text="";
                txtPcs.Text="";
                conversionUpdating=false;
                return;
            }

            // Quy đổi nhập tay cũng tuân theo quy tắc làm tròn 1 số thập phân của app.
            currentRate=Math.Round(rate,1,MidpointRounding.AwayFromZero);

            // Nếu KG/PCS đã có sẵn thì tính lại ngay theo hệ số vừa nhập.
            if(!string.IsNullOrWhiteSpace(txtKg.Text)) ConvertFromKg();
            else if(!string.IsNullOrWhiteSpace(txtPcs.Text)) ConvertFromPcs();
        }

        void ConvertFromKg()
        {
            if(conversionUpdating || currentRate<=0) return;
            double kg;
            if(!TryNumber(txtKg.Text,out kg)) { conversionUpdating=true; txtPcs.Text=""; conversionUpdating=false; return; }

            // PCS chỉ lấy phần nguyên, bỏ phần thập phân: 749.6 -> 749.
            double pcs=Math.Truncate(kg*currentRate);
            string pcsText=pcs.ToString("0",CultureInfo.GetCultureInfo("vi-VN"));

            conversionUpdating=true;
            txtPcs.Text=pcsText;
            conversionUpdating=false;

            // Khi nhập KG, PCS tính ra sẽ tự điền vào ô Nhập SL.
            // Ô Nhập SL vẫn có thể sửa tay; chỉ bị cập nhật lại khi KG thay đổi tiếp.
            if(txtCheckQty!=null) txtCheckQty.Text=pcsText;
        }

        void ConvertFromPcs()
        {
            if(conversionUpdating || currentRate<=0) return;
            double pcs;
            if(!TryNumber(txtPcs.Text,out pcs)) { conversionUpdating=true; txtKg.Text=""; conversionUpdating=false; return; }
            if(!clearingLinkedInputs && txtCheckQty!=null)
            {
                long pcsInt=(long)Math.Truncate(pcs);
                txtCheckQty.Text=pcsInt.ToString(CultureInfo.InvariantCulture);
            }
            conversionUpdating=true;
            txtKg.Text=(pcs/currentRate).ToString("0.###",CultureInfo.GetCultureInfo("vi-VN"));
            conversionUpdating=false;
        }

        bool TryNumber(string text, out double value)
        {
            // Ô KG/PCS cho phép nhập cả 17.2 và 17,2.
            // Không dùng NumberStyles.Any với vi-VN vì dấu '.' có thể bị hiểu
            // là phân cách hàng nghìn (17.2 -> 172), làm kết quả sai 10 lần.
            string s=(text??"").Trim().Replace(" ","");
            value=0;
            if(s.Length==0) return false;

            int lastComma=s.LastIndexOf(',');
            int lastDot=s.LastIndexOf('.');

            if(lastComma>=0 && lastDot>=0)
            {
                // Có cả hai dấu: dấu xuất hiện sau cùng được xem là dấu thập phân.
                if(lastComma>lastDot)
                    s=s.Replace(".","").Replace(',', '.');
                else
                    s=s.Replace(",","");
            }
            else if(lastComma>=0)
            {
                // Chỉ có dấu phẩy: coi là dấu thập phân.
                s=s.Replace(',', '.');
            }
            // Chỉ có dấu chấm: giữ nguyên và coi là dấu thập phân.

            return double.TryParse(s,NumberStyles.AllowLeadingSign|NumberStyles.AllowDecimalPoint,CultureInfo.InvariantCulture,out value);
        }

        void ResetQuantityCheck()
        {
            if(txtCheckQty==null || lblQtyCheck==null || lblQtyCheckIssued==null) return;
            txtCheckQty.Text="";
            lblQtyCheck.Text="Nhập SL để kiểm tra";
            lblQtyCheck.ForeColor=Color.DimGray;
            lblQtyCheckIssued.Text="Nhập SL để kiểm tra";
            lblQtyCheckIssued.ForeColor=Color.DimGray;
            RestoreQuantityPreviewCards();
        }

        void ClearLinkedQuantityInputs()
        {
            if(clearingLinkedInputs) return;
            clearingLinkedInputs=true;
            try
            {
                if(txtKg!=null) txtKg.Text="";
                if(txtPcs!=null) txtPcs.Text="";
                if(txtCheckQty!=null) txtCheckQty.Text="";
            }
            finally
            {
                clearingLinkedInputs=false;
            }
        }

        void RestoreQuantityPreviewCards()
        {
            if(currentOrder==null) return;

            if(lblTransfer!=null)
                lblTransfer.Text=F(currentOrder.TransferQty);

            if(lblNotOk!=null)
            {
                lblNotOk.Text=F(currentOrder.NotOkQty);
                lblNotOk.ForeColor=currentOrder.NotOkQty<0 ? Color.Firebrick : Color.SeaGreen;
            }

            if(lblCanTransfer!=null)
            {
                double can=CanTransferQty(currentOrder);
                lblCanTransfer.Text=F(can);
                if(can>0) lblCanTransfer.ForeColor=Color.SeaGreen;
                else if(can<0) lblCanTransfer.ForeColor=Color.Firebrick;
                else lblCanTransfer.ForeColor=Color.DimGray;
                lblCanTransfer.Font=new Font("Segoe UI Semibold",14F,FontStyle.Bold);
            }
        }

        void ApplyQuantityPreviewCards(double added)
        {
            if(currentOrder==null) return;

            double transferPreview=currentOrder.TransferQty + added;
            double notOkPreview=transferPreview - currentOrder.OrderQty;
            double canTransferPreview=currentOrder.IssuedQty - transferPreview - currentOrder.NgQty;

            if(lblTransfer!=null)
                lblTransfer.Text=F(transferPreview);

            if(lblNotOk!=null)
            {
                lblNotOk.Text=F(notOkPreview);
                lblNotOk.ForeColor=notOkPreview<0 ? Color.Firebrick : Color.SeaGreen;
            }

            if(lblCanTransfer!=null)
            {
                lblCanTransfer.Text=F(canTransferPreview);
                if(canTransferPreview>0) lblCanTransfer.ForeColor=Color.SeaGreen;
                else if(canTransferPreview<0) lblCanTransfer.ForeColor=Color.Firebrick;
                else lblCanTransfer.ForeColor=Color.DimGray;
                lblCanTransfer.Font=new Font("Segoe UI Semibold",14F,FontStyle.Bold);
            }
        }

        void UpdateQuantityCheck()
        {
            if(lblQtyCheck==null || lblQtyCheckIssued==null) return;
            if(currentOrder==null)
            {
                overInputWarningShown=false;

                lblQtyCheck.Text="Chưa có công đơn";
                lblQtyCheck.ForeColor=Color.DimGray;
                lblQtyCheckIssued.Text="Chưa có công đơn";
                lblQtyCheckIssued.ForeColor=Color.DimGray;
                lblQtyCheckIssued.Font=new Font("Segoe UI Semibold",12F,FontStyle.Regular);
                return;
            }

            double added;
            if(!TryNumber(txtCheckQty==null ? "" : txtCheckQty.Text,out added))
            {
                overInputWarningShown=false;
                RestoreQuantityPreviewCards();

                lblQtyCheck.Text="Nhập SL để kiểm tra";
                lblQtyCheck.ForeColor=Color.DimGray;
                lblQtyCheckIssued.Text="Nhập SL để kiểm tra";
                lblQtyCheckIssued.ForeColor=Color.DimGray;
                lblQtyCheckIssued.Font=new Font("Segoe UI Semibold",12F,FontStyle.Regular);
                return;
            }

            ApplyQuantityPreviewCards(added);

            double byOrder=currentOrder.TransferQty + added - currentOrder.OrderQty;
            SetQuantityResult(lblQtyCheck, byOrder);

            double byIssued=currentOrder.TransferQty + added - currentOrder.IssuedQty + currentOrder.NgQty;
            if(byIssued > 0)
            {
                lblQtyCheckIssued.Font=new Font("Segoe UI Semibold",12F,FontStyle.Regular);
                SetQuantityResult(lblQtyCheckIssued, byIssued);
                if(!overInputWarningShown)
                {
                    overInputWarningShown=true;
                    ShowOverInputWarning();
                }
            }
            else
            {
                overInputWarningShown=false;
                lblQtyCheckIssued.Font=new Font("Segoe UI Semibold",12F,FontStyle.Regular);
                SetQuantityResult(lblQtyCheckIssued, byIssued);
            }
        }

        void ShowFinishWarning(double notOkQty, double theoLinhLieu)
        {
            using(Form dlg=new Form())
            {
                dlg.Text="Thông báo công đơn FINISH";
                dlg.StartPosition=FormStartPosition.CenterParent;
                dlg.FormBorderStyle=FormBorderStyle.FixedDialog;
                dlg.MaximizeBox=false;
                dlg.MinimizeBox=false;
                dlg.ShowInTaskbar=false;
                dlg.ClientSize=new Size(650,190);

                PictureBox infoIcon=new PictureBox();
                infoIcon.Image=SystemIcons.Information.ToBitmap();
                infoIcon.SizeMode=PictureBoxSizeMode.CenterImage;
                infoIcon.Location=new Point(24,48);
                infoIcon.Size=new Size(48,48);

                Label msg=new Label();
                msg.Text="Đơn này đang dư " + F(notOkQty) + " PCS.\r\nCó thể chuyển thêm " + F(Math.Abs(theoLinhLieu)) + " PCS hoặc chuyển sang đơn khác.";
                msg.Font=new Font("Segoe UI",14F,FontStyle.Bold);
                msg.TextAlign=ContentAlignment.MiddleLeft;
                msg.AutoSize=false;
                msg.Location=new Point(86,25);
                msg.Size=new Size(540,100);

                Button ok=new Button();
                ok.Text="OK";
                ok.DialogResult=DialogResult.OK;
                ok.Size=new Size(90,30);
                ok.Location=new Point((dlg.ClientSize.Width-ok.Width)/2,140);

                dlg.Controls.Add(infoIcon);
                dlg.Controls.Add(msg);
                dlg.Controls.Add(ok);
                dlg.AcceptButton=ok;
                dlg.CancelButton=ok;
                dlg.ShowDialog(this);
            }
        }

        void ShowExtraIssueWarning(double qty)
        {
            using(Form dlg=new Form())
            {
                dlg.Text="Thông báo lĩnh bù liệu";
                dlg.StartPosition=FormStartPosition.CenterParent;
                dlg.FormBorderStyle=FormBorderStyle.FixedDialog;
                dlg.MaximizeBox=false;
                dlg.MinimizeBox=false;
                dlg.ShowInTaskbar=false;
                dlg.ClientSize=new Size(570,175);

                PictureBox warningIcon=new PictureBox();
                warningIcon.Image=SystemIcons.Warning.ToBitmap();
                warningIcon.SizeMode=PictureBoxSizeMode.CenterImage;
                warningIcon.Location=new Point(24,42);
                warningIcon.Size=new Size(48,48);

                Label msg=new Label();
                msg.Text="Đơn Này Có Lĩnh Bù Liệu\r\nSố Lượng là " + F(Math.Abs(qty)) + " PCS";
                msg.ForeColor=Color.Firebrick;
                msg.Font=new Font("Segoe UI",14F,FontStyle.Bold);
                msg.TextAlign=ContentAlignment.MiddleLeft;
                msg.AutoSize=false;
                msg.Location=new Point(86,22);
                msg.Size=new Size(460,85);

                Button ok=new Button();
                ok.Text="OK";
                ok.DialogResult=DialogResult.OK;
                ok.Size=new Size(90,30);
                ok.Location=new Point((dlg.ClientSize.Width-ok.Width)/2,125);

                dlg.Controls.Add(warningIcon);
                dlg.Controls.Add(msg);
                dlg.Controls.Add(ok);
                dlg.AcceptButton=ok;
                dlg.CancelButton=ok;
                dlg.ShowDialog(this);
            }
        }

        void ShowMissingIssueWarning(double missingQty)
        {
            using(Form dlg=new Form())
            {
                dlg.Text="Cảnh báo lĩnh liệu";
                dlg.StartPosition=FormStartPosition.CenterParent;
                dlg.FormBorderStyle=FormBorderStyle.FixedDialog;
                dlg.MaximizeBox=false;
                dlg.MinimizeBox=false;
                dlg.ShowInTaskbar=false;
                dlg.ClientSize=new Size(570,205);

                PictureBox warningIcon=new PictureBox();
                warningIcon.Image=SystemIcons.Warning.ToBitmap();
                warningIcon.SizeMode=PictureBoxSizeMode.CenterImage;
                warningIcon.Location=new Point(24,42);
                warningIcon.Size=new Size(48,48);

                Label msg=new Label();
                msg.Text="Công đơn chưa lĩnh đủ liệu.\r\nSố lượng còn thiếu là " + F(Math.Abs(missingQty)) + " PCS\r\nChia Liệu Chú Ý Nhé !";
                msg.ForeColor=Color.Firebrick;
                msg.Font=new Font("Segoe UI",14F,FontStyle.Bold);
                msg.TextAlign=ContentAlignment.MiddleLeft;
                msg.AutoSize=false;
                msg.Location=new Point(86,18);
                msg.Size=new Size(460,115);

                Button ok=new Button();
                ok.Text="OK";
                ok.DialogResult=DialogResult.OK;
                ok.Size=new Size(90,30);
                ok.Location=new Point((dlg.ClientSize.Width-ok.Width)/2,155);

                dlg.Controls.Add(warningIcon);
                dlg.Controls.Add(msg);
                dlg.Controls.Add(ok);
                dlg.AcceptButton=ok;
                dlg.CancelButton=ok;
                dlg.ShowDialog(this);
            }
        }

        void ShowOverInputWarning()
        {
            using(Form dlg=new Form())
            {
                dlg.Text="Cảnh báo số lượng";
                dlg.StartPosition=FormStartPosition.CenterParent;
                dlg.FormBorderStyle=FormBorderStyle.FixedDialog;
                dlg.MaximizeBox=false;
                dlg.MinimizeBox=false;
                dlg.ShowInTaskbar=false;
                dlg.ClientSize=new Size(650,150);

                PictureBox warningIcon=new PictureBox();
                warningIcon.Image=SystemIcons.Warning.ToBitmap();
                warningIcon.SizeMode=PictureBoxSizeMode.CenterImage;
                warningIcon.Location=new Point(25,34);
                warningIcon.Size=new Size(48,48);

                Label msg=new Label();
                msg.Text="Không Thể Chuyển Vượt Quá Số Lượng Đầu Vào Hãy Kiểm Tra Lại";
                msg.ForeColor=Color.Firebrick;
                msg.Font=new Font("Segoe UI",13F,FontStyle.Bold);
                msg.TextAlign=ContentAlignment.MiddleLeft;
                msg.AutoSize=false;
                msg.Location=new Point(82,20);
                msg.Size=new Size(548,70);

                Button ok=new Button();
                ok.Text="OK";
                ok.DialogResult=DialogResult.OK;
                ok.Size=new Size(90,30);
                ok.Location=new Point((dlg.ClientSize.Width-ok.Width)/2,105);

                dlg.Controls.Add(warningIcon);
                dlg.Controls.Add(msg);
                dlg.Controls.Add(ok);
                dlg.AcceptButton=ok;
                dlg.CancelButton=ok;
                dlg.ShowDialog(this);
            }
        }

        void SetQuantityResult(Label label, double result)
        {
            if(Math.Abs(result)<0.000001)
            {
                label.Text="ĐỦ  •  Còn lại: 0 PCS";
                label.ForeColor=Color.SeaGreen;
            }
            else if(result<0)
            {
                label.Text="THIẾU "+F(Math.Abs(result))+" PCS";
                label.ForeColor=Color.Firebrick;
            }
            else
            {
                label.Text="THỪA "+F(result)+" PCS";
                label.ForeColor=Color.FromArgb(41,98,255);
            }
        }

        void ShowIssueDetails(string workOrder)
        {
            if(string.IsNullOrWhiteSpace(workOrder)) return;
            var list=issues.Where(x=>x.WorkOrder.Equals(workOrder,StringComparison.OrdinalIgnoreCase)).ToList();
            string[] headers={"Ngày lĩnh","Công đơn","Mã liệu","Quy cách","SL đầu vào","SL lĩnh","KG","ERP","Khách hàng"};
            List<object[]> values=new List<object[]>();
            foreach(var x in list) values.Add(new object[]{x.Date,x.WorkOrder,x.Material,x.Spec,F(x.InputQty),F(x.IssuedQty),F3(x.Kg),x.ErpNote,x.Customer});
            ShowDetailForm("CHI TIẾT LĨNH LIỆU - "+workOrder,headers,values,"Tổng lĩnh: "+F(list.Sum(x=>x.IssuedQty))+" PCS     Tổng KG: "+F3(list.Sum(x=>x.Kg)));
        }

        void ShowReceiptDetails(string workOrder)
        {
            if(string.IsNullOrWhiteSpace(workOrder)) return;
            var list=receipts.Where(x=>x.WorkOrder.Equals(workOrder,StringComparison.OrdinalIgnoreCase)).ToList();
            string[] headers={"Ngày chuyển","Công đơn","Mã liệu","Quy cách","Đơn vị","SL chuyển XLN","KG","Trạng thái","LINE","Quy đổi PCS/KG","Ghi chú"};
            List<object[]> values=new List<object[]>();
            foreach(var x in list) values.Add(new object[]{x.Date,x.WorkOrder,x.Material,x.Spec,x.Unit,F(x.Qty),F3(x.Kg),x.Status,x.Line,x.PcsPerKg>0?Math.Round(x.PcsPerKg,1,MidpointRounding.AwayFromZero).ToString("0.#",CultureInfo.GetCultureInfo("vi-VN")):"",x.Note});
            double totalQty=list.Sum(x=>x.Qty), totalKg=list.Sum(x=>x.Kg);
            double rate=totalKg>0?totalQty/totalKg:0;
            string summary="Tổng chuyển XLN: "+F(totalQty)+" PCS     Tổng KG: "+F3(totalKg)+(rate>0?"     Quy đổi: "+rate.ToString("N3",CultureInfo.GetCultureInfo("vi-VN"))+" PCS/KG":"");
            ShowDetailForm("CHI TIẾT CHUYỂN XLN - "+workOrder,headers,values,summary);
        }


        void ShowShippingSchedule(string workOrder)
        {
            if(string.IsNullOrWhiteSpace(workOrder)) return;
            WorkOrderRow selected=rows.FirstOrDefault(x=>x.WorkOrder.Equals(workOrder,StringComparison.OrdinalIgnoreCase));
            if(selected==null) return;

            var list=rows.Where(x=>x.Material.Equals(selected.Material,StringComparison.OrdinalIgnoreCase))
                         .OrderBy(x=>ShippingSortKey(x.ShippingDate))
                         .ThenBy(x=>x.WorkOrder)
                         .ToList();
            string[] headers={"Lịch xuất hàng","Công đơn","Mã liệu","Trạng thái","SL đơn","Chưa OK","Khách hàng"};
            List<object[]> values=new List<object[]>();
            foreach(var x in list)
                values.Add(new object[]{x.ShippingDate,x.WorkOrder,x.Material,x.Status,F(x.OrderQty),F(x.NotOkQty),x.Customer});

            string next=list.Where(x=>ShippingSortKey(x.ShippingDate)!=DateTime.MaxValue && ShippingSortKey(x.ShippingDate).Date>=DateTime.Today)
                            .Select(x=>x.ShippingDate).FirstOrDefault();
            string summary="Mã liệu: "+selected.Material+"     Tổng công đơn: "+list.Count.ToString("N0")+
                           (string.IsNullOrEmpty(next)?"":"     Lịch gần nhất: "+next);
            ShowDetailForm("LỊCH XUẤT HÀNG - "+selected.Material,headers,values,summary);
        }

        DateTime ShippingSortKey(string value)
        {
            DateTime d;
            if(DateTime.TryParseExact(value,"dd/MM/yyyy",CultureInfo.InvariantCulture,DateTimeStyles.None,out d)) return d;
            return DateTime.MaxValue;
        }

        void ShowDetailForm(string title, string[] headers, List<object[]> rowsData, string summary)
        {
            Form f=new Form();
            f.Text=title; f.StartPosition=FormStartPosition.CenterParent; f.Size=new Size(1180,650); f.MinimumSize=new Size(900,500); f.Font=new Font("Segoe UI",10F); f.BackColor=Color.FromArgb(244,247,251);
            Label head=new Label { Text=title, Dock=DockStyle.Top, Height=52, Padding=new Padding(18,15,0,0), Font=new Font("Segoe UI Semibold",15F), BackColor=Color.White, ForeColor=Color.FromArgb(24,35,52) };
            Label sum=new Label { Text=summary, Dock=DockStyle.Bottom, Height=46, Padding=new Padding(18,12,0,0), Font=new Font("Segoe UI Semibold",10.5F), BackColor=Color.White, ForeColor=Color.FromArgb(24,35,52) };
            DataGridView g=new DataGridView { Dock=DockStyle.Fill, ReadOnly=true, AllowUserToAddRows=false, AllowUserToDeleteRows=false, RowHeadersVisible=false, SelectionMode=DataGridViewSelectionMode.FullRowSelect, MultiSelect=false, BackgroundColor=Color.White, BorderStyle=BorderStyle.None, AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill };
            g.DefaultCellStyle.SelectionBackColor=Color.White;
            g.DefaultCellStyle.SelectionForeColor=Color.Black;
            g.DefaultCellStyle.ForeColor=Color.Black;
            foreach(string h in headers) g.Columns.Add("c"+g.Columns.Count.ToString(),h);

            foreach(DataGridViewColumn c in g.Columns)
            {
                c.MinimumWidth=70;
                if(c.HeaderText=="Công đơn")
                {
                    c.MinimumWidth=150;
                    c.FillWeight=145F;
                }
                else if(c.HeaderText=="Mã liệu")
                {
                    c.MinimumWidth=180;
                    c.FillWeight=165F;
                }
                else if(c.HeaderText=="Khách hàng")
                {
                    c.MinimumWidth=190;
                    c.FillWeight=160F;
                }
                else if(c.HeaderText=="Quy cách")
                {
                    c.MinimumWidth=150;
                    c.FillWeight=125F;
                }
                else if(c.HeaderText=="ERP")
                {
                    c.MinimumWidth=120;
                    c.FillWeight=110F;
                }
                else
                {
                    c.FillWeight=100F;
                }
            }

            // Riêng bảng XLN hôm nay: thu gọn các cột vừa nội dung để dành chỗ cho Trạng thái.
            if(title.StartsWith("ĐÃ CHUYỂN XLN HÔM NAY",StringComparison.OrdinalIgnoreCase))
            {
                foreach(DataGridViewColumn c in g.Columns) c.MinimumWidth=45;
                for(int ci=0;ci<g.Columns.Count;ci++)
                {
                    DataGridViewColumn c=g.Columns[ci];
                    if(c.HeaderText=="Ngày chuyển")          c.FillWeight=80F;
                    else if(c.HeaderText=="Công đơn")       c.FillWeight=135F;
                    else if(c.HeaderText=="Mã liệu")        c.FillWeight=155F;
                    else if(c.HeaderText=="Quy cách")       c.FillWeight=145F;
                    else if(c.HeaderText=="SL chuyển XLN")  c.FillWeight=90F;
                    else if(c.HeaderText=="KG")             c.FillWeight=65F;
                    else if(c.HeaderText=="Trạng thái")     { c.FillWeight=175F; c.MinimumWidth=175; }
                    else if(c.HeaderText=="Quy đổi PCS/KG") c.FillWeight=85F;
                    else if(c.HeaderText=="Ghi chú")        c.FillWeight=95F;
                }
            }

            foreach(object[] v in rowsData) g.Rows.Add(v);

            int statusCol=-1;
            for(int ci=0;ci<g.Columns.Count;ci++)
                if(g.Columns[ci].HeaderText=="Trạng thái") { statusCol=ci; break; }

            if(statusCol>=0)
            {
                foreach(DataGridViewRow row in g.Rows)
                {
                    string st=Convert.ToString(row.Cells[statusCol].Value);
                    if(string.Equals(st,"FINISH",StringComparison.OrdinalIgnoreCase))
                    {
                        row.Cells[statusCol].Style.ForeColor=Color.SeaGreen;
                        row.Cells[statusCol].Style.Font=new Font("Segoe UI Semibold",10F,FontStyle.Bold);
                    }
                    else if(st.StartsWith("Còn thiếu:",StringComparison.OrdinalIgnoreCase))
                    {
                        row.Cells[statusCol].Style.ForeColor=Color.Firebrick;
                        row.Cells[statusCol].Style.Font=new Font("Segoe UI Semibold",10F,FontStyle.Bold);
                    }
                }
            }

            if(rowsData.Count==0)
            {
                Label empty=new Label { Text="Không có dữ liệu cho công đơn này.", Dock=DockStyle.Fill, TextAlign=ContentAlignment.MiddleCenter, Font=new Font("Segoe UI",13F), ForeColor=Color.DimGray };
                f.Controls.Add(empty); empty.BringToFront();
            }
            f.Controls.Add(g); f.Controls.Add(sum); f.Controls.Add(head);
            f.ShowDialog(this);
        }

        void ShowDetails(WorkOrderRow x)
        {
            lblMaterial.Text=x.Material; lblCustomer.Text=string.IsNullOrWhiteSpace(x.Customer)?"-":x.Customer; lblSpec.Text=string.IsNullOrWhiteSpace(x.Spec)?"-":x.Spec; lblStatus.Text=x.Status; lblOrder.Text=F(x.OrderQty); lblInput.Text=F(x.InputQty); lblIssued.Text=F(x.IssuedQty); lblTransfer.Text=F(x.TransferQty); lblNg.Text=F(x.NgQty); lblNotOk.Text=F(x.NotOkQty);
            lblCanTransfer.Text=F(CanTransferQty(x));
            ApplyCanTransferColor(); lblMissingIssue.Text=F(x.MissingIssueQty); lblShipping.Text=string.IsNullOrWhiteSpace(x.ShippingDate)?"-":x.ShippingDate;
            lblStatus.ForeColor=x.Status.Equals("FINISH",StringComparison.OrdinalIgnoreCase)?Color.SeaGreen:Color.DarkOrange;
            lblNotOk.ForeColor=x.NotOkQty<0?Color.Firebrick:Color.SeaGreen;
            lblMissingIssue.ForeColor=x.MissingIssueQty>0?Color.Firebrick:Color.SeaGreen;
        }

        void ClearDetails()
        {
            foreach(var l in new[]{lblMaterial,lblCustomer,lblSpec,lblStatus,lblOrder,lblInput,lblIssued,lblTransfer,lblNg,lblNotOk,lblCanTransfer,lblMissingIssue,lblShipping}) if(l!=null) l.Text="-";
        }

        string F(double v){ return v.ToString("N0",CultureInfo.GetCultureInfo("vi-VN")); }
        string F3(double v){ return v.ToString("N3",CultureInfo.GetCultureInfo("vi-VN")); }
        string FormatKgCompact(double v){ return v.ToString("0.###",CultureInfo.GetCultureInfo("vi-VN")); }
    }
}