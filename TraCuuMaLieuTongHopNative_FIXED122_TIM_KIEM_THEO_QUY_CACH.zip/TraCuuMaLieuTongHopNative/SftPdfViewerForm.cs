using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace TraCuuMaLieuTongHopNative
{
    internal sealed class SftPdfViewerForm : Form
    {
        readonly string pdfPath;
        readonly string workOrder;

        public SftPdfViewerForm(string path, string order)
        {
            pdfPath = path;
            workOrder = order;
            Text = "Công đơn SFT - " + workOrder;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(480, 150);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            if (Application.OpenForms.Count > 0) Icon = Application.OpenForms[0].Icon;

            Label l = new Label();
            l.Text = "Đang mở PDF công đơn bằng WebView2...";
            l.AutoSize = true;
            l.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            l.Location = new Point(25, 30);
            Controls.Add(l);

            Shown += delegate { BeginInvoke((MethodInvoker)LaunchWebView2Viewer); };
        }

        void LaunchWebView2Viewer()
        {
            try
            {
                string helper = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "SftPdfViewer.exe");
                if (!File.Exists(helper))
                {
                    MessageBox.Show(this,
                        "Thiếu SftPdfViewer.exe.\r\nHãy chạy BUILD.bat để build cả bộ WebView2.",
                        "SFT", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    Close();
                    return;
                }

                string args = Quote(pdfPath) + " " + Quote(workOrder);
                Process.Start(new ProcessStartInfo
                {
                    FileName = helper,
                    Arguments = args,
                    UseShellExecute = true
                });
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Không mở được WebView2 PDF Viewer.\r\n" + ex.Message,
                    "SFT", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Close();
            }
        }

        static string Quote(string s)
        {
            if (s == null) s = "";
            return "\"" + s.Replace("\"", "\\\"") + "\"";
        }
    }
}
