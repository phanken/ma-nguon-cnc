using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;

namespace TraCuuMaLieuTongHopNative
{
    internal sealed class SftSettings
    {
        public string UserId;
        public string Password;
        public string CompanyId;

        public bool IsComplete
        {
            get { return !string.IsNullOrWhiteSpace(UserId) && !string.IsNullOrWhiteSpace(Password) && !string.IsNullOrWhiteSpace(CompanyId); }
        }
    }

    internal static class SftClient
    {
        const string Host = "http://192.168.3.5:8100";
        const string SftRoot = Host + "/SFT";
        const string CenterPage = SftRoot + "/main/centerPage/centerPage.jsp?locale=vi_VN";
        const string UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36";

        public static string CreateAndDownloadPdf(SftSettings settings, string workOrder)
        {
            if(settings == null || !settings.IsComplete) throw new InvalidOperationException("Chưa cấu hình tài khoản SFT.");
            if(string.IsNullOrWhiteSpace(workOrder)) throw new InvalidOperationException("Công đơn trống.");

            ServicePointManager.Expect100Continue = false;
            CookieContainer cookies = new CookieContainer();

            // Tạo session SFT trước khi đăng nhập.
            GetText(SftRoot + "/login.jsp?locale=vi_VN", cookies, null);

            string loginUrl = SftRoot + "/loginInside.jsp?loginTo=SFT&language=vi_VN"
                + "&password=" + Uri.EscapeDataString(settings.Password)
                + "&userID=" + Uri.EscapeDataString(settings.UserId)
                + "&AUTH_ID=" + Uri.EscapeDataString(settings.UserId)
                + "&companyid=" + Uri.EscapeDataString(settings.CompanyId);

            GetText(loginUrl, cookies, SftRoot + "/login.jsp?locale=vi_VN");

            CookieCollection cc = cookies.GetCookies(new Uri(SftRoot + "/"));
            string jsession = "";
            foreach(Cookie c in cc)
            {
                if(string.Equals(c.Name, "JSESSIONID", StringComparison.OrdinalIgnoreCase))
                {
                    jsession = c.Value;
                    break;
                }
            }
            if(string.IsNullOrWhiteSpace(jsession))
                throw new InvalidOperationException("SFT không trả về JSESSIONID sau khi đăng nhập.");

            // Browser SFT có cookie company_select; đặt lại để request DWR giống trình duyệt.
            try
            {
                cookies.Add(new Uri(SftRoot + "/"), new Cookie("company_select", settings.CompanyId, "/SFT"));
            }
            catch { }

            string batchId = DateTime.Now.ToString("HHmmssfff");
            string scriptSessionId = Guid.NewGuid().ToString("N").ToUpperInvariant() + new Random().Next(1000, 9999).ToString();
            string body = BuildDwrBody(settings.CompanyId, workOrder.Trim(), jsession, scriptSessionId, batchId);
            string dwrUrl = SftRoot + "/dwr/call/plaincall/RouteForm.createForm.dwr";
            string response = PostText(dwrUrl, body, cookies, CenterPage);

            Match m = Regex.Match(response ?? "", "[\\\"']([^\\\"']*SFTC01[^\\\"']*\\.pdf)[\\\"']", RegexOptions.IgnoreCase);
            if(!m.Success)
            {
                string shortResponse = (response ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
                if(shortResponse.Length > 500) shortResponse = shortResponse.Substring(0, 500) + "...";
                throw new InvalidOperationException("SFT chưa tạo được PDF. Phản hồi: " + shortResponse);
            }

            string pdfName = m.Groups[1].Value;
            string pdfUrl = SftRoot + "/report/" + Uri.EscapeDataString(pdfName);
            byte[] pdf = GetBytes(pdfUrl, cookies, CenterPage);
            if(pdf == null || pdf.Length < 4 || pdf[0] != 0x25 || pdf[1] != 0x50 || pdf[2] != 0x44 || pdf[3] != 0x46)
                throw new InvalidOperationException("SFT đã tạo tên file nhưng nội dung tải về không phải PDF.");

            string safeWo = Regex.Replace(workOrder, "[^0-9A-Za-z_-]", "_");
            string localPath = Path.Combine(Path.GetTempPath(), "SFT_" + safeWo + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".pdf");
            File.WriteAllBytes(localPath, pdf);
            return localPath;
        }

        static string BuildDwrBody(string companyId, string workOrder, string httpSessionId, string scriptSessionId, string batchId)
        {
            // Payload bắt trực tiếp từ SFT RouteForm.createForm.dwr.
            List<string> p = new List<string>();
            p.Add("callCount=1");
            p.Add("page=/SFT/main/centerPage/centerPage.jsp?locale=vi_VN");
            p.Add("httpSessionId=" + httpSessionId);
            p.Add("scriptSessionId=" + scriptSessionId);
            p.Add("c0-scriptName=RouteForm");
            p.Add("c0-methodName=createForm");
            p.Add("c0-id=0");
            p.Add("c0-param0=string:" + companyId);
            p.Add("c0-param1=string:perpendi");
            p.Add("c0-e2=string:PLANPROCESSST");
            p.Add("c0-e3=string:");
            p.Add("c0-e1=Array:[reference:c0-e2,reference:c0-e3]");
            p.Add("c0-e5=string:PLANPROCESSST");
            p.Add("c0-e6=string:");
            p.Add("c0-e4=Array:[reference:c0-e5,reference:c0-e6]");
            p.Add("c0-e8=string:CMOID");
            p.Add("c0-e9=string:");
            p.Add("c0-e7=Array:[reference:c0-e8,reference:c0-e9]");
            p.Add("c0-e11=string:CMOID");
            p.Add("c0-e12=string:");
            p.Add("c0-e10=Array:[reference:c0-e11,reference:c0-e12]");
            p.Add("c0-e14=string:CMOID");
            p.Add("c0-e15=string:'" + workOrder.Replace("'", "") + "'");
            p.Add("c0-e13=Array:[reference:c0-e14,reference:c0-e15]");
            p.Add("c0-e17=string:moStatusStr");
            p.Add("c0-e18=string:");
            p.Add("c0-e16=Array:[reference:c0-e17,reference:c0-e18]");
            p.Add("c0-e20=string:EXECUTEQTY");
            p.Add("c0-e21=string:");
            p.Add("c0-e19=Array:[reference:c0-e20,reference:c0-e21]");
            p.Add("c0-e23=string:MO040");
            p.Add("c0-e24=string:N");
            p.Add("c0-e22=Array:[reference:c0-e23,reference:c0-e24]");
            p.Add("c0-param2=Array:[reference:c0-e1,reference:c0-e4,reference:c0-e7,reference:c0-e10,reference:c0-e13,reference:c0-e16,reference:c0-e19,reference:c0-e22]");
            p.Add("c0-param3=string:%7B%22isWithNetFlow%22%3A%22-1%22%2C%22withDataCollector%22%3Afalse%2C%22printtype%22%3A%22normal%22%2C%22language%22%3A%22vi_VN%22%2C%22PRINTUSERINFORM%22%3Atrue%2C%22checksplit_checkbox%22%3Afalse%2C%22PRINTSTAFFINFORM%22%3Afalse%7D");
            p.Add("batchId=" + batchId);
            return string.Join("\n", p.ToArray());
        }

        static HttpWebRequest NewRequest(string url, CookieContainer cookies, string referer)
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.CookieContainer = cookies;
            req.UserAgent = UserAgent;
            req.Accept = "*/*";
            req.AllowAutoRedirect = true;
            req.Timeout = 15000;
            req.ReadWriteTimeout = 15000;
            req.KeepAlive = true;
            if(!string.IsNullOrWhiteSpace(referer)) req.Referer = referer;
            return req;
        }

        static string GetText(string url, CookieContainer cookies, string referer)
        {
            HttpWebRequest req = NewRequest(url, cookies, referer);
            req.Method = "GET";
            using(HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
            using(StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8, true))
                return sr.ReadToEnd();
        }

        static string PostText(string url, string body, CookieContainer cookies, string referer)
        {
            byte[] data = Encoding.UTF8.GetBytes(body ?? "");
            HttpWebRequest req = NewRequest(url, cookies, referer);
            req.Method = "POST";
            req.ContentType = "text/plain";
            req.ContentLength = data.Length;
            using(Stream s = req.GetRequestStream()) s.Write(data, 0, data.Length);
            try
            {
                using(HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                using(StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8, true))
                    return sr.ReadToEnd();
            }
            catch(WebException ex)
            {
                string detail = "";
                try
                {
                    HttpWebResponse er = ex.Response as HttpWebResponse;
                    if(er != null)
                    {
                        using(StreamReader sr = new StreamReader(er.GetResponseStream(), Encoding.UTF8, true)) detail = sr.ReadToEnd();
                    }
                }
                catch { }
                throw new InvalidOperationException("Lỗi gọi SFT DWR: " + ex.Message + (string.IsNullOrWhiteSpace(detail) ? "" : "\r\n" + detail), ex);
            }
        }

        static byte[] GetBytes(string url, CookieContainer cookies, string referer)
        {
            HttpWebRequest req = NewRequest(url, cookies, referer);
            req.Method = "GET";
            using(HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
            using(Stream s = resp.GetResponseStream())
            using(MemoryStream ms = new MemoryStream())
            {
                byte[] buf = new byte[8192];
                int n;
                while((n = s.Read(buf, 0, buf.Length)) > 0) ms.Write(buf, 0, n);
                return ms.ToArray();
            }
        }
    }
}
