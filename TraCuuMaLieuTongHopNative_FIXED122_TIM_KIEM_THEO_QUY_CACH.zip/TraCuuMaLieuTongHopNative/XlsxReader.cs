﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Packaging;
using System.Linq;
using System.Xml.Linq;

namespace TraCuuMaLieuTongHopNative
{
    public sealed class WorkOrderRow
    {
        public string Status = "";
        public string WorkOrder = "";
        public string Material = "";
        public string ProductName = "";
        public string Spec = "";
        public string Customer = "";
        public string ShippingDate = "";
        public double OrderQty;
        public double InputQty;
        public double IssuedQty;
        public double TransferQty;
        public double MissingReturnQty;
        public double NgQty;
        public double NotOkQty;
        public double MissingIssueQty;
    }

    public sealed class IssueRow
    {
        public string Date = "";
        public string WorkOrder = "";
        public string Material = "";
        public string ProductName = "";
        public string Spec = "";
        public double InputQty;
        public double IssuedQty;
        public double Kg;
        public string ErpNote = "";
        public string Customer = "";
    }

    public sealed class ReceiptRow
    {
        public int RowNumber;
        public string Date = "";
        public string WorkOrder = "";
        public string Material = "";
        public string ProductName = "";
        public string Spec = "";
        public string Unit = "";
        public double Qty;
        public double Kg;
        public string Status = "";
        public string Note = "";
        public string Line = "";
        public double PcsPerKg;
        public double RateR;
        public double RateDiffS;
    }

    public sealed class WorkbookData
    {
        public List<WorkOrderRow> WorkOrders = new List<WorkOrderRow>();
        public List<IssueRow> Issues = new List<IssueRow>();
        public List<ReceiptRow> Receipts = new List<ReceiptRow>();
    }

    public static class XlsxReader
    {
        static readonly XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        static readonly XNamespace relNs = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        static readonly XNamespace pkgRelNs = "http://schemas.openxmlformats.org/package/2006/relationships";

        public static WorkbookData ReadAll(string path)
        {
            string tempPath = Path.Combine(Path.GetTempPath(), "TraCuuMaLieu_" + Guid.NewGuid().ToString("N") + ".xlsx");
            try
            {
                // Copy first so the original workbook can stay open in Excel.
                using (FileStream input = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (FileStream output = new FileStream(tempPath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    input.CopyTo(output);
                }

                using (Package package = Package.Open(tempPath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    List<string> shared = LoadSharedStrings(package);
                    WorkbookData data = new WorkbookData();
                    data.WorkOrders = ReadWorkOrders(package, shared);
                    data.Issues = ReadIssues(package, shared);
                    data.Receipts = ReadReceipts(package, shared);
                    return data;
                }
            }
            finally
            {
                try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { }
            }
        }

        public static List<WorkOrderRow> ReadWorkOrders(string path)
        {
            return ReadAll(path).WorkOrders;
        }

        static List<WorkOrderRow> ReadWorkOrders(Package package, List<string> shared)
        {
            List<Dictionary<int, string>> sheet = ReadSheet(package, shared, "工单");
            List<WorkOrderRow> result = new List<WorkOrderRow>();
            foreach (Dictionary<int, string> cells in sheet)
            {
                int r = ParseInt(Get(cells, 0));
                if (r < 4) continue;
                string wo = Get(cells, 7).Trim();
                if (string.IsNullOrWhiteSpace(wo) || wo.IndexOf("Công", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                result.Add(new WorkOrderRow
                {
                    Status = Get(cells, 5).Trim(),
                    WorkOrder = wo,
                    Material = Get(cells, 8).Trim(),
                    ProductName = Get(cells, 9).Trim(),
                    Spec = Get(cells, 10).Trim(),
                    Customer = Get(cells, 6).Trim(),
                    ShippingDate = ShippingDate(Get(cells, 21)),
                    OrderQty = Num(Get(cells, 11)),
                    InputQty = Num(Get(cells, 12)),
                    IssuedQty = Num(Get(cells, 13)),
                    TransferQty = Num(Get(cells, 14)),
                    MissingReturnQty = Num(Get(cells, 15)),
                    NgQty = Num(Get(cells, 17)),
                    NotOkQty = Num(Get(cells, 18)),
                    MissingIssueQty = Num(Get(cells, 22))
                });
            }
            return result;
        }

        static List<IssueRow> ReadIssues(Package package, List<string> shared)
        {
            // Workbook sheet name contains a trailing space: "领料 ".
            List<Dictionary<int, string>> sheet = ReadSheet(package, shared, "领料 ");
            List<IssueRow> result = new List<IssueRow>();
            foreach (Dictionary<int, string> cells in sheet)
            {
                int r = ParseInt(Get(cells, 0));
                if (r < 4) continue;
                string wo = Get(cells, 5).Trim();
                if (string.IsNullOrWhiteSpace(wo)) continue;
                result.Add(new IssueRow
                {
                    Date = ExcelDate(Get(cells, 4)),
                    WorkOrder = wo,
                    Material = Get(cells, 6).Trim(),
                    ProductName = Get(cells, 7).Trim(),
                    Spec = Get(cells, 8).Trim(),
                    InputQty = Num(Get(cells, 9)),
                    IssuedQty = Num(Get(cells, 10)),
                    Kg = Num(Get(cells, 11)),
                    ErpNote = Get(cells, 12).Trim(),
                    Customer = Get(cells, 13).Trim()
                });
            }
            return result;
        }

        static List<ReceiptRow> ReadReceipts(Package package, List<string> shared)
        {
            List<Dictionary<int, string>> sheet = ReadSheet(package, shared, "入库-转包装-转生管");
            List<ReceiptRow> result = new List<ReceiptRow>();
            foreach (Dictionary<int, string> cells in sheet)
            {
                int r = ParseInt(Get(cells, 0));
                if (r < 6) continue;
                string wo = Get(cells, 6).Trim();
                if (string.IsNullOrWhiteSpace(wo)) continue;
                result.Add(new ReceiptRow
                {
                    RowNumber = r,
                    Date = ExcelDate(Get(cells, 5)),
                    WorkOrder = wo,
                    Material = Get(cells, 7).Trim(),
                    ProductName = Get(cells, 8).Trim(),
                    Spec = Get(cells, 9).Trim(),
                    Unit = Get(cells, 10).Trim(),
                    Qty = Num(Get(cells, 11)),
                    Kg = Num(Get(cells, 12)),
                    Status = Get(cells, 13).Trim(),
                    Note = Get(cells, 14).Trim(),
                    Line = Get(cells, 16).Trim(),
                    PcsPerKg = Num(Get(cells, 17)),
                    RateR = Num(Get(cells, 18)),
                    RateDiffS = Num(Get(cells, 19))
                });
            }
            return result;
        }

        // Each returned dictionary stores the Excel row number at key 0, cells at 1-based column numbers.
        static List<Dictionary<int, string>> ReadSheet(Package package, List<string> shared, string sheetName)
        {
            string sheetPath = ResolveSheetPath(package, sheetName);
            PackagePart part = GetPart(package, sheetPath);
            if (part == null) throw new Exception("Không tìm thấy sheet " + sheetName + ".");
            XDocument doc;
            using (Stream s = part.GetStream(FileMode.Open, FileAccess.Read)) doc = XDocument.Load(s);

            List<Dictionary<int, string>> result = new List<Dictionary<int, string>>();
            foreach (XElement row in doc.Descendants(ns + "row"))
            {
                Dictionary<int, string> cells = new Dictionary<int, string>();
                cells[0] = ((string)row.Attribute("r") ?? "0");
                foreach (XElement c in row.Elements(ns + "c"))
                {
                    string cellRef = (string)c.Attribute("r") ?? "";
                    int col = ColumnNumber(cellRef);
                    string type = (string)c.Attribute("t") ?? "";
                    string val = "";
                    if (type == "inlineStr")
                        val = string.Concat(c.Descendants(ns + "t").Select(x => x.Value).ToArray());
                    else
                    {
                        XElement v = c.Element(ns + "v");
                        val = v == null ? "" : v.Value;
                        if (type == "s")
                        {
                            int idx;
                            if (int.TryParse(val, out idx) && idx >= 0 && idx < shared.Count) val = shared[idx];
                        }
                    }
                    cells[col] = val;
                }
                result.Add(cells);
            }
            return result;
        }

        static PackagePart GetPart(Package package, string path)
        {
            Uri uri = PackUriHelper.CreatePartUri(new Uri("/" + path.TrimStart('/'), UriKind.Relative));
            return package.PartExists(uri) ? package.GetPart(uri) : null;
        }

        static List<string> LoadSharedStrings(Package package)
        {
            List<string> list = new List<string>();
            PackagePart part = GetPart(package, "xl/sharedStrings.xml");
            if (part == null) return list;
            XDocument doc;
            using (Stream s = part.GetStream(FileMode.Open, FileAccess.Read)) doc = XDocument.Load(s);
            foreach (XElement si in doc.Descendants(ns + "si"))
                list.Add(string.Concat(si.Descendants(ns + "t").Select(x => x.Value).ToArray()));
            return list;
        }

        static string ResolveSheetPath(Package package, string sheetName)
        {
            PackagePart wbPart = GetPart(package, "xl/workbook.xml");
            PackagePart relPart = GetPart(package, "xl/_rels/workbook.xml.rels");
            if (wbPart == null || relPart == null) throw new Exception("File Excel không hợp lệ.");

            XDocument wb, rel;
            using (Stream s = wbPart.GetStream(FileMode.Open, FileAccess.Read)) wb = XDocument.Load(s);
            using (Stream s = relPart.GetStream(FileMode.Open, FileAccess.Read)) rel = XDocument.Load(s);

            XElement sh = wb.Descendants(ns + "sheet").FirstOrDefault(x => ((string)x.Attribute("name") ?? "") == sheetName);
            if (sh == null) throw new Exception("Không tìm thấy sheet " + sheetName + ".");
            string rid = (string)sh.Attribute(relNs + "id") ?? "";
            XElement rr = rel.Descendants(pkgRelNs + "Relationship").FirstOrDefault(x => ((string)x.Attribute("Id") ?? "") == rid);
            if (rr == null) throw new Exception("Không đọc được liên kết sheet.");
            string target = (string)rr.Attribute("Target") ?? "";
            if (target.StartsWith("/")) return target.TrimStart('/');
            return "xl/" + target.Replace("\\", "/").TrimStart('/');
        }

        static int ColumnNumber(string cellRef)
        {
            int n = 0;
            foreach (char ch in cellRef)
            {
                if (!char.IsLetter(ch)) break;
                n = n * 26 + (char.ToUpperInvariant(ch) - 'A' + 1);
            }
            return n;
        }

        static string ExcelDate(string s)
        {
            double serial;
            if (double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out serial) && serial > 1 && serial < 100000)
            {
                try { return DateTime.FromOADate(serial).ToString("dd/MM/yyyy"); } catch { }
            }
            return s == null ? "" : s.Trim();
        }

        static string ShippingDate(string s)
        {
            string value=(s ?? "").Trim();
            if(value.Length==0 || value=="0" || value.StartsWith("#")) return "-";
            double serial;
            if(double.TryParse(value,NumberStyles.Any,CultureInfo.InvariantCulture,out serial) && serial>1 && serial<100000)
            {
                try { return DateTime.FromOADate(serial).ToString("dd/MM/yyyy"); } catch { }
            }
            return value;
        }

        static string Get(Dictionary<int, string> d, int c) { string v; return d.TryGetValue(c, out v) ? v : ""; }
        static int ParseInt(string s) { int v; return int.TryParse(s, out v) ? v : 0; }
        static double Num(string s)
        {
            double v;
            if (double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out v)) return v;
            if (double.TryParse(s, NumberStyles.Any, CultureInfo.CurrentCulture, out v)) return v;
            return 0;
        }
    }
}
