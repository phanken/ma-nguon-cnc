@echo off
call "%~dp0BUILD.bat"
if errorlevel 1 exit /b 1
start "" "%~dp0bin\Release\TraCuuMaLieuTongHopNative.exe"
