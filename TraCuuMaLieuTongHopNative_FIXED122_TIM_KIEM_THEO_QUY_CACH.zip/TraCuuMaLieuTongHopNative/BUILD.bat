@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo   BUILD CHIA DON 5102 - MAIN APP ONLY
echo ==========================================
echo.
echo SftPdfViewer.exe da co san - KHONG build lai Viewer.
echo.

set "MSBUILD=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\MSBuild.exe"
if exist "%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe" set "MSBUILD=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe"

if not exist "%MSBUILD%" (
    echo KHONG TIM THAY MSBuild .NET Framework 4.0.
    pause
    exit /b 1
)

"%MSBUILD%" "TraCuuMaLieuTongHopNative.csproj" /t:Rebuild /p:Configuration=Release
if errorlevel 1 (
    echo.
    echo BUILD THAT BAI.
    pause
    exit /b 1
)

echo.
echo BUILD THANH CONG.
echo File app: bin\Release\TraCuuMaLieuTongHopNative.exe
if exist "bin\Release\SftPdfViewer.exe" (
    echo SftPdfViewer.exe: GIU NGUYEN FILE CO SAN.
) else (
    echo CANH BAO: bin\Release\SftPdfViewer.exe chua co.
    echo Hay copy SftPdfViewer.exe da co san vao bin\Release.
)
echo.
pause
