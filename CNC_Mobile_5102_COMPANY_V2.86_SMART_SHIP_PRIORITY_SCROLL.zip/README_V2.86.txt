CNC Mobile 5102 - V2.86 SMART SHIP PRIORITY SCROLL

Baseline: V2.85

Moi trong V2.86:
- Khi tra cong don, so sanh lich xuat cua cong don dang tra voi cac don WAITING cung ma lieu.
- Neu cong don dang tra co lich xuat gan nhat (ke ca trung ngay gan nhat): tu dong cuon xuong Chia don nhu cu.
- Neu co don WAITING cung ma lieu co lich xuat som hon: tu dong cuon xuong Don WAITING cung ma lieu.
- Cong don co lich xuat som nhat trong danh sach se duoc danh dau mau do + nhan 'Lich xuat gan nhat'.
- Neu cong don dang tra chua co lich xuat ma co don WAITING cung ma lieu co lich: uu tien cuon den danh sach WAITING.
- Giu nguyen NG, 5 so quy doi gan nhat, nhap quy doi thu cong khi thieu, Save Gate, SFT, Assistant va cache schema hien tai.

Cach cap nhat:
1. Dung server cu.
2. Ghi de bo file V2.86 vao thu muc dang chay.
3. GIU NGUYEN thu muc CACHE va config.json hien tai.
4. Chay UNBLOCK_ALL.bat neu Windows chan file.
5. Chay START_ALL.bat.
