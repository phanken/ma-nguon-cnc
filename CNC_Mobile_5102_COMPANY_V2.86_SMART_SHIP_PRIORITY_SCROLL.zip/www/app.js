const $=s=>document.querySelector(s), wo=$('#wo'), btn=$('#search'), msg=$('#message'), result=$('#result'), divideWrap=$('#divideWrap'), same=$('#same'), sameWrap=$('#sameWrap');
const fmt=n=>new Intl.NumberFormat('vi-VN',{maximumFractionDigits:2}).format(Number(n||0));
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
let pin=localStorage.getItem('cnc_pin')||'';
function showPin(){ $('#pinModal').classList.remove('hidden'); $('#pin').value=pin; setTimeout(()=>$('#pin').focus(),50) }
function hidePin(){ $('#pinModal').classList.add('hidden') }
if(!pin) showPin();
$('#savePin').onclick=()=>{pin=$('#pin').value.trim();if(pin){localStorage.setItem('cnc_pin',pin);hidePin();wo.focus();loadDashboard()}};
$('#changePin').onclick=showPin; $('#pin').addEventListener('keydown',e=>{if(e.key==='Enter')$('#savePin').click()});
function item(k,v,wide=false,cls=''){return `<div class="item ${wide?'wide':''}"><div class="k">${k}</div><div class="v ${cls}">${esc(v||'-')}</div></div>`}
function renderTarget(x){
 const status=(x.status||'').toLowerCase();
 let note='';
 if(x.status==='FINISH') note=`<div class="alert green">✅ Đơn này đã hoàn thành. SL chưa OK: ${fmt(x.notOkQty)} PCS</div>`;
 else if(Number(x.issueDiff)<0) note=`<div class="alert red">⚠️ Công đơn chưa lĩnh đủ liệu. Còn thiếu ${fmt(Math.abs(x.issueDiff))} PCS.</div>`;
 else if(Number(x.issueDiff)>0) note=`<div class="alert green">ℹ️ Đơn này có lĩnh bù liệu: ${fmt(x.issueDiff)} PCS.</div>`;
 result.innerHTML=`<div class="card"><div class="title-row"><div><div class="wo">${esc(x.workOrder)}</div><div class="material">${esc(x.material)}</div></div><span class="status ${status}">${esc(x.status)}</span></div><button class="print-sft-btn" data-print-wo="${esc(x.workOrder)}" type="button">🖨️ In công đơn SFT</button><div class="detail-actions"><button class="detail-btn issue-detail-btn" data-detail-wo="${esc(x.workOrder)}" type="button">📦 Chi tiết lĩnh liệu</button><button class="detail-btn xln-detail-btn" data-detail-wo="${esc(x.workOrder)}" type="button">⇄ Chi tiết chuyển XLN</button></div><div class="print-sft-status" id="printSftStatus"></div>${note}<div class="grid">
 ${item('Khách hàng',x.customer,true)}${item('Tên VL',x.materialName,true)}${item('Quy cách',x.spec,true)}${item('SL đơn hàng',fmt(x.orderQty),false,'num')}${item('SL đầu vào',fmt(x.inputQty),false,'num')}${item('Đã lĩnh liệu',fmt(x.issuedQty),false,'num')}${item('Chuyển KH',fmt(x.transferredQty),false,'num')}${item('Thiếu trả XLN',fmt(x.missingReturnXLN),false,'num')}${item('NG',fmt(x.ngQty),false,'num')}${item('SL chưa OK',fmt(x.notOkQty),false,'num')}${item('Lĩnh liệu thiếu',fmt(x.issueDiff),false,'num')}${item('Lịch xuất hàng',x.shipDate||'-',true)}
 </div></div>`; result.classList.remove('hidden');
}
function parseShipDate(v){
 const m=String(v||'').trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
 if(!m)return null;
 const d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]));
 return Number.isNaN(d.getTime())?null:d;
}
function getNearestSameMaterial(target,arr){
 const list=Array.isArray(arr)?arr:[];
 const targetDate=parseShipDate(target?.shipDate);
 let nearest=null, nearestDate=null;
 for(const x of list){
   const d=parseShipDate(x?.shipDate);
   if(!d)continue;
   if(!nearestDate || d<nearestDate){nearest=x;nearestDate=d;}
 }
 if(!nearest||!nearestDate)return {scrollTo:'divide',highlightWo:''};
 // Nếu công đơn đang tra không có lịch xuất, hoặc có công đơn WAITING cùng mã liệu xuất sớm hơn -> ưu tiên danh sách WAITING.
 if(!targetDate || nearestDate<targetDate)return {scrollTo:'same',highlightWo:String(nearest.workOrder||'')};
 // Cùng ngày cũng xem công đơn đang tra là một trong các đơn gần nhất.
 return {scrollTo:'divide',highlightWo:''};
}
function renderSame(arr,highlightWo=''){
 if(!arr||!arr.length){sameWrap.classList.add('hidden');return}
 $('#sameCount').textContent=`(${arr.length})`;
 same.innerHTML=arr.map(x=>{const nearest=highlightWo&&String(x.workOrder||'')===String(highlightWo);return `<div class="mini waiting-pick${nearest?' nearest-ship':''}" data-wo="${esc(x.workOrder)}" role="button" tabindex="0" title="Chạm đúp để chia đơn"><div class="mini-head"><span class="mini-wo">${esc(x.workOrder)}</span><span class="status waiting">WAITING</span></div>${nearest?'<div class="nearest-ship-label">🔥 Lịch xuất gần nhất</div>':''}<div class="mini-grid"><span>Đơn hàng: <b>${fmt(x.orderQty)}</b></span><span>Chưa OK: <b>${fmt(x.notOkQty)}</b></span><span>Lĩnh liệu: <b>${fmt(x.issuedQty)}</b></span><span>NG: <b>${fmt(x.ngQty)}</b></span><span>Lịch xuất: <b>${esc(x.shipDate||'-')}</b></span></div><div class="double-hint">Chạm đúp để chia đơn</div></div>`}).join('');
 sameWrap.classList.remove('hidden');
 bindWaitingPick();
}

let printCopies=1, printWorkOrder='';
function openPrintCopies(w){
 printWorkOrder=w; printCopies=1;
 const n=$('#printCopiesNum'), title=$('#printCopiesWo'), go=$('#printCopiesGo');
 if(n)n.textContent='1'; if(title)title.textContent=w; if(go)go.textContent='🖨️ In 1 bản';
 $('#printCopiesModal').classList.remove('hidden');
}
function closePrintCopies(){ $('#printCopiesModal').classList.add('hidden') }
function setPrintCopies(v){
 printCopies=Math.max(1,Math.min(10,Number(v)||1));
 $('#printCopiesNum').textContent=String(printCopies);
 $('#printCopiesGo').textContent=`🖨️ In ${printCopies} bản`;
}
async function doPrintSft(){
 const w=printWorkOrder.trim(); if(!w)return;
 const copies=printCopies; closePrintCopies();
 const b=document.querySelector('.print-sft-btn'), st=$('#printSftStatus');
 if(b){b.disabled=true;b.textContent='⏳ Đang gửi lệnh...'}
 if(st){st.className='print-sft-status working';st.textContent=`Đang gửi lệnh in ${copies} bản...`}
 try{
   const ac=new AbortController(); const tm=setTimeout(()=>ac.abort(),8000);
   let r;
   try{
     r=await fetch('/api/print-sft?workOrder='+encodeURIComponent(w)+'&copies='+copies,{headers:{'X-CNC-PIN':pin},cache:'no-store',signal:ac.signal});
   } finally { clearTimeout(tm); }
   const j=await r.json().catch(()=>({}));
   if(r.status===401){showPin();throw new Error(j.error||'PIN không đúng')}
   if(!r.ok)throw new Error((j.error||'In công đơn thất bại')+(j.log?' • Log: '+j.log:''));
   if(st){st.className='print-sft-status ok';st.textContent=j.queued?`✅ Đã nhận lệnh in ${j.copies||copies} bản ${w}. Đang xử lý nền, có thể tiếp tục dùng web.`:`✅ Đã gửi in ${j.copies||copies} bản ${w}`}
 }catch(e){if(st){st.className='print-sft-status err';st.textContent='❌ '+e.message}}
 finally{if(b){b.disabled=false;b.textContent='🖨️ In công đơn SFT'}}
}
function bindPrintSft(){
 const b=document.querySelector('.print-sft-btn');
 if(!b)return;
 b.addEventListener('click',()=>{const w=(b.dataset.printWo||'').trim();if(w)openPrintCopies(w)});
}
function initPrintCopies(){
 const modal=$('#printCopiesModal'); if(!modal)return;
 $('#printCopiesMinus').onclick=()=>setPrintCopies(printCopies-1);
 $('#printCopiesPlus').onclick=()=>setPrintCopies(printCopies+1);
 $('#printCopiesCancel').onclick=closePrintCopies;
 $('#printCopiesGo').onclick=doPrintSft;
 modal.addEventListener('click',e=>{if(e.target===modal)closePrintCopies()});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initPrintCopies);else initPrintCopies();

async function search(scrollToDivide=false){
 let v=wo.value.trim(); if(!v)return; if(!pin){showPin();return} btn.disabled=true;btn.textContent='...';msg.innerHTML='';result.classList.add('hidden');divideWrap.classList.add('hidden');sameWrap.classList.add('hidden');
 try{const r=await fetch('/api/search?workOrder='+encodeURIComponent(v),{headers:{'X-CNC-PIN':pin}});const j=await r.json();if(r.status===401){showPin();throw new Error(j.error||'PIN không đúng')}if(!r.ok)throw new Error(j.error||'Không tìm thấy');const nav=getNearestSameMaterial(j.target,j.waitingSameMaterial);renderTarget(j.target);bindPrintSft();renderDivide(j.target);renderSame(j.waitingSameMaterial,nav.highlightWo);$('#updated').textContent='Excel cập nhật: '+j.sourceUpdated;loadDashboard();if(scrollToDivide)setTimeout(()=>{const el=nav.scrollTo==='same'?sameWrap:divideWrap;el.scrollIntoView({behavior:'smooth',block:'start'});},100);}
 catch(e){msg.innerHTML=`<div class="msg">${esc(e.message)}</div>`}finally{btn.disabled=false;btn.textContent='Tìm'}
}
btn.onclick=()=>search(true);
let autoSearchTimer=0, lastAutoSearch='';
wo.addEventListener('keydown',e=>{if(e.key==='Enter')search(true)});
// Nhận công đơn từ CNC Assistant: /?workOrder=5102-260814006
function loadWorkOrderFromUrl(){
 try{
   const params=new URLSearchParams(window.location.search);
   const raw=(params.get('workOrder')||params.get('wo')||'').trim();
   if(!raw)return;
   wo.value=raw;
   if(pin){ setTimeout(()=>search(),80); }
   else{
     const wait=setInterval(()=>{ if(pin){clearInterval(wait);search();} },200);
     setTimeout(()=>clearInterval(wait),15000);
   }
 }catch(e){}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',loadWorkOrderFromUrl);else loadWorkOrderFromUrl();

wo.addEventListener('input',()=>{
 const raw=wo.value.trim();
 const digits=raw.replace(/\D/g,'');
 const isNine=/^\d{9}$/.test(raw);
 const isFull5102=/^5102-?\d{9}$/i.test(raw);
 if(!isNine&&!isFull5102){lastAutoSearch='';clearTimeout(autoSearchTimer);return}
 const key=isNine?raw:('5102-'+digits.slice(-9));
 if(key===lastAutoSearch)return;
 clearTimeout(autoSearchTimer);
 autoSearchTimer=setTimeout(()=>{
   const now=wo.value.trim();
   if(!(/^\d{9}$/.test(now)||/^5102-?\d{9}$/i.test(now)))return;
   lastAutoSearch=key;
   search(true);
 },180);
});

let waitingTapTimer=0, waitingTapWo='';
function openWaitingForDivide(card){
 const w=(card?.dataset?.wo||'').trim();
 if(!w)return;
 wo.value=w;
 search(true);
}
function bindWaitingPick(){
 same.querySelectorAll('.waiting-pick').forEach(card=>{
   card.addEventListener('dblclick',e=>{e.preventDefault();openWaitingForDivide(card)});
   card.addEventListener('touchend',e=>{
     const now=Date.now(), w=(card.dataset.wo||'');
     if(waitingTapWo===w && now-waitingTapTimer<430){
       e.preventDefault();
       waitingTapTimer=0;waitingTapWo='';
       openWaitingForDivide(card);
     }else{
       waitingTapTimer=now;waitingTapWo=w;
     }
   },{passive:false});
   card.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();openWaitingForDivide(card)}});
 });
}


function setSys(id,ok,text){const e=$(id);if(!e)return;e.className=ok?'sys-ok':'sys-err';e.textContent='● '+text}
async function loadDashboard(){
 if(!pin)return;
 try{
  const r=await fetch('/api/dashboard?_='+Date.now(),{headers:{'X-CNC-PIN':pin},cache:'no-store'});
  const j=await r.json(); if(r.status===401)return; if(!r.ok)throw new Error('dashboard');
  $('#dashboard').classList.remove('hidden');
  $('#dashWaiting').textContent=fmt(j.waitingTotal); $('#dashShortage').textContent=fmt(j.shortageCount); $('#dashToday').textContent=fmt(j.shipTodayCount);
  $('#dashNearest').textContent=j.nearestShipCount?fmt(j.nearestShipCount):'--';
  $('#dashNearestLabel').textContent=j.nearestShipDate?'Gần nhất '+j.nearestShipDate:'Chưa có lịch';
  $('#dashUpdated').textContent='Excel '+(j.sourceUpdated||'');
  const reload=$('#excelReload');
  if(reload){
    const busy=!!j.excelReloading;
    reload.classList.toggle('hidden',!busy);
    if(busy){ const t=$('#excelReloadTime'); if(t)t.textContent=fmt(j.excelReloadSeconds||0)+'s'; }
  }
  const ch=$('#excelChange'), c=j.latestExcelChange;
  if(ch){
    ch.classList.toggle('hidden',!c || !!j.excelReloading);
    if(c && !j.excelReloading){
      const sm=c.summary||{}, parts=[];
      if(c.baseline){
        $('#excelChangeTitle').textContent=`✓ Đã khởi tạo baseline · ${c.at||''}`;
        $('#excelChangeSummary').textContent=`${fmt(c.summary?.totalChanges||0)} thay đổi · ${fmt(c.workOrdersAffected||0)} công đơn · ${c.note||'Không tính dữ liệu hiện có là thay đổi'}`;
      } else {
      if(sm.newOrders)parts.push(`+${fmt(sm.newOrders)} đơn mới`);
      if(sm.finishChanges)parts.push(`${fmt(sm.finishChanges)} FINISH`);
      if(sm.notOkChanges)parts.push(`${fmt(sm.notOkChanges)} đổi SL chưa OK`);
      if(sm.transferChanges)parts.push(`${fmt(sm.transferChanges)} đổi XLN`);
      if(sm.shipDateChanges)parts.push(`${fmt(sm.shipDateChanges)} đổi lịch xuất`);
      if(!parts.length)parts.push(Number(c.totalChanges||0)?`${fmt(c.totalChanges)} thay đổi khác`:'0 thay đổi dữ liệu');
      $('#excelChangeTitle').textContent=`✓ Excel vừa cập nhật · ${c.at||''}`;
      $('#excelChangeSummary').textContent=`${fmt(c.totalChanges||0)} thay đổi · ${fmt(c.workOrdersAffected||0)} công đơn · ${parts.slice(0,3).join(' · ')}`;
      }
    }
  }
  const s=j.system||{}; setSys('#sysServer',!!s.server,'Server'); setSys('#sysExcel',!!s.excel,'Excel'); setSys('#sysSft',!!s.sft,'SFT'); setSys('#sysPrinter',!!s.printer,'Máy in');
  if(s.printerName)$('#sysPrinter').title=s.printerName;
 }catch(e){setSys('#sysServer',false,'Server')}
}

function setNetState(){
 const n=$('#net'); if(!n)return;
 const online=navigator.onLine; n.textContent=online?'● ONLINE':'● OFFLINE'; n.classList.toggle('offline',!online);
}
async function checkServerHealth(){
 const el=$('#serverMini'); if(!el)return;
 try{
   const ctrl=new AbortController(), timer=setTimeout(()=>ctrl.abort(),3500);
   const r=await fetch('/health?_='+Date.now(),{cache:'no-store',signal:ctrl.signal}); clearTimeout(timer);
   if(!r.ok)throw new Error('HTTP '+r.status);
   const j=await r.json();
   const t=new Date().toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'});
   el.className='server-mini ok'; el.textContent=`● SERVER OK · ${t}`;
   el.title=`Server đang chạy · ${j.rows??0} dòng dữ liệu · Excel ${j.updated||''}`;
 }catch(e){
   el.className='server-mini err'; el.textContent='● SERVER MẤT'; el.title='Không kết nối được server CNC trên PC công ty';
 }
}
window.addEventListener('online',()=>{setNetState();checkServerHealth()});
window.addEventListener('offline',()=>{setNetState();checkServerHealth()});
setNetState(); checkServerHealth(); loadDashboard(); setInterval(checkServerHealth,20000); setInterval(loadDashboard,3000);
if('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(()=>{});


let currentTarget=null;
const roundKg=n=>Math.round((Number(n)||0)*10)/10;
function signText(n){n=Number(n)||0;return n>0?`Dư ${fmt(n)} PCS`:n<0?`Thiếu ${fmt(Math.abs(n))} PCS`:'Đủ 0 PCS'}
function renderDivide(x){
 currentTarget=x;
 // V2.79: hien thi he so dung cach lam tron 1 chu so nhu Excel (14.705... -> 14.7).
 const roundRatio=n=>{n=Number(n)||0;return n>0?Math.round((n+Number.EPSILON)*10)/10:0};
 const recent=(Array.isArray(x.conversionRecent)?x.conversionRecent:[]).map(roundRatio).filter(v=>v>0).slice(0,5);
 let ratio=recent.length?recent[0]:roundRatio(x.conversionRatio||0);
 const hasSavedRatio=ratio>0;
 const recentHtml=recent.length?`<div class="recent-ratios"><span class="recent-label">5 số quy đổi gần nhất</span><div class="recent-ratio-list">${recent.map((v,i)=>`<button type="button" class="recent-ratio-btn${i===0?' active':''}" data-ratio="${v}">${fmt(v)}</button>`).join('')}</div></div>`:'';
 const manualRatioHtml=!hasSavedRatio?`<div class="missing-ratio"><div class="missing-ratio-msg">⚠️ Mã liệu chưa có quy đổi</div><label class="manual-ratio-label">Nhập số quy đổi (PCS/KG)<input id="manualRatioInput" inputmode="decimal" step="0.1" placeholder="Ví dụ 14,7"></label></div>`:'';
 divideWrap.innerHTML=`<div class="divide-card"><div class="divide-title">✂️ Chia đơn</div>
  <div class="ratio-box"><span>Số quy đổi</span><b id="activeRatioText">${ratio?fmt(ratio)+' PCS/KG':'Chưa có quy đổi'}</b></div>
  ${recentHtml}
  ${manualRatioHtml}
  <div class="divide-grid"><label>KG<input id="kgInput" inputmode="decimal" placeholder="Nhập KG"></label><label>PCS<input id="pcsInput" inputmode="numeric" placeholder="Nhập PCS"></label></div>
  <label class="sl-label">SL nhập<input id="slInput" inputmode="numeric" placeholder="Nhập số lượng chuyển"></label>
  <div id="divideWarn"></div><div id="divideResult" class="calc-grid"></div>
 </div>`;
 divideWrap.classList.remove('hidden');
 const kg=$('#kgInput'),pcs=$('#pcsInput'),sl=$('#slInput'); let syncing=false;
 function calc(){
  const v=Number(sl.value||0), cap=Number(x.inputQty||0), r1=Number(x.transferredQty||0)+v-Number(x.orderQty||0), r2=Number(x.transferredQty||0)+v-Number(x.issuedQty||0)+Number(x.ngQty||0);
  $('#divideResult').innerHTML=`<div class="calc"><span>Theo đơn hàng</span><b class="${r1<0?'neg':'pos'}">${signText(r1)}</b></div><div class="calc"><span>Theo lĩnh liệu</span><b class="${r2<0?'neg':'pos'}">${signText(r2)}</b></div>`;
  $('#divideWarn').innerHTML=(v>cap&&cap>0)?`<div class="transfer-warn">⚠️ Không Thể Chuyển Vượt Quá Số Lượng Đầu Vào. Hãy Kiểm Tra Lại!</div>`:'';
 }
 function recalcFromSelectedRatio(){
  syncing=true;
  if(kg.value){const p=Math.floor(Number(kg.value.replace(',','.'))*ratio);pcs.value=p;sl.value=p}
  else if(pcs.value){kg.value=roundKg(Number(pcs.value)/ratio);sl.value=pcs.value}
  syncing=false;calc();
 }
 document.querySelectorAll('.recent-ratio-btn').forEach(btn=>btn.addEventListener('click',()=>{
   ratio=Number(btn.dataset.ratio)||ratio;
   document.querySelectorAll('.recent-ratio-btn').forEach(b=>b.classList.toggle('active',b===btn));
   const t=$('#activeRatioText');if(t)t.textContent=fmt(ratio)+' PCS/KG';
   recalcFromSelectedRatio();
 }));
 const manualRatio=$('#manualRatioInput');
 if(manualRatio){
   manualRatio.addEventListener('input',()=>{
     const raw=Number(String(manualRatio.value||'').replace(',','.'));
     ratio=raw>0?roundRatio(raw):0;
     const t=$('#activeRatioText');if(t)t.textContent=ratio?fmt(ratio)+' PCS/KG':'Chưa có quy đổi';
     if(ratio)recalcFromSelectedRatio();
     else{syncing=true;kg.value='';pcs.value='';sl.value='';syncing=false;calc()}
   });
   manualRatio.addEventListener('blur',()=>{
     if(!ratio)return;
     manualRatio.value=String(ratio).replace('.',',');
   });
 }
 kg.addEventListener('input',()=>{if(syncing)return;syncing=true;if(!kg.value){pcs.value='';sl.value=''}else if(ratio){const p=Math.floor(Number(kg.value.replace(',','.'))*ratio);pcs.value=p;sl.value=p}else{pcs.value='';sl.value=''}syncing=false;calc()});
 pcs.addEventListener('input',()=>{if(syncing)return;syncing=true;if(!pcs.value){kg.value='';sl.value=''}else if(ratio){kg.value=roundKg(Number(pcs.value)/ratio);sl.value=pcs.value}else{kg.value='';sl.value=pcs.value}syncing=false;calc()});
 sl.addEventListener('input',calc); calc();
}

function initQr(){
 const qrBtn=document.querySelector('#qrBtn'),qrModal=document.querySelector('#qrModal'),qrClose=document.querySelector('#qrClose');
 if(!qrBtn||!qrModal||!qrClose)return;
 qrBtn.addEventListener('click',()=>qrModal.classList.remove('hidden'));
 qrClose.addEventListener('click',()=>qrModal.classList.add('hidden'));
 qrModal.addEventListener('click',e=>{if(e.target===qrModal)qrModal.classList.add('hidden')});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initQr);else initQr();




function xlnFmt(v){
  const n=Number(v||0);
  return Number.isFinite(n) ? n.toLocaleString('vi-VN',{maximumFractionDigits:3}) : (v??'');
}
function xlnEsc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function closeTodayXln(){ const m=document.querySelector('#todayXlnModal'); if(m)m.hidden=true; }

let todayXlnCache={}, todayXlnLoading={};
function localIsoDate(d=new Date()){const y=d.getFullYear(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${y}-${m}-${day}`}
async function fetchTodayXln(force=false,date=''){
  const key=date||localIsoDate();
  if(todayXlnCache[key]&&!force)return todayXlnCache[key];
  if(todayXlnLoading[key]&&!force)return todayXlnLoading[key];
  todayXlnLoading[key]=(async()=>{
    const r=await fetch('/api/today-xln?date='+encodeURIComponent(key)+'&t='+Date.now(),{cache:'no-store'});
    const text=await r.text(); let j={}; try{j=JSON.parse(text)}catch{}
    if(!r.ok||!j.ok)throw new Error(j.error||text||('HTTP '+r.status));
    todayXlnCache[key]=j; return j;
  })();
  try{return await todayXlnLoading[key]}finally{delete todayXlnLoading[key]}
}
function renderTodayXln(j){
  const list=document.querySelector('#xlnList'), sum=document.querySelector('#xlnSummary'), title=document.querySelector('#xlnTitle');
  if(!list||!sum||!title)return;
  title.textContent='ĐÃ CHUYỂN XLN - '+(j.date||'');
  sum.textContent=`Công đơn: ${xlnFmt(j.workOrderCount)}  •  Dòng chuyển: ${xlnFmt(j.rowCount)}  •  Tổng SL: ${xlnFmt(j.totalQty)} PCS  •  Tổng KG: ${xlnFmt(j.totalKg)}`;
  if(!j.rows||!j.rows.length){list.innerHTML='<div class="xln-empty">Ngày này chưa có công đơn chuyển XLN.</div>';return;}
  list.innerHTML=j.rows.map(x=>`<div class="xln-card">
    <div class="xln-card-top"><b>${xlnEsc(x.workOrder)}</b><span>${xlnEsc(x.date)}</span></div>
    ${x.customer?('<div class="xln-customer"><strong>'+xlnEsc(x.customer)+'</strong></div>'):''}
    <div class="xln-material">${xlnEsc(x.material)}${x.spec?(' · '+xlnEsc(x.spec)):''}</div>
    <div class="xln-qty"><strong>${xlnFmt(x.qty)} PCS</strong><span>${xlnFmt(x.kg)} KG</span></div>
    <div class="xln-order-state ${x.orderFinished?'finish':'missing'}">${x.orderFinished?'✓ FINISH':('Số lượng còn thiếu là '+xlnFmt(x.remainingQty)+' PCS')}</div>
    <div class="xln-meta">${x.status?('<span>'+xlnEsc(x.status)+'</span>'):''}${x.pcsPerKg?('<span>Quy đổi '+xlnFmt(x.pcsPerKg)+' PCS/KG</span>'):''}</div>
    ${x.note?('<div class="xln-note">'+xlnEsc(x.note)+'</div>'):''}
  </div>`).join('');
}
async function loadXlnDate(force=false){
  const input=document.querySelector('#xlnDate'),list=document.querySelector('#xlnList'),sum=document.querySelector('#xlnSummary');
  const date=(input&&input.value)||localIsoDate();
  if(list)list.innerHTML='<div class="xln-loading">Đang tải...</div>'; if(sum)sum.textContent='Đang tải...';
  try{renderTodayXln(await fetchTodayXln(force,date))}catch(e){if(sum)sum.textContent='Không tải được dữ liệu';if(list)list.innerHTML='<div class="xln-error">❌ '+xlnEsc(e.message||e)+'</div>'}
}
async function showTodayXln(){
  const m=document.querySelector('#todayXlnModal'),input=document.querySelector('#xlnDate'); if(!m)return;
  m.hidden=false; if(input&&!input.value)input.value=localIsoDate(); await loadXlnDate(false);
}
function bindTodayXln(){
  const input=document.querySelector('#xlnDate'); if(input){
    input.value=localIsoDate();
    input.addEventListener('change',()=>loadXlnDate(true));
    input.addEventListener('input',()=>loadXlnDate(true));
  }
  fetchTodayXln(false,localIsoDate()).catch(()=>{});
  setInterval(()=>fetchTodayXln(true,localIsoDate()).catch(()=>{}),30000);
  const b=document.querySelector('#btnTodayXln'); if(b)b.addEventListener('click',showTodayXln);
  document.querySelectorAll('[data-xln-close]').forEach(x=>x.addEventListener('click',closeTodayXln));
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bindTodayXln);else bindTodayXln();


function detailFmt(v,max=3){return new Intl.NumberFormat('vi-VN',{maximumFractionDigits:max}).format(Number(v||0))}
function closeDetail(){const m=$('#detailModal');if(m)m.classList.add('hidden')}
function detailCardIssue(x){return `<div class="detail-card"><div class="detail-card-top"><b>${esc(x.date||'-')}</b><span>${esc(x.workOrder||'')}</span></div><div class="detail-material">${esc(x.material||'')}${x.spec?' · '+esc(x.spec):''}</div><div class="detail-qty"><strong>${detailFmt(x.issuedQty)} PCS</strong><span>${detailFmt(x.kg)} KG</span></div><div class="detail-meta"><span>Đầu vào ${detailFmt(x.inputQty)}</span>${x.erp?'<span>ERP '+esc(x.erp)+'</span>':''}</div>${x.customer?'<div class="detail-note">KH: '+esc(x.customer)+'</div>':''}</div>`}
function detailCardXln(x){return `<div class="detail-card"><div class="detail-card-top"><b>${esc(x.date||'-')}</b><span>${esc(x.workOrder||'')}</span></div><div class="detail-material">${esc(x.material||'')}${x.spec?' · '+esc(x.spec):''}</div><div class="detail-qty"><strong>${detailFmt(x.qty)} PCS</strong><span>${detailFmt(x.kg)} KG</span></div><div class="detail-meta">${x.unit?'<span>'+esc(x.unit)+'</span>':''}${x.line?'<span>LINE '+esc(x.line)+'</span>':''}${Number(x.pcsPerKg)>0?'<span>Quy đổi '+detailFmt(x.pcsPerKg,1)+' PCS/KG</span>':''}${x.status?'<span>'+esc(x.status)+'</span>':''}</div>${x.note?'<div class="detail-note">'+esc(x.note)+'</div>':''}</div>`}
async function showOrderDetail(kind,w){
 const modal=$('#detailModal'),title=$('#detailTitle'),sum=$('#detailSummary'),list=$('#detailList');
 if(!modal||!w)return;modal.classList.remove('hidden');title.textContent=(kind==='issue'?'CHI TIẾT LĨNH LIỆU - ':'CHI TIẾT CHUYỂN XLN - ')+w;sum.textContent='Đang tải...';list.innerHTML='<div class="detail-loading">Đang đọc Excel...</div>';
 try{
  const url=kind==='issue'?'/api/issue-details':'/api/xln-details';
  const r=await fetch(url+'?workOrder='+encodeURIComponent(w)+'&_='+Date.now(),{headers:{'X-CNC-PIN':pin},cache:'no-store'});const j=await r.json().catch(()=>({}));
  if(r.status===401){showPin();throw new Error(j.error||'PIN không đúng')}if(!r.ok)throw new Error(j.error||'Không đọc được chi tiết');
  if(kind==='issue')sum.textContent=`${j.count||0} dòng • Tổng lĩnh ${detailFmt(j.totalQty)} PCS • ${detailFmt(j.totalKg)} KG`;
  else sum.textContent=`${j.count||0} dòng • Tổng chuyển ${detailFmt(j.totalQty)} PCS • ${detailFmt(j.totalKg)} KG${Number(j.rate)>0?' • Quy đổi '+detailFmt(j.rate)+' PCS/KG':''}`;
  if(!j.rows||!j.rows.length){list.innerHTML='<div class="detail-empty">Công đơn này chưa có dữ liệu.</div>';return}
  list.innerHTML=j.rows.map(kind==='issue'?detailCardIssue:detailCardXln).join('');
 }catch(e){sum.textContent='Không tải được dữ liệu';list.innerHTML='<div class="detail-error">❌ '+esc(e.message||e)+'</div>'}
}
function initOrderDetails(){
 document.addEventListener('click',e=>{const ib=e.target.closest('.issue-detail-btn');if(ib){showOrderDetail('issue',ib.dataset.detailWo);return}const xb=e.target.closest('.xln-detail-btn');if(xb){showOrderDetail('xln',xb.dataset.detailWo);return}if(e.target.closest('[data-detail-close]'))closeDetail()});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initOrderDetails);else initOrderDetails();
