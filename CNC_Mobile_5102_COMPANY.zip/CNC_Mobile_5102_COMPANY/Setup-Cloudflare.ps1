﻿$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Tools = Join-Path $Root 'tools'
$Cloudflared = Join-Path $Tools 'cloudflared.exe'
New-Item -ItemType Directory -Force -Path $Tools | Out-Null

Write-Host ''
Write-Host '=== CNC Mobile 5102 - Cloudflare Tunnel Setup ===' -ForegroundColor Cyan
if (!(Test-Path $Cloudflared)) {
    Write-Host 'Dang tai cloudflared.exe chinh chu...' -ForegroundColor Yellow
    $url = 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe'
    Invoke-WebRequest -Uri $url -OutFile $Cloudflared -UseBasicParsing
}

$domain = 'cnc.phanken.io.vn'
$tunnelName = 'cnc-mobile-5102-company'

Write-Host ''
Write-Host 'Trinh duyet se mo de dang nhap Cloudflare va chon domain...' -ForegroundColor Yellow
& $Cloudflared tunnel login
if ($LASTEXITCODE -ne 0) { throw 'Cloudflare login that bai.' }

$listJson = & $Cloudflared tunnel list --output json 2>$null
$tunnelId = $null
if ($LASTEXITCODE -eq 0 -and $listJson) {
    try {
        $list = $listJson | ConvertFrom-Json
        $found = $list | Where-Object { $_.name -eq $tunnelName } | Select-Object -First 1
        if ($found) { $tunnelId = $found.id }
    } catch {}
}

if (!$tunnelId) {
    Write-Host "Tao tunnel $tunnelName..." -ForegroundColor Yellow
    $createOut = (& $Cloudflared tunnel create $tunnelName 2>&1 | Out-String)
    Write-Host $createOut
    $m = [regex]::Match($createOut, '[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')
    if (!$m.Success) { throw 'Khong lay duoc Tunnel ID.' }
    $tunnelId = $m.Value
}

Write-Host "Gan DNS $domain -> $tunnelName..." -ForegroundColor Yellow
& $Cloudflared tunnel route dns $tunnelName $domain

$cred = Join-Path (Join-Path $env:USERPROFILE '.cloudflared') ($tunnelId + '.json')
$cfg = @"
tunnel: $tunnelId
credentials-file: $cred
ingress:
  - hostname: $domain
    service: http://127.0.0.1:8787
  - service: http_status:404
"@
$cfgPath = Join-Path $Root 'cloudflare-config.yml'
Set-Content -Path $cfgPath -Value $cfg -Encoding UTF8
Set-Content -Path (Join-Path $Root 'DOMAIN.txt') -Value ("https://" + $domain) -Encoding UTF8

Write-Host ''
Write-Host 'HOAN TAT!' -ForegroundColor Green
Write-Host "Domain: https://$domain" -ForegroundColor Green
Write-Host 'Tu lan sau chi can bam START_ALL.bat' -ForegroundColor Cyan
