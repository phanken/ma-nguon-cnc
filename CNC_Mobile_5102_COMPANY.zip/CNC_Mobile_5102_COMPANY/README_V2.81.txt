CNC Mobile 5102 - V2.81 HISTORY BASELINE FIX

- Sửa lịch sử Excel bị tính hàng nghìn công đơn hiện có thành "công đơn mới" khi snapshot trước bị rỗng/không đầy đủ.
- Nếu baseline trước không hợp lệ, server tạo "Khởi tạo baseline" và KHÔNG tính dữ liệu hiện có là thay đổi.
- Tự sửa các record lịch sử cũ có dấu hiệu baseline lỗi (ví dụ vài chục dòng -> hơn 4.000 dòng và gần như toàn bộ bị tính là đơn mới).
- Các lần Save tiếp theo vẫn so sánh thay đổi bình thường.
- Giữ nguyên toàn bộ V2.80: Save Gate, Fast Path, 5 số quy đổi gần nhất, auto-scroll Chia đơn, Assistant, SFT, Device Tracking.
