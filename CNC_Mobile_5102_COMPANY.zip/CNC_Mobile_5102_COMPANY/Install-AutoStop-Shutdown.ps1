$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$scriptPath = Join-Path $Root 'Shutdown-AutoStop.ps1'
if (-not (Test-Path $scriptPath)) { throw "Khong tim thay $scriptPath" }

# Local Group Policy shutdown scripts are stored here. Windows executes them for both shutdown and restart.
$base = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Group Policy\Scripts\Shutdown'
New-Item -Path $base -Force | Out-Null

# Remove only an older entry created by this CNC package.
Get-ChildItem $base -ErrorAction SilentlyContinue | ForEach-Object {
    $p = $_.PSPath
    Get-ChildItem $p -ErrorAction SilentlyContinue | ForEach-Object {
        $v = Get-ItemProperty $_.PSPath -ErrorAction SilentlyContinue
        if ([string]$v.Script -match 'Shutdown-AutoStop\.ps1') {
            Remove-Item $p -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

# Pick next numeric Group Policy slot.
$nums = @(Get-ChildItem $base -ErrorAction SilentlyContinue | ForEach-Object { if ($_.PSChildName -match '^\d+$') { [int]$_.PSChildName } })
$n = 0
while ($nums -contains $n) { $n++ }
$key = Join-Path $base ([string]$n)
$cmd = Join-Path $key '0'
New-Item -Path $cmd -Force | Out-Null
New-ItemProperty -Path $cmd -Name 'Script' -Value 'powershell.exe' -PropertyType String -Force | Out-Null
$args = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $scriptPath + '"'
New-ItemProperty -Path $cmd -Name 'Parameters' -Value $args -PropertyType String -Force | Out-Null
New-ItemProperty -Path $key -Name 'GPO-ID' -Value 'LocalGPO' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $key -Name 'SOM-ID' -Value 'Local' -PropertyType String -Force | Out-Null
New-ItemProperty -Path $key -Name 'FileSysPath' -Value $Root -PropertyType String -Force | Out-Null
New-ItemProperty -Path $key -Name 'DisplayName' -Value 'CNC Mobile 5102 Auto Stop' -PropertyType String -Force | Out-Null

Write-Host '[OK] Da cai AUTO STOP khi Windows Shutdown/Restart.' -ForegroundColor Green
Write-Host '[OK] Windows khoi dong lai se KHONG tu START server.' -ForegroundColor Green
Write-Host '[INFO] Khong can cai lai sau moi lan restart.' -ForegroundColor Cyan
