﻿$ErrorActionPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$CfPidFile = Join-Path $Root 'cloudflare.pid'
$ServerErrorLog = Join-Path $Root 'LOGS\server-error.log'

Write-Host ''
Write-Host '=== CNC MOBILE 5102 - TRANG THAI ===' -ForegroundColor Cyan

# 1) Server: kiem tra TCP truoc, sau do /health
$serverOk = $false
$healthOk = $false
$rows = $null
$updated = $null

try {
    $tcp = New-Object System.Net.Sockets.TcpClient
    $async = $tcp.BeginConnect('127.0.0.1', 8787, $null, $null)
    if ($async.AsyncWaitHandle.WaitOne(2000, $false)) {
        try {
            $tcp.EndConnect($async)
            if ($tcp.Connected) { $serverOk = $true }
        } catch {}
    }
    $tcp.Close()
} catch {}

if ($serverOk) {
    try {
        $r = Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:8787/health?statuscheck=1' -TimeoutSec 4 -ErrorAction Stop
        if ($r.StatusCode -eq 200) {
            $healthOk = $true
            try {
                $h = $r.Content | ConvertFrom-Json
                $rows = $h.rows
                $updated = $h.updated
            } catch {}
        }
    } catch {}

    if ($healthOk) {
        Write-Host 'SERVER     : DANG CHAY | PORT 8787 | HEALTH OK' -ForegroundColor Green
    } else {
        Write-Host 'SERVER     : DANG CHAY | PORT 8787' -ForegroundColor Green
    }
    if ($null -ne $rows) {
        Write-Host ("DU LIEU     : {0} dong | {1}" -f $rows, $updated) -ForegroundColor DarkGray
    }
} else {
    Write-Host 'SERVER     : DA TAT / PORT 8787 KHONG MO' -ForegroundColor Red
    if (Test-Path $ServerErrorLog) {
        try {
            $lastErr = Get-Content -LiteralPath $ServerErrorLog -Tail 8 -ErrorAction Stop
            if ($lastErr) {
                Write-Host 'LOI SERVER GAN NHAT:' -ForegroundColor Magenta
                foreach($ln in $lastErr){ Write-Host ('  ' + $ln) -ForegroundColor DarkRed }
                Write-Host 'LOG        : LOGS\server-error.log' -ForegroundColor DarkGray
            }
        } catch {}
    }
}

# 2) Cloudflare: PID file + fallback process lookup
$cfOk = $false
$cfPid = $null
if (Test-Path $CfPidFile) {
    try {
        $raw = (Get-Content $CfPidFile -Raw).Trim()
        $id = 0
        if ([int]::TryParse($raw, [ref]$id)) {
            $p = Get-Process -Id $id -ErrorAction Stop
            if ($p.ProcessName -eq 'cloudflared') {
                $cfOk = $true
                $cfPid = $id
            }
        }
    } catch {}
}
if (-not $cfOk) {
    $p = Get-Process cloudflared -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($p) {
        $cfOk = $true
        $cfPid = $p.Id
    }
}
if ($cfOk) {
    Write-Host ("CLOUDFLARE : DANG CHAY | PID {0}" -f $cfPid) -ForegroundColor Green
} else {
    Write-Host 'CLOUDFLARE : KHONG THAY TIEN TRINH' -ForegroundColor Yellow
}

# 3) Public web
$webOk = $false
try {
    $w = Invoke-WebRequest -UseBasicParsing -Uri 'https://cnc.phanken.io.vn/health?statuscheck=1' -TimeoutSec 8 -ErrorAction Stop
    if ($w.StatusCode -eq 200) { $webOk = $true }
} catch {}
if ($webOk) {
    Write-Host 'WEB        : TRUY CAP DUOC cnc.phanken.io.vn' -ForegroundColor Green
} else {
    Write-Host 'WEB        : KHONG KIEM TRA DUOC TU MAY NAY' -ForegroundColor Yellow
}

Write-Host ''
if ($serverOk -and $webOk) {
    Write-Host 'HE THONG   : HOAT DONG BINH THUONG' -ForegroundColor Green
} elseif ($serverOk) {
    Write-Host 'HE THONG   : SERVER VAN DANG CHAY' -ForegroundColor Yellow
} else {
    Write-Host 'HE THONG   : SERVER DANG TAT' -ForegroundColor Red
}
Write-Host ''
