@echo off
cd /d "%~dp0"
if not exist "%~dp0LOGS" mkdir "%~dp0LOGS"
if not exist "%~dp0LOGS\server-error.log" (
  echo Chua co server-error.log. Hay START_ALL roi CHECK_STATUS neu server loi.
  pause
  exit /b 0
)
start "" notepad.exe "%~dp0LOGS\server-error.log"
exit /b 0
