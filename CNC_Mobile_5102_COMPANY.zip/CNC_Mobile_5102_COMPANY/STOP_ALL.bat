@echo off
chcp 65001 >nul
cd /d "%~dp0"
title CNC Mobile 5102 - Stop All

echo ==============================================
echo   CNC MOBILE 5102 - STOP ALL - MANUAL MODE
echo ==============================================
echo.

rem V2.94: Auto Start is no longer used. Remove any old V2.92/V2.93 task/registry entry
rem and kill an old watchdog first so it cannot start the server again after STOP.
schtasks /End /TN "CNC Mobile 5102 Auto Start" >nul 2>&1
schtasks /Delete /TN "CNC Mobile 5102 Auto Start" /F >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "CNC_Mobile_5102" /f >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Disable-AutoStart.ps1"

rem Stop CNC server + this app's Cloudflare tunnel.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Stop-All-Hidden.ps1"
timeout /t 1 /nobreak >nul

rem Verify the real result. Do not print OK unless it is actually stopped.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$server=$false; try{$c=Get-NetTCPConnection -State Listen -LocalPort 8787 -ErrorAction Stop; if($c){$server=$true}}catch{}; if($server){Write-Host '[!] SERVER 8787 VAN CON CHAY' -ForegroundColor Yellow}else{Write-Host '[OK] SERVER DA DUNG' -ForegroundColor Green}; $cf=Get-Process cloudflared -ErrorAction SilentlyContinue; if($cf){Write-Host '[!] CLOUDFLARE VAN CON TIEN TRINH' -ForegroundColor Yellow}else{Write-Host '[OK] CLOUDFLARE DA DUNG' -ForegroundColor Green}"
echo.
echo [INFO] AUTO START DA TAT. TU BAY GIO BAT SERVER BANG START_ALL.bat.
echo.
pause
