@echo off
chcp 65001 >nul
cd /d "%~dp0"
title CNC Mobile 5102 - Stop All
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Stop-All-Hidden.ps1"
timeout /t 1 /nobreak >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; try{$c=Get-NetTCPConnection -State Listen -LocalPort 8787 -ErrorAction Stop; if($c){$ok=$true}}catch{}; if($ok){Write-Host '[!] SERVER 8787 VAN CON CHAY' -ForegroundColor Yellow}else{Write-Host '[OK] SERVER DA DUNG' -ForegroundColor Green}; $cf=Get-Process cloudflared -ErrorAction SilentlyContinue; if($cf){Write-Host '[!] CLOUDFLARE CO TIEN TRINH CON CHAY' -ForegroundColor Yellow}else{Write-Host '[OK] CLOUDFLARE DA DUNG' -ForegroundColor Green}"
echo.
pause
