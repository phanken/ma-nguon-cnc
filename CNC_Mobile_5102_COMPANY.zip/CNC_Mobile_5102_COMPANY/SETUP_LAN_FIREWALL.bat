@echo off
setlocal
title CNC Mobile 5102 - LAN Firewall

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo Dang yeu cau quyen Administrator...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

echo Dang mo cong TCP 8787 cho Private + Public + Domain...
netsh advfirewall firewall delete rule name="CNC Mobile 5102 Port 8787" >nul 2>&1
netsh advfirewall firewall add rule name="CNC Mobile 5102 Port 8787" dir=in action=allow protocol=TCP localport=8787 profile=any

if %errorlevel% neq 0 (
  echo.
  echo LOI: Khong the tao Firewall rule.
  echo Hay kiem tra Windows Defender Firewall.
) else (
  echo.
  echo OK: Da mo TCP 8787 cho TAT CA network profile.
)

echo.
echo Dia chi IPv4 cua PC:
powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | Sort-Object InterfaceMetric | ForEach-Object { Write-Host ('  http://' + $_.IPAddress + ':8787  [' + $_.InterfaceAlias + ']') }"
echo.
echo Hay dung IP cua Wi-Fi/Ethernet dang ket noi cung mang voi dien thoai.
pause
