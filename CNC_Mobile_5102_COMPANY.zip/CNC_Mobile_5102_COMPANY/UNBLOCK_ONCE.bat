@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0UNBLOCK_ALL_FILES.ps1"
exit /b 0
