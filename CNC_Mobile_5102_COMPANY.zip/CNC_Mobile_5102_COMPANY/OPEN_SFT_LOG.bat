@echo off
cd /d "%~dp0"
if not exist "logs" mkdir "logs"
if not exist "logs\\SFT_PRINT.log" (
  echo Chua co log SFT. Hay bam In cong don tren dien thoai 1 lan truoc.
  pause
  exit /b 0
)
start "" notepad.exe "logs\\SFT_PRINT.log"
