V2.44 - SERVER DIAGNOSTIC LOG

server.log       : toan bo qua trinh khoi dong + output cua Start-Server.ps1
server-error.log : chi ghi loi crash/startup quan trong

Neu CHECK_STATUS bao PORT 8787 KHONG MO:
1. Mo OPEN_SERVER_LOG.bat
2. Gui file LOGS\server-error.log
