@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo =============================================
echo  KIEM TRA SFT + MAY IN - CNC MOBILE 5102
echo =============================================
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$p='HKCU:\Software\TraCuuMaLieuTongHopNative\CNC5102';" ^
 "if(Test-Path $p){$x=Get-ItemProperty $p; if($x.SftUser -and $x.SftPassword){Write-Host ('SFT: DA CAU HINH - User: '+$x.SftUser) -ForegroundColor Green}else{Write-Host 'SFT: CHUA CAU HINH. Mo FIXED92 -> Cau hinh SFT...' -ForegroundColor Red}}else{Write-Host 'SFT: CHUA CO CAU HINH FIXED92.' -ForegroundColor Red};" ^
 "Add-Type -AssemblyName System.Drawing; $pr=(New-Object System.Drawing.Printing.PrinterSettings).PrinterName; if($pr){Write-Host ('Default printer: '+$pr) -ForegroundColor Green}else{Write-Host 'Default printer: CHUA CO' -ForegroundColor Red};" ^
 "if(Test-Path '.\tools\SumatraPDF.exe'){Write-Host 'PDF print: SumatraPDF silent' -ForegroundColor Green}else{Write-Host 'PDF print: Windows Print verb (fallback)' -ForegroundColor Yellow}"
echo.
pause
