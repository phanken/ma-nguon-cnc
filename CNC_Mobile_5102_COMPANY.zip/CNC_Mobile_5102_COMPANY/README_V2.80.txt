﻿CNC Mobile 5102 COMPANY V2.80

- Baseline: V2.79.
- Khoi phuc auto-scroll xuong khu vuc Chia don sau khi tra cong don thanh cong.
- Ap dung cho auto-search khi nhap du 9 so, Enter va nut Tim.
- Chi scroll khi API tra cong don thanh cong; neu dang reload/khong tim thay thi khong scroll.
- Giu nguyen 5 so quy doi gan nhat, rounding/cache fix, Save Gate va cac tinh nang cua V2.79.
