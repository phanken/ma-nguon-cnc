@echo off
cd /d "%~dp0"
set "APPDIR=%~dp0"
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "CNC_Mobile_5102" /t REG_SZ /d "wscript.exe \"%APPDIR%AUTO_START_HIDDEN.vbs\"" /f >nul
exit /b 0
