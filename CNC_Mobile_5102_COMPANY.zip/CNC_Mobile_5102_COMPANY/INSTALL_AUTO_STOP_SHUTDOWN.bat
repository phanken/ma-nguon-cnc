@echo off
chcp 65001 >nul
cd /d "%~dp0"
fltmc >nul 2>&1
if errorlevel 1 (
  echo [INFO] Dang mo quyen Administrator...
  powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
echo ==============================================
echo  CNC MOBILE 5102 - AUTO STOP SHUTDOWN/RESTART
echo ==============================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-AutoStop-Shutdown.ps1"
echo.
pause
