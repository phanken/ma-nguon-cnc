﻿param(
    [Parameter(Mandatory=$true)][string]$PrinterName,
    [Parameter(Mandatory=$true)][string]$PdfPath,
    [Parameter(Mandatory=$true)][string]$SumatraPath,
    [int]$Copies = 1,
    [string]$LogPath = ""
)
$ErrorActionPreference='Stop'
function Log([string]$level,[string]$msg){
    $line="[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [$level] $msg"
    if($LogPath){ try { Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8 } catch {} }
}
try {
    if(!(Test-Path -LiteralPath $PdfPath)){ throw "Khong tim thay PDF: $PdfPath" }
    if(!(Test-Path -LiteralPath $SumatraPath)){ throw "Khong tim thay SumatraPDF: $SumatraPath" }
    if($Copies -lt 1){$Copies=1}; if($Copies -gt 10){$Copies=10}

    # Driver probe already confirmed:
    # RICOH Aficio MP 5001 PCL 6 -> A5 RAWKIND = 11.
    # Use paperkind=11 directly. This bypasses the paper-name parsing that kept producing A4.
    $settings='paperkind=11,duplexlong,fit,ignore-pdf-print-settings'
    Log 'INFO' "PRINT WORKER V2.28 bat dau; printer=$PrinterName; settings=$settings"

    for($i=1;$i -le $Copies;$i++){
        $args=@(
            '-print-to', ('"' + $PrinterName + '"'),
            '-print-settings', ('"' + $settings + '"'),
            '-silent',
            ('"' + $PdfPath + '"')
        )
        Log 'INFO' "Gui ban $i/$Copies; paperkind=11(A5); duplexlong; fit"
        $p=Start-Process -FilePath $SumatraPath -ArgumentList $args -PassThru -WindowStyle Hidden -ErrorAction Stop
        if($p){
            if(-not $p.WaitForExit(30000)){
                try{$p.Kill()}catch{}
                throw 'Sumatra qua 30 giay khong ket thuc.'
            }
            if($p.ExitCode -ne 0){ throw "Sumatra ExitCode=$($p.ExitCode)" }
        }
        if($i -lt $Copies){Start-Sleep -Milliseconds 400}
    }
    Log 'INFO' 'PRINT WORKER V2.28 thanh cong.'
    exit 0
}
catch {
    Log 'ERROR' ("PRINT WORKER V2.28 loi: "+$_.Exception.Message)
    exit 28
}
