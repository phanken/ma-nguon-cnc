CNC Mobile 5102 - V2.93 MANUAL STOP AWARE WATCHDOG

Nen tang: V2.92.

Moi trong V2.93:
- STOP_ALL.bat tao MANUAL_STOP.flag gan voi lan khoi dong Windows hien tai.
- Watchdog thay co nay se KHONG tu bat lai Server/Cloudflare sau khi nguoi dung chu dong STOP.
- START_ALL.bat tu xoa MANUAL_STOP.flag va bat lai binh thuong.
- Sau khi Windows reboot, watchdog nhan ra flag thuoc boot cu, tu xoa flag va auto-start lai nhu V2.92.
- Watchdog van tu cuu neu Server/Cloudflare tu chet ngoai y muon.
- Khong thay doi cache Excel, /qd, Chia don, SFT hay Assistant.

Su dung:
1. Neu chua cai Auto Start: chay INSTALL_AUTO_START.bat mot lan.
2. Bam STOP_ALL.bat => dung co chu y, watchdog khong bat lai.
3. Bam START_ALL.bat => huy trang thai manual stop va chay lai.
4. Restart Windows => server van tu khoi dong lai sau khi dang nhap.
