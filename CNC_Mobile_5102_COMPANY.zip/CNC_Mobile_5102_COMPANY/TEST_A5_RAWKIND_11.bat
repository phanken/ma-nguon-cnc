@echo off
setlocal
title CNC 5102 - TEST A5 RAWKIND 11
echo.
echo File nay KHONG tu in.
echo No chi kiem tra driver RICOH da co A5 RAWKIND 11 hay chua.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.Drawing; $p=New-Object System.Drawing.Printing.PrinterSettings; $p.PrinterName='RICOH Aficio MP 5001 PCL 6'; $p.PaperSizes | ? {$_.RawKind -eq 11} | %% { 'A5 RAWKIND 11 FOUND: '+$_.PaperName+' '+$_.Width+'x'+$_.Height }"
echo.
pause
