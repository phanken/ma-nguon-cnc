﻿$ErrorActionPreference='SilentlyContinue'
$Root=Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile=Join-Path $Root 'cnc-server.pid'
if(Test-Path $pidFile){
  $v=(Get-Content $pidFile -Raw).Trim(); $n=0
  if([int]::TryParse($v,[ref]$n)){ Stop-Process -Id $n -Force -ErrorAction SilentlyContinue }
  Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
}
try {
  $pids=@(Get-NetTCPConnection -State Listen -LocalPort 8787 -ErrorAction Stop | Select-Object -ExpandProperty OwningProcess -Unique)
} catch {
  $pids=@(); $lines=netstat -ano -p tcp | Select-String ':8787\s+.*LISTENING\s+(\d+)'
  foreach($line in $lines){ if($line.Matches.Count){$pids += [int]$line.Matches[0].Groups[1].Value} }
}
foreach($id in @($pids|Select-Object -Unique)){
  if($id -gt 0 -and $id -ne $PID){
    $p=Get-CimInstance Win32_Process -Filter ("ProcessId=$id")
    if($p -and (([string]$p.CommandLine -match 'Start-Server\.ps1') -or ([string]$p.Name -match 'powershell|pwsh'))){Stop-Process -Id $id -Force}
  }
}
Remove-Item $pidFile -Force -ErrorAction SilentlyContinue
