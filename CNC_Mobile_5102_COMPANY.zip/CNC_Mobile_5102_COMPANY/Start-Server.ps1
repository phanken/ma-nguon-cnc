﻿param(
    [switch]$BuildCacheOnly,
    [string]$BuildExcelPath = '',
    [string]$BuildCachePath = ''
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
Add-Type -AssemblyName System.Web

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Www = Join-Path $Root 'www'
$ConfigPath = Join-Path $Root 'config.json'

function Load-Config {
    if (!(Test-Path $ConfigPath)) {
        Copy-Item (Join-Path $Root 'config.example.json') $ConfigPath
    }
    return (Get-Content $ConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json)
}

function Save-Config($cfg) {
    $cfg | ConvertTo-Json -Depth 5 | Set-Content $ConfigPath -Encoding UTF8
}

function Select-ExcelFile {
    Add-Type -AssemblyName System.Windows.Forms
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = 'Chon file Excel CNC 5102'
    $dlg.Filter = 'Excel Workbook (*.xlsx)|*.xlsx'
    $dlg.Multiselect = $false
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.FileName }
    return $null
}

function Col-LettersToNumber([string]$letters) {
    $n = 0
    foreach ($ch in $letters.ToUpper().ToCharArray()) { $n = $n * 26 + ([int][char]$ch - [int][char]'A' + 1) }
    return $n
}

function ExcelDate-ToString($value) {
    if ($null -eq $value -or $value -eq '' -or $value -like '#*') { return '' }
    $num = 0.0
    if ([double]::TryParse([string]$value, [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::InvariantCulture, [ref]$num)) {
        if ($num -gt 20000 -and $num -lt 80000) {
            try { return ([datetime]'1899-12-30').AddDays($num).ToString('dd/MM/yyyy') } catch {}
        }
    }
    try { return ([datetime]$value).ToString('dd/MM/yyyy') } catch { return [string]$value }
}

function Num-OrZero($v) {
    if ($null -eq $v -or $v -eq '' -or [string]$v -like '#*') { return 0.0 }
    $d = 0.0
    if ([double]::TryParse(([string]$v).Replace(',',''), [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) { return $d }
    return 0.0
}

# V2.77: hash the actual XLSX bytes. Network/Excel metadata can change while a workbook is open
# even when the user has not saved any real file content. This hash is the SAVE GATE.
function Get-ExcelFileContentHash([string]$path) {
    if([string]::IsNullOrWhiteSpace($path) -or !(Test-Path -LiteralPath $path)){ return '' }
    $fs=$null;$sha=$null
    try {
        $fs=[System.IO.File]::Open($path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
        $sha=[System.Security.Cryptography.SHA256]::Create()
        return ([BitConverter]::ToString($sha.ComputeHash($fs))).Replace('-','').ToUpperInvariant()
    } catch { return '' }
    finally {
        if($sha){$sha.Dispose()}
        if($fs){$fs.Dispose()}
    }
}

function Read-XlsxWorkOrders([string]$path) {
    Write-Host "Dang doc Excel: $path" -ForegroundColor Yellow
    $fs = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
    try {
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Read, $false)
        try {
            function Entry-Text([string]$name) {
                $e = $zip.GetEntry($name)
                if (!$e) { return $null }
                $sr = New-Object IO.StreamReader($e.Open(), [Text.Encoding]::UTF8)
                try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
            }

            $shared = @()
            $sstText = Entry-Text 'xl/sharedStrings.xml'
            if ($sstText) {
                [xml]$sst = $sstText
                $ns = New-Object Xml.XmlNamespaceManager($sst.NameTable)
                $ns.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main')
                foreach ($si in $sst.SelectNodes('//x:si',$ns)) {
                    $parts = @()
                    foreach ($t in $si.SelectNodes('.//x:t',$ns)) { $parts += $t.InnerText }
                    $shared += ($parts -join '')
                }
            }

            [xml]$wb = Entry-Text 'xl/workbook.xml'
            [xml]$rels = Entry-Text 'xl/_rels/workbook.xml.rels'
            $nsw = New-Object Xml.XmlNamespaceManager($wb.NameTable)
            $nsw.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main')
            $nsw.AddNamespace('r','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
            $nsr = New-Object Xml.XmlNamespaceManager($rels.NameTable)
            $nsr.AddNamespace('p','http://schemas.openxmlformats.org/package/2006/relationships')
            $sheetNode = $wb.SelectSingleNode("//x:sheet[@name='工单']",$nsw)
            if (!$sheetNode) { throw "Khong tim thay sheet 工单" }
            $rid = $sheetNode.GetAttribute('id','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
            $rel = $rels.SelectSingleNode("//p:Relationship[@Id='$rid']",$nsr)
            if (!$rel) { throw 'Khong tim thay quan he sheet 工单' }
            $target = $rel.Target
            if ($target.StartsWith('/')) { $sheetPath = $target.TrimStart('/') }
            elseif ($target.StartsWith('xl/')) { $sheetPath = $target }
            else { $sheetPath = 'xl/' + $target.TrimStart('/') }

            [xml]$sheet = Entry-Text $sheetPath
            $nss = New-Object Xml.XmlNamespaceManager($sheet.NameTable)
            $nss.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main')

            function Cell-Value($c) {
                $t = $c.GetAttribute('t')
                $vNode = $c.SelectSingleNode('./x:v',$nss)
                if (!$vNode) {
                    $inline = $c.SelectSingleNode('./x:is/x:t',$nss)
                    if ($inline) { return $inline.InnerText }
                    return ''
                }
                $v = $vNode.InnerText
                if ($t -eq 's') {
                    $idx = 0
                    if ([int]::TryParse($v,[ref]$idx) -and $idx -ge 0 -and $idx -lt $shared.Count) { return $shared[$idx] }
                }
                return $v
            }

            $rows = New-Object System.Collections.Generic.List[object]
            foreach ($row in $sheet.SelectNodes('//x:sheetData/x:row',$nss)) {
                $rn = [int]$row.r
                if ($rn -lt 4) { continue }
                $vals = @{}
                foreach ($c in $row.SelectNodes('./x:c',$nss)) {
                    $ref = $c.r
                    $m = [regex]::Match($ref,'^[A-Z]+')
                    if (!$m.Success) { continue }
                    $col = $m.Value
                    if ($col -in @('D','E','F','G','H','I','J','K','L','M','N','O','Q','R','U','V')) {
                        $vals[$col] = Cell-Value $c
                    }
                }
                $wo = [string]$vals['G']
                if ([string]::IsNullOrWhiteSpace($wo)) { continue }
                $status = [string]$vals['E']
                if ($status -ne 'FINISH' -and $status -ne 'WAITING') {
                    $r = Num-OrZero $vals['R']
                    $status = if ($r -ge 0) { 'FINISH' } else { 'WAITING' }
                }
                $obj = [pscustomobject]@{
                    workOrder = $wo.Trim()
                    status = $status
                    receivedDate = ExcelDate-ToString $vals['D']
                    customer = [string]$vals['F']
                    material = [string]$vals['H']
                    materialName = [string]$vals['I']
                    spec = [string]$vals['J']
                    orderQty = Num-OrZero $vals['K']
                    inputQty = Num-OrZero $vals['L']
                    issuedQty = Num-OrZero $vals['M']
                    transferredQty = Num-OrZero $vals['N']
                    missingReturnXLN = Num-OrZero $vals['O']
                    ngQty = Num-OrZero $vals['Q']
                    notOkQty = Num-OrZero $vals['R']
                    shipDate = ExcelDate-ToString $vals['U']
                    issueDiff = Num-OrZero $vals['V']
                }
                $rows.Add($obj)
            }
            Write-Host ("Da nap {0:N0} cong don." -f $rows.Count) -ForegroundColor Green
            return $rows
        } finally { $zip.Dispose() }
    } finally { $fs.Dispose() }
}


function Read-XlsxConversionMap([string]$path) {
    $map = @{}
    $fs = [System.IO.File]::Open($path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
    try {
        $zip = New-Object System.IO.Compression.ZipArchive($fs, [System.IO.Compression.ZipArchiveMode]::Read, $false)
        try {
            function Entry-Text2([string]$name) {
                $e = $zip.GetEntry($name)
                if (!$e) { return $null }
                $sr = New-Object IO.StreamReader($e.Open(), [Text.Encoding]::UTF8)
                try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
            }
            $shared = @()
            $sstText = Entry-Text2 'xl/sharedStrings.xml'
            if ($sstText) {
                [xml]$sst = $sstText
                $ns = New-Object Xml.XmlNamespaceManager($sst.NameTable)
                $ns.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main')
                foreach ($si in $sst.SelectNodes('//x:si',$ns)) {
                    $parts = @(); foreach ($t in $si.SelectNodes('.//x:t',$ns)) { $parts += $t.InnerText }
                    $shared += ($parts -join '')
                }
            }
            [xml]$wb = Entry-Text2 'xl/workbook.xml'
            [xml]$rels = Entry-Text2 'xl/_rels/workbook.xml.rels'
            $nsw = New-Object Xml.XmlNamespaceManager($wb.NameTable)
            $nsw.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main')
            $nsw.AddNamespace('r','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
            $nsr = New-Object Xml.XmlNamespaceManager($rels.NameTable)
            $nsr.AddNamespace('p','http://schemas.openxmlformats.org/package/2006/relationships')
            $sheetNode = $wb.SelectSingleNode("//x:sheet[@name='入库-转包装-转生管']",$nsw)
            if (!$sheetNode) { return $map }
            $rid = $sheetNode.GetAttribute('id','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
            $rel = $rels.SelectSingleNode("//p:Relationship[@Id='$rid']",$nsr)
            if (!$rel) { return $map }
            $target = $rel.Target
            if ($target.StartsWith('/')) { $sheetPath = $target.TrimStart('/') }
            elseif ($target.StartsWith('xl/')) { $sheetPath = $target }
            else { $sheetPath = 'xl/' + $target.TrimStart('/') }
            [xml]$sheet = Entry-Text2 $sheetPath
            $nss = New-Object Xml.XmlNamespaceManager($sheet.NameTable)
            $nss.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main')
            function Cell-Value2($c) {
                $t = $c.GetAttribute('t'); $vNode = $c.SelectSingleNode('./x:v',$nss)
                if (!$vNode) { return '' }
                $v = $vNode.InnerText
                if ($t -eq 's') { $ix=0; if ([int]::TryParse($v,[ref]$ix) -and $ix -lt $shared.Count) { return $shared[$ix] } }
                return $v
            }
            foreach ($row in $sheet.SelectNodes('//x:sheetData/x:row',$nss)) {
                if ([int]$row.r -lt 5) { continue }
                $vals=@{}
                foreach ($c in $row.SelectNodes('./x:c',$nss)) {
                    $m=[regex]::Match($c.r,'^[A-Z]+'); if(!$m.Success){continue}
                    $col=$m.Value; if($col -in @('E','G','Q')){$vals[$col]=Cell-Value2 $c}
                }
                $material=([string]$vals['G']).Trim(); if([string]::IsNullOrWhiteSpace($material)){continue}
                $ratio=Num-OrZero $vals['Q']; if($ratio -le 0){continue}
                $dateScore=Num-OrZero $vals['E']
                if($dateScore -le 0){ try{$dateScore=([datetime]$vals['E']).Ticks}catch{$dateScore=0} }
                $key=$material.ToUpperInvariant()
                if(!$map.ContainsKey($key) -or $dateScore -ge $map[$key].dateScore){
                    $map[$key]=[pscustomobject]@{ratio=$ratio;dateScore=$dateScore}
                }
            }
            return $map
        } finally { $zip.Dispose() }
    } finally { $fs.Dispose() }
}




function Read-XlsxSheetRows([string]$path, [string[]]$sheetNames, [int]$minRow, [string[]]$wantedCols) {
    $fs=[System.IO.File]::Open($path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
    try {
        $zip=New-Object System.IO.Compression.ZipArchive($fs,[System.IO.Compression.ZipArchiveMode]::Read,$false)
        try {
            function EntryTextDetail([string]$name){$e=$zip.GetEntry($name);if(!$e){return $null};$sr=New-Object IO.StreamReader($e.Open(),[Text.Encoding]::UTF8);try{return $sr.ReadToEnd()}finally{$sr.Dispose()}}
            $shared=@();$sstText=EntryTextDetail 'xl/sharedStrings.xml'
            if($sstText){[xml]$sst=$sstText;$ns=New-Object Xml.XmlNamespaceManager($sst.NameTable);$ns.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main');foreach($si in $sst.SelectNodes('//x:si',$ns)){$parts=@();foreach($t in $si.SelectNodes('.//x:t',$ns)){$parts+=$t.InnerText};$shared+=($parts-join '')}}
            [xml]$wb=EntryTextDetail 'xl/workbook.xml';[xml]$rels=EntryTextDetail 'xl/_rels/workbook.xml.rels'
            $nsw=New-Object Xml.XmlNamespaceManager($wb.NameTable);$nsw.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main');$nsw.AddNamespace('r','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
            $nsr=New-Object Xml.XmlNamespaceManager($rels.NameTable);$nsr.AddNamespace('p','http://schemas.openxmlformats.org/package/2006/relationships')
            $sn=$null
            foreach($nm in $sheetNames){$safe=$nm.Replace("'","&apos;");$sn=$wb.SelectSingleNode("//x:sheet[@name='$safe']",$nsw);if($sn){break}}
            if(!$sn){throw ('Không tìm thấy sheet: '+($sheetNames -join ' / '))}
            $rid=$sn.GetAttribute('id','http://schemas.openxmlformats.org/officeDocument/2006/relationships');$rel=$rels.SelectSingleNode("//p:Relationship[@Id='$rid']",$nsr);if(!$rel){throw 'Không tìm thấy quan hệ sheet'}
            $target=$rel.Target;if($target.StartsWith('/')){$sheetPath=$target.TrimStart('/')}elseif($target.StartsWith('xl/')){$sheetPath=$target}else{$sheetPath='xl/'+$target.TrimStart('/')}
            [xml]$sheet=EntryTextDetail $sheetPath;$nss=New-Object Xml.XmlNamespaceManager($sheet.NameTable);$nss.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main')
            function CVDetail($c){
                $t=$c.GetAttribute('t')
                if($t -eq 'inlineStr'){$tn=$c.SelectNodes('.//x:t',$nss);if($tn){return (($tn|ForEach-Object{$_.InnerText})-join '')}}
                $vn=$c.SelectSingleNode('./x:v',$nss);if(!$vn){return ''};$v=$vn.InnerText
                if($t -eq 's'){$ix=0;if([int]::TryParse($v,[ref]$ix)-and $ix -ge 0 -and $ix -lt $shared.Count){return $shared[$ix]}}
                return $v
            }
            $out=@()
            foreach($row in $sheet.SelectNodes('//x:sheetData/x:row',$nss)){
                $rn=[int]$row.r;if($rn -lt $minRow){continue};$v=@{}
                foreach($c in $row.SelectNodes('./x:c',$nss)){$m=[regex]::Match($c.r,'^[A-Z]+');if(!$m.Success){continue};$col=$m.Value;if($wantedCols -contains $col){$v[$col]=CVDetail $c}}
                $v['_ROW']=$rn;$out+=,$v
            }
            return $out
        } finally {$zip.Dispose()}
    } finally {$fs.Dispose()}
}

function Detail-DateString([string]$raw) {
    if([string]::IsNullOrWhiteSpace($raw)){return ''}
    $serial=0.0
    if([double]::TryParse($raw,[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$serial)-and $serial -gt 1 -and $serial -lt 100000){try{return [datetime]::FromOADate($serial).ToString('dd/MM/yyyy')}catch{}}
    $d=[datetime]::MinValue
    if([datetime]::TryParse($raw,[Globalization.CultureInfo]::GetCultureInfo('vi-VN'),[Globalization.DateTimeStyles]::None,[ref]$d)){return $d.ToString('dd/MM/yyyy')}
    return $raw
}

function Read-XlsxIssueDetailsByWo([string]$path,[string]$workOrder) {
    $rows=Read-XlsxSheetRows $path @('领料 ','领料-退料','领料') 4 @('D','E','F','G','H','I','J','K','L','M')
    $out=@();$totalQty=0.0;$totalKg=0.0
    foreach($v in $rows){$wo=([string]$v['E']).Trim();if(!$wo.Equals($workOrder,[StringComparison]::OrdinalIgnoreCase)){continue};$iq=Num-OrZero $v['J'];$kg=Num-OrZero $v['K'];$totalQty+=$iq;$totalKg+=$kg;$out += [pscustomobject]@{date=Detail-DateString ([string]$v['D']);workOrder=$wo;material=([string]$v['F']).Trim();productName=([string]$v['G']).Trim();spec=([string]$v['H']).Trim();inputQty=Num-OrZero $v['I'];issuedQty=$iq;kg=$kg;erp=([string]$v['L']).Trim();customer=([string]$v['M']).Trim();rowNumber=[int]$v['_ROW']}}
    return [pscustomobject]@{rows=$out;count=$out.Count;totalQty=$totalQty;totalKg=$totalKg}
}

function Read-XlsxXlnDetailsByWo([string]$path,[string]$workOrder) {
    $rows=Read-XlsxSheetRows $path @('入库-转包装-转生管') 6 @('E','F','G','H','I','J','K','L','M','N','P','Q')
    $out=@();$totalQty=0.0;$totalKg=0.0
    foreach($v in $rows){$wo=([string]$v['F']).Trim();if(!$wo.Equals($workOrder,[StringComparison]::OrdinalIgnoreCase)){continue};$qty=Num-OrZero $v['K'];$kg=Num-OrZero $v['L'];$totalQty+=$qty;$totalKg+=$kg;$out += [pscustomobject]@{date=Detail-DateString ([string]$v['E']);workOrder=$wo;material=([string]$v['G']).Trim();productName=([string]$v['H']).Trim();spec=([string]$v['I']).Trim();unit=([string]$v['J']).Trim();qty=$qty;kg=$kg;status=([string]$v['M']).Trim();note=([string]$v['N']).Trim();line=([string]$v['P']).Trim();pcsPerKg=Num-OrZero $v['Q'];rowNumber=[int]$v['_ROW']}}
    $rate=if($totalKg -gt 0){$totalQty/$totalKg}else{0.0}
    return [pscustomobject]@{rows=$out;count=$out.Count;totalQty=$totalQty;totalKg=$totalKg;rate=$rate}
}



function Build-IssueDetailsIndex([string]$path) {
    $rows=Read-XlsxSheetRows $path @('领料 ','领料-退料','领料') 4 @('D','E','F','G','H','I','J','K','L','M')
    $idx=@{}
    foreach($v in $rows){
        $wo=([string]$v['E']).Trim(); if([string]::IsNullOrWhiteSpace($wo)){continue}
        $key=$wo.ToUpperInvariant()
        if(!$idx.ContainsKey($key)){$idx[$key]=New-Object System.Collections.Generic.List[object]}
        $idx[$key].Add([pscustomobject]@{date=Detail-DateString ([string]$v['D']);workOrder=$wo;material=([string]$v['F']).Trim();productName=([string]$v['G']).Trim();spec=([string]$v['H']).Trim();inputQty=Num-OrZero $v['I'];issuedQty=Num-OrZero $v['J'];kg=Num-OrZero $v['K'];erp=([string]$v['L']).Trim();customer=([string]$v['M']).Trim();rowNumber=[int]$v['_ROW']})
    }
    return $idx
}

function Build-XlnDetailsIndex([string]$path) {
    $rows=Read-XlsxSheetRows $path @('入库-转包装-转生管') 6 @('E','F','G','H','I','J','K','L','M','N','P','Q')
    $idx=@{}
    foreach($v in $rows){
        $wo=([string]$v['F']).Trim(); if([string]::IsNullOrWhiteSpace($wo)){continue}
        $key=$wo.ToUpperInvariant()
        if(!$idx.ContainsKey($key)){$idx[$key]=New-Object System.Collections.Generic.List[object]}
        $idx[$key].Add([pscustomobject]@{date=Detail-DateString ([string]$v['E']);workOrder=$wo;material=([string]$v['G']).Trim();productName=([string]$v['H']).Trim();spec=([string]$v['I']).Trim();unit=([string]$v['J']).Trim();qty=Num-OrZero $v['K'];kg=Num-OrZero $v['L'];status=([string]$v['M']).Trim();note=([string]$v['N']).Trim();line=([string]$v['P']).Trim();pcsPerKg=Num-OrZero $v['Q'];rowNumber=[int]$v['_ROW']})
    }
    return $idx
}

function Get-IssueDetailsFromCache([string]$workOrder) {
    $key=$workOrder.ToUpperInvariant()
    [object[]]$rows=@()
    if($script:IssueDetailsByWo.ContainsKey($key)){
        # Windows PowerShell 5.1 can throw "Argument types do not match"
        # when @() directly enumerates a Generic.List[object]. Convert it first.
        $list=$script:IssueDetailsByWo[$key]
        if($null -ne $list){ if($list.PSObject.Methods['ToArray']){[object[]]$rows=$list.ToArray()}else{$tmp=New-Object System.Collections.Generic.List[object];foreach($x in $list){$tmp.Add($x)};[object[]]$rows=$tmp.ToArray()} }
    }
    $totalQty=0.0;$totalKg=0.0
    foreach($r in $rows){$totalQty += [double]$r.issuedQty; $totalKg += [double]$r.kg}
    return [pscustomobject]@{rows=$rows;count=$rows.Count;totalQty=$totalQty;totalKg=$totalKg}
}

function Get-XlnDetailsFromCache([string]$workOrder) {
    $key=$workOrder.ToUpperInvariant()
    [object[]]$rows=@()
    if($script:XlnDetailsByWo.ContainsKey($key)){
        # Same PowerShell 5.1 generic-list binder fix as issue details.
        $list=$script:XlnDetailsByWo[$key]
        if($null -ne $list){ if($list.PSObject.Methods['ToArray']){[object[]]$rows=$list.ToArray()}else{$tmp=New-Object System.Collections.Generic.List[object];foreach($x in $list){$tmp.Add($x)};[object[]]$rows=$tmp.ToArray()} }
    }
    $totalQty=0.0;$totalKg=0.0
    foreach($r in $rows){$totalQty += [double]$r.qty; $totalKg += [double]$r.kg}
    $rate=if($totalKg -gt 0){$totalQty/$totalKg}else{0.0}
    return [pscustomobject]@{rows=$rows;count=$rows.Count;totalQty=$totalQty;totalKg=$totalKg;rate=$rate}
}

function Read-XlsxTodayXlnDetails([string]$path) {
    $out=[pscustomobject]@{ workOrderCount=0; rowCount=0; totalQty=0.0; totalKg=0.0; rows=@() }
    $fs=[System.IO.File]::Open($path,[System.IO.FileMode]::Open,[System.IO.FileAccess]::Read,[System.IO.FileShare]::ReadWrite)
    try {
        $zip=New-Object System.IO.Compression.ZipArchive($fs,[System.IO.Compression.ZipArchiveMode]::Read,$false)
        try {
            function EntryTextTX([string]$name){$e=$zip.GetEntry($name);if(!$e){return $null};$sr=New-Object IO.StreamReader($e.Open(),[Text.Encoding]::UTF8);try{return $sr.ReadToEnd()}finally{$sr.Dispose()}}
            $shared=@();$sstText=EntryTextTX 'xl/sharedStrings.xml'
            if($sstText){[xml]$sst=$sstText;$ns=New-Object Xml.XmlNamespaceManager($sst.NameTable);$ns.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main');foreach($si in $sst.SelectNodes('//x:si',$ns)){$parts=@();foreach($t in $si.SelectNodes('.//x:t',$ns)){$parts+=$t.InnerText};$shared+=($parts-join '')}}
            [xml]$wb=EntryTextTX 'xl/workbook.xml';[xml]$rels=EntryTextTX 'xl/_rels/workbook.xml.rels'
            $nsw=New-Object Xml.XmlNamespaceManager($wb.NameTable);$nsw.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main');$nsw.AddNamespace('r','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
            $nsr=New-Object Xml.XmlNamespaceManager($rels.NameTable);$nsr.AddNamespace('p','http://schemas.openxmlformats.org/package/2006/relationships')
            $sn=$wb.SelectSingleNode("//x:sheet[@name='入库-转包装-转生管']",$nsw);if(!$sn){return $out}
            $rid=$sn.GetAttribute('id','http://schemas.openxmlformats.org/officeDocument/2006/relationships');$rel=$rels.SelectSingleNode("//p:Relationship[@Id='$rid']",$nsr);if(!$rel){return $out}
            $target=$rel.Target;if($target.StartsWith('/')){$sheetPath=$target.TrimStart('/')}elseif($target.StartsWith('xl/')){$sheetPath=$target}else{$sheetPath='xl/'+$target.TrimStart('/')}
            [xml]$sheet=EntryTextTX $sheetPath;$nss=New-Object Xml.XmlNamespaceManager($sheet.NameTable);$nss.AddNamespace('x','http://schemas.openxmlformats.org/spreadsheetml/2006/main')
            function CVTX($c){
                $t=$c.GetAttribute('t')
                if($t -eq 'inlineStr'){$tn=$c.SelectNodes('.//x:t',$nss);if($tn){return (($tn|ForEach-Object{$_.InnerText})-join '')}}
                $vn=$c.SelectSingleNode('./x:v',$nss);if(!$vn){return ''};$v=$vn.InnerText
                if($t -eq 's'){$ix=0;if([int]::TryParse($v,[ref]$ix)-and $ix -ge 0 -and $ix -lt $shared.Count){return $shared[$ix]}}
                return $v
            }
            function DateTX([string]$raw){
                $d=[datetime]::MinValue;$serial=0.0
                if([double]::TryParse($raw,[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$serial)-and $serial -gt 1 -and $serial -lt 100000){try{return [datetime]::FromOADate($serial)}catch{}}
                $formats=@('dd/MM/yyyy','d/M/yyyy','dd-MM-yyyy','d-M-yyyy','yyyy-MM-dd','yyyy/M/d','MM/dd/yyyy')
                if([datetime]::TryParseExact($raw,$formats,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$d)){return $d}
                if([datetime]::TryParse($raw,[Globalization.CultureInfo]::GetCultureInfo('vi-VN'),[Globalization.DateTimeStyles]::None,[ref]$d)){return $d}
                return [datetime]::MinValue
            }
            $today=(Get-Date).Date;$rows=@();$wos=@{}
            foreach($row in $sheet.SelectNodes('//x:sheetData/x:row',$nss)){
                $rn=[int]$row.r;if($rn -lt 6){continue};$v=@{}
                foreach($c in $row.SelectNodes('./x:c',$nss)){$m=[regex]::Match($c.r,'^[A-Z]+');if(!$m.Success){continue};$col=$m.Value;if($col -in @('E','F','G','I','K','L','M','N','Q')){$v[$col]=CVTX $c}}
                $wo=([string]$v['F']).Trim();if([string]::IsNullOrWhiteSpace($wo)){continue}
                $dt=DateTX ([string]$v['E']);if($dt -eq [datetime]::MinValue -or $dt.Date -ne $today){continue}
                $qty=Num-OrZero $v['K'];$kg=Num-OrZero $v['L'];$rate=Num-OrZero $v['Q']
                $rows += [pscustomobject]@{
                    rowNumber=$rn; date=$dt.ToString('dd/MM/yyyy'); workOrder=$wo;
                    material=([string]$v['G']).Trim(); spec=([string]$v['I']).Trim();
                    qty=$qty; kg=$kg; status=([string]$v['M']).Trim();
                    note=([string]$v['N']).Trim(); pcsPerKg= if($rate -gt 0){[Math]::Round($rate,1,[MidpointRounding]::AwayFromZero)}else{0}
                }
                $wos[$wo.ToUpperInvariant()]=$true
            }
            $rows=@($rows|Sort-Object workOrder,rowNumber)
            return [pscustomobject]@{
                workOrderCount=$wos.Count; rowCount=$rows.Count;
                totalQty=($rows|Measure-Object qty -Sum).Sum;
                totalKg=($rows|Measure-Object kg -Sum).Sum;
                rows=$rows
            }
        } finally {$zip.Dispose()}
    } finally {$fs.Dispose()}
}


# ========================= SFT / IN CONG DON =========================
# Dung dung request da bat tu FIXED92. Tai khoan SFT duoc doc lai tu
# HKCU\\Software\\TraCuuMaLieuTongHopNative\\CNC5102 cua app FIXED92,
# nen khong can luu mat khau SFT vao web/mobile.
$SftHost = 'http://192.168.3.5:8100'
$SftRoot = $SftHost + '/SFT'
$SftCenterPage = $SftRoot + '/main/centerPage/centerPage.jsp?locale=vi_VN'
$SftUserAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
$SftRegistryPath = 'HKCU:\\Software\\TraCuuMaLieuTongHopNative\\CNC5102'
$SftLogDir = Join-Path $Root 'logs'
$SftLogFile = Join-Path $SftLogDir 'SFT_PRINT.log'
function Write-SftLog([string]$level, [string]$message) {
    try {
        if (!(Test-Path $SftLogDir)) { New-Item -ItemType Directory -Path $SftLogDir -Force | Out-Null }
        $line = ('[' + (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '] [' + $level + '] ' + $message)
        Add-Content -LiteralPath $SftLogFile -Value $line -Encoding UTF8
    } catch {}
}


function Load-SftSettingsFromFixed92 {
    $result = [pscustomobject]@{ UserId=''; Password=''; CompanyId='EXWIN2026' }
    try {
        if (!(Test-Path $SftRegistryPath)) { return $result }
        $p = Get-ItemProperty -Path $SftRegistryPath -ErrorAction Stop
        $result.UserId = [string]$p.SftUser
        if (![string]::IsNullOrWhiteSpace([string]$p.SftCompany)) { $result.CompanyId = [string]$p.SftCompany }
        $enc = [string]$p.SftPassword
        if (![string]::IsNullOrWhiteSpace($enc)) {
            try {
                Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
                $protectedBytes = [Convert]::FromBase64String($enc)
                $clear = [System.Security.Cryptography.ProtectedData]::Unprotect(
                    $protectedBytes, $null, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
                $result.Password = [Text.Encoding]::UTF8.GetString($clear)
            } catch { $result.Password = '' }
        }
    } catch {}
    return $result
}

function New-SftWebRequest([string]$url, $cookies, [string]$referer) {
    $req = [System.Net.HttpWebRequest]::Create($url)
    $req.CookieContainer = $cookies
    $req.UserAgent = $SftUserAgent
    $req.Accept = '*/*'
    $req.AllowAutoRedirect = $true
    $req.Timeout = 15000
    $req.ReadWriteTimeout = 15000
    $req.KeepAlive = $true
    if (![string]::IsNullOrWhiteSpace($referer)) { $req.Referer = $referer }
    return $req
}

function Get-SftText([string]$url, $cookies, [string]$referer) {
    $req = New-SftWebRequest $url $cookies $referer
    $req.Method = 'GET'
    $resp = $req.GetResponse()
    try {
        $sr = New-Object IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8, $true)
        try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
    } finally { $resp.Dispose() }
}

function Post-SftText([string]$url, [string]$body, $cookies, [string]$referer) {
    $data = [Text.Encoding]::UTF8.GetBytes([string]$body)
    $req = New-SftWebRequest $url $cookies $referer
    $req.Method = 'POST'
    $req.ContentType = 'text/plain'
    $req.ContentLength = $data.Length
    $out = $req.GetRequestStream()
    try { $out.Write($data,0,$data.Length) } finally { $out.Dispose() }
    try {
        $resp = $req.GetResponse()
        try {
            $sr = New-Object IO.StreamReader($resp.GetResponseStream(), [Text.Encoding]::UTF8, $true)
            try { return $sr.ReadToEnd() } finally { $sr.Dispose() }
        } finally { $resp.Dispose() }
    } catch [System.Net.WebException] {
        $detail = ''
        try {
            if ($_.Exception.Response) {
                $sr = New-Object IO.StreamReader($_.Exception.Response.GetResponseStream(), [Text.Encoding]::UTF8, $true)
                try { $detail = $sr.ReadToEnd() } finally { $sr.Dispose() }
            }
        } catch {}
        throw ('Loi goi SFT DWR: ' + $_.Exception.Message + $(if($detail){"`r`n$detail"}else{''}))
    }
}

function Get-SftBytes([string]$url, $cookies, [string]$referer) {
    $req = New-SftWebRequest $url $cookies $referer
    $req.Method = 'GET'
    $resp = $req.GetResponse()
    try {
        $input = $resp.GetResponseStream()
        try {
            $ms = New-Object IO.MemoryStream
            try { $input.CopyTo($ms); return $ms.ToArray() } finally { $ms.Dispose() }
        } finally { $input.Dispose() }
    } finally { $resp.Dispose() }
}

function Build-SftDwrBody([string]$companyId, [string]$workOrder, [string]$httpSessionId, [string]$scriptSessionId, [string]$batchId) {
    $safeWo = $workOrder.Replace("'",'')
    $p = New-Object System.Collections.Generic.List[string]
    foreach($line in @(
        'callCount=1',
        'page=/SFT/main/centerPage/centerPage.jsp?locale=vi_VN',
        ('httpSessionId=' + $httpSessionId),
        ('scriptSessionId=' + $scriptSessionId),
        'c0-scriptName=RouteForm',
        'c0-methodName=createForm',
        'c0-id=0',
        ('c0-param0=string:' + $companyId),
        'c0-param1=string:perpendi',
        'c0-e2=string:PLANPROCESSST','c0-e3=string:','c0-e1=Array:[reference:c0-e2,reference:c0-e3]',
        'c0-e5=string:PLANPROCESSST','c0-e6=string:','c0-e4=Array:[reference:c0-e5,reference:c0-e6]',
        'c0-e8=string:CMOID','c0-e9=string:','c0-e7=Array:[reference:c0-e8,reference:c0-e9]',
        'c0-e11=string:CMOID','c0-e12=string:','c0-e10=Array:[reference:c0-e11,reference:c0-e12]',
        'c0-e14=string:CMOID',("c0-e15=string:'" + $safeWo + "'"),'c0-e13=Array:[reference:c0-e14,reference:c0-e15]',
        'c0-e17=string:moStatusStr','c0-e18=string:','c0-e16=Array:[reference:c0-e17,reference:c0-e18]',
        'c0-e20=string:EXECUTEQTY','c0-e21=string:','c0-e19=Array:[reference:c0-e20,reference:c0-e21]',
        'c0-e23=string:MO040','c0-e24=string:N','c0-e22=Array:[reference:c0-e23,reference:c0-e24]',
        'c0-param2=Array:[reference:c0-e1,reference:c0-e4,reference:c0-e7,reference:c0-e10,reference:c0-e13,reference:c0-e16,reference:c0-e19,reference:c0-e22]',
        'c0-param3=string:%7B%22isWithNetFlow%22%3A%22-1%22%2C%22withDataCollector%22%3Afalse%2C%22printtype%22%3A%22normal%22%2C%22language%22%3A%22vi_VN%22%2C%22PRINTUSERINFORM%22%3Atrue%2C%22checksplit_checkbox%22%3Afalse%2C%22PRINTSTAFFINFORM%22%3Afalse%7D',
        ('batchId=' + $batchId)
    )) { $p.Add($line) }
    return [string]::Join("`n", $p.ToArray())
}

function Create-SftPdf([string]$workOrder) {
    Write-SftLog 'INFO' ('Bat dau SFT cho ' + $workOrder)
    $settings = Load-SftSettingsFromFixed92
    if ([string]::IsNullOrWhiteSpace($settings.UserId) -or [string]::IsNullOrWhiteSpace($settings.Password) -or [string]::IsNullOrWhiteSpace($settings.CompanyId)) {
        throw 'Chua cau hinh tai khoan SFT. Mo app FIXED92 tren PC -> chuot phai -> Cau hinh SFT... va luu 1 lan.'
    }
    Write-SftLog 'INFO' ('Da doc cau hinh SFT: user=' + $settings.UserId + '; company=' + $settings.CompanyId)
    [System.Net.ServicePointManager]::Expect100Continue = $false
    $cookies = New-Object System.Net.CookieContainer
    Write-SftLog 'INFO' 'Dang ket noi trang login SFT...'
    [void](Get-SftText ($SftRoot + '/login.jsp?locale=vi_VN') $cookies $null)
    $loginUrl = $SftRoot + '/loginInside.jsp?loginTo=SFT&language=vi_VN' +
        '&password=' + [Uri]::EscapeDataString($settings.Password) +
        '&userID=' + [Uri]::EscapeDataString($settings.UserId) +
        '&AUTH_ID=' + [Uri]::EscapeDataString($settings.UserId) +
        '&companyid=' + [Uri]::EscapeDataString($settings.CompanyId)
    [void](Get-SftText $loginUrl $cookies ($SftRoot + '/login.jsp?locale=vi_VN'))

    $jsession = ''
    foreach($c in $cookies.GetCookies([Uri]($SftRoot + '/'))) {
        if ($c.Name -ieq 'JSESSIONID') { $jsession = $c.Value; break }
    }
    if ([string]::IsNullOrWhiteSpace($jsession)) { throw 'SFT khong tra ve JSESSIONID sau khi dang nhap.' }
    Write-SftLog 'INFO' 'Dang nhap SFT thanh cong, da co JSESSIONID.'
    try {
        $cookie = New-Object System.Net.Cookie('company_select', $settings.CompanyId, '/SFT')
        $cookies.Add([Uri]($SftRoot + '/'), $cookie)
    } catch {}

    $batchId = Get-Date -Format 'HHmmssfff'
    $scriptSessionId = ([Guid]::NewGuid().ToString('N').ToUpperInvariant() + (Get-Random -Minimum 1000 -Maximum 9999))
    $body = Build-SftDwrBody $settings.CompanyId $workOrder.Trim() $jsession $scriptSessionId $batchId
    Write-SftLog 'INFO' ('Dang goi RouteForm.createForm.dwr cho ' + $workOrder)
    $response = Post-SftText ($SftRoot + '/dwr/call/plaincall/RouteForm.createForm.dwr') $body $cookies $SftCenterPage
    $m = [regex]::Match([string]$response, '[\"'']([^\"'']*SFTC01[^\"'']*\.pdf)[\"'']', [Text.RegularExpressions.RegexOptions]::IgnoreCase)
    if (!$m.Success) {
        $short = ([string]$response).Replace("`r",' ').Replace("`n",' ').Trim()
        if ($short.Length -gt 500) { $short = $short.Substring(0,500) + '...' }
        throw ('SFT chua tao duoc PDF. Phan hoi: ' + $short)
    }
    $pdfName = $m.Groups[1].Value
    $pdfUrl = $SftRoot + '/report/' + [Uri]::EscapeDataString($pdfName)
    Write-SftLog 'INFO' ('SFT tao PDF: ' + $pdfName)
    $pdf = Get-SftBytes $pdfUrl $cookies $SftCenterPage
    if ($null -eq $pdf -or $pdf.Length -lt 4 -or $pdf[0] -ne 0x25 -or $pdf[1] -ne 0x50 -or $pdf[2] -ne 0x44 -or $pdf[3] -ne 0x46) {
        throw 'SFT da tao ten file nhung noi dung tai ve khong phai PDF.'
    }
    $dir = Join-Path $Root 'SFT_PDF'
    if (!(Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
    $safeWo = [regex]::Replace($workOrder, '[^0-9A-Za-z_-]', '_')
    $localPath = Join-Path $dir ('SFT_' + $safeWo + '_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.pdf')
    [IO.File]::WriteAllBytes($localPath, $pdf)
    Write-SftLog 'INFO' ('Da tai PDF ve: ' + $localPath)
    return $localPath
}

function Find-SumatraPdf {
    $candidates = @(
        (Join-Path $Root 'tools\SumatraPDF.exe'),
        (Join-Path $env:LOCALAPPDATA 'SumatraPDF\SumatraPDF.exe'),
        (Join-Path $env:ProgramFiles 'SumatraPDF\SumatraPDF.exe')
    )
    if (${env:ProgramFiles(x86)}) {
        $candidates += (Join-Path ${env:ProgramFiles(x86)} 'SumatraPDF\SumatraPDF.exe')
    }
    foreach ($p in $candidates) {
        if ($p -and (Test-Path $p)) { return $p }
    }
    return $null
}

function Invoke-SftPdfPrint([string]$pdfPath, [int]$copies = 1) {
    Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
    $printerName = ''
    try { $printerName = (New-Object System.Drawing.Printing.PrinterSettings).PrinterName } catch {}
    if ([string]::IsNullOrWhiteSpace($printerName)) {
        throw 'PC chua co may in mac dinh. Hay chon may RICOH lam Default printer trong Windows.'
    }
    if ($copies -lt 1) { $copies = 1 }
    if ($copies -gt 10) { $copies = 10 }

    $sumatra = Find-SumatraPdf
    if ([string]::IsNullOrWhiteSpace($sumatra)) {
        Write-SftLog 'ERROR' 'Khong tim thay SumatraPDF.exe. Khong fallback sang WPS.'
        throw 'Chua co SumatraPDF tren PC. Hay chay INSTALL_SUMATRA.bat mot lan.'
    }

    $worker = Join-Path $PSScriptRoot 'Print-Ricoh-A5-Worker.ps1'
    if (!(Test-Path -LiteralPath $worker)) { throw 'Thieu Print-Ricoh-A5-Worker.ps1.' }

    Write-SftLog 'INFO' ('Print V2.28 isolated; printer=' + $printerName + '; copies=' + $copies + '; paperkind=11(A5); duplexlong; fit')

    $argList = @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', ('"' + $worker + '"'),
        '-PrinterName', ('"' + $printerName + '"'),
        '-PdfPath', ('"' + $pdfPath + '"'),
        '-SumatraPath', ('"' + $sumatra + '"'),
        '-Copies', ([string]$copies),
        '-LogPath', ('"' + $SftLogFile + '"')
    )
    try {
        $wp = Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -PassThru -WindowStyle Hidden -Wait -ErrorAction Stop
        if ($null -eq $wp) { throw 'Khong khoi dong duoc print worker.' }
        if ($wp.ExitCode -ne 0) {
            Write-SftLog 'ERROR' ('Print worker ExitCode=' + $wp.ExitCode + '. Server van tiep tuc chay.')
            throw ('Khong in duoc. Worker ExitCode=' + $wp.ExitCode + '. Server van dang chay; xem SFT_PRINT.log.')
        }
        Write-SftLog 'INFO' 'Print worker hoan thanh. Server van hoat dong.'
        return [pscustomobject]@{
            printer=$printerName
            method='Sumatra paperkind=11 isolated'
            copies=$copies
            duplex='A5 RAWKIND 11 + Duplex Long Edge'
        }
    } catch {
        Write-SftLog 'ERROR' ('Print isolated loi, KHONG tat server: ' + $_.Exception.Message)
        throw $_
    }
}


function Start-SftPrintBackground([string]$workOrder, [int]$copies = 1) {
    if ([string]::IsNullOrWhiteSpace($workOrder)) { throw 'Thieu cong don.' }
    if ($copies -lt 1) { $copies = 1 }
    if ($copies -gt 10) { $copies = 10 }

    $bg = Join-Path $PSScriptRoot 'SFT-Print-Standalone.ps1'
    if (!(Test-Path -LiteralPath $bg)) { throw 'Thieu SFT-Print-Standalone.ps1.' }

    Write-SftLog 'INFO' ('V2.31 QUEUE STANDALONE: ' + $workOrder + '; copies=' + $copies)

    $args = @(
        '-NoProfile','-ExecutionPolicy','Bypass',
        '-File',('"' + $bg + '"'),
        '-AppRoot',('"' + $Root + '"'),
        '-WorkOrder',('"' + $workOrder + '"'),
        '-Copies',([string]$copies),
        '-LogPath',('"' + $SftLogFile + '"')
    )
    $p = Start-Process -FilePath 'powershell.exe' -ArgumentList $args -PassThru -WindowStyle Hidden -ErrorAction Stop
    if ($null -eq $p) { throw 'Khong tao duoc SFT standalone worker.' }

    return [pscustomobject]@{
        queued=$true; pid=$p.Id; workOrder=$workOrder; copies=$copies
        message='Da nhan lenh in. Worker SFT doc lap dang xu ly.'
    }
}

# ======================= END SFT / IN CONG DON =======================

function Normalize-WorkOrder([string]$s) {
    if ($null -eq $s) { return '' }
    $s = $s.Trim()
    if ($s -match '^\d{9}$') { return '5102-' + $s }
    return $s
}

function Mime-Type([string]$path) {
    switch ([IO.Path]::GetExtension($path).ToLower()) {
        '.html' { 'text/html; charset=utf-8' }
        '.js' { 'application/javascript; charset=utf-8' }
        '.css' { 'text/css; charset=utf-8' }
        '.json' { 'application/json; charset=utf-8' }
        '.svg' { 'image/svg+xml' }
        '.png' { 'image/png' }
        '.pdf' { 'application/pdf' }
        default { 'application/octet-stream' }
    }
}

function Send-Response($stream, [int]$status, [string]$type, [byte[]]$body, [hashtable]$extraHeaders=$null) {
    # Mobile browsers may cancel icon/cache/service-worker requests while the
    # response is being written. That is normal and must not be treated as a
    # server failure.
    if ($null -eq $stream -or !$stream.CanWrite) { return $false }
    try {
        $statusText = @{200='OK';400='Bad Request';401='Unauthorized';404='Not Found';500='Internal Server Error'}[$status]
        if (!$statusText) { $statusText = 'OK' }
        $hdr = "HTTP/1.1 $status $statusText`r`nContent-Type: $type`r`nContent-Length: $($body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n"
        if ($extraHeaders) { foreach ($k in $extraHeaders.Keys) { $hdr += "$k`: $($extraHeaders[$k])`r`n" } }
        $hdr += "`r`n"
        $hb = [Text.Encoding]::ASCII.GetBytes($hdr)
        $stream.Write($hb,0,$hb.Length)
        if ($body.Length -gt 0) { $stream.Write($body,0,$body.Length) }
        $stream.Flush()
        return $true
    } catch [System.IO.IOException] {
        return $false
    } catch [System.Net.Sockets.SocketException] {
        return $false
    } catch [System.ObjectDisposedException] {
        return $false
    }
}


# V2.43 background worker mode: parse Excel outside HTTP and persist as flat CSV files.
# We intentionally avoid one giant ConvertTo-Json object because Windows PowerShell 5.1
# becomes extremely slow on large nested detail indexes.
if ($BuildCacheOnly) {
    $workerCacheLog=''
    try {
        if([string]::IsNullOrWhiteSpace($BuildExcelPath) -or !(Test-Path $BuildExcelPath)){ throw 'BuildExcelPath khong hop le' }
        if([string]::IsNullOrWhiteSpace($BuildCachePath)){ throw 'BuildCachePath khong hop le' }
        $workerCacheDir=Split-Path -Parent $BuildCachePath
        if(!(Test-Path $workerCacheDir)){New-Item -ItemType Directory -Path $workerCacheDir -Force|Out-Null}
        $workerCacheLog=Join-Path $workerCacheDir 'cache-refresh.log'
        $lockPath=$BuildCachePath+'.lock'
        [IO.File]::WriteAllText($lockPath,[string]$PID,(New-Object Text.UTF8Encoding($false)))
        function BuildLog([string]$m){ try{Add-Content $workerCacheLog ('[{0}] {1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'),$m) -Encoding UTF8}catch{} }
        function Get-CanonicalFileHash([string]$path){
            if([string]::IsNullOrWhiteSpace($path) -or !(Test-Path -LiteralPath $path)){ return '' }
            $lines=@(Get-Content -LiteralPath $path -Encoding UTF8)
            if($lines.Count -le 0){ $canon='' }
            elseif($lines.Count -eq 1){ $canon=[string]$lines[0] }
            else {
                $header=[string]$lines[0]
                $body=@($lines[1..($lines.Count-1)] | Sort-Object)
                $canon=$header+"`n"+($body -join "`n")
            }
            $shaLocal=[System.Security.Cryptography.SHA256]::Create()
            try {
                $bytes=[Text.Encoding]::UTF8.GetBytes($canon)
                return ([BitConverter]::ToString($shaLocal.ComputeHash($bytes))).Replace('-','')
            } finally { $shaLocal.Dispose() }
        }
        function Get-CacheBundleHash([string[]]$paths){
            $parts=@(); foreach($pp in @($paths)){ $parts += (Get-CanonicalFileHash $pp) }
            if(@($parts | Where-Object { [string]::IsNullOrWhiteSpace([string]$_) }).Count -gt 0){ return '' }
            $text=($parts -join '|')
            $shaBundle=[System.Security.Cryptography.SHA256]::Create()
            try {
                $bytes=[Text.Encoding]::UTF8.GetBytes($text)
                return ([BitConverter]::ToString($shaBundle.ComputeHash($bytes))).Replace('-','')
            } finally { $shaBundle.Dispose() }
        }
        BuildLog ('BUILD START PID={0}' -f $PID)
        $fiBefore=Get-Item $BuildExcelPath
        $excelContentHashBefore=Get-ExcelFileContentHash $BuildExcelPath
        if([string]::IsNullOrWhiteSpace($excelContentHashBefore)){ throw 'SAVE GATE: Khong doc duoc hash noi dung Excel truoc khi build.' }
        BuildLog ('EXCEL CONTENT HASH BEFORE: '+$excelContentHashBefore)

        # V2.75 upgrade-safe comparison: hash the currently published cache in the worker,
        # so the main HTTP process can skip a blocking re-import even on the first V2.75 reload.
        $previousDataHash=''
        $previousBuiltAt=''
        try {
            if(Test-Path -LiteralPath $BuildCachePath){
                $oldMetaRaw=Get-Content -LiteralPath $BuildCachePath -Raw -Encoding UTF8
                if(![string]::IsNullOrWhiteSpace($oldMetaRaw)){
                    $oldMeta=$oldMetaRaw|ConvertFrom-Json
                    $previousBuiltAt=[string]$oldMeta.builtAt
                    if(![string]::IsNullOrWhiteSpace([string]$oldMeta.dataHash)){
                        $previousDataHash=([string]$oldMeta.dataHash).Trim().ToUpperInvariant()
                    } else {
                        $oldPaths=@(
                            (Join-Path $workerCacheDir ([string]$oldMeta.coreFile)),
                            (Join-Path $workerCacheDir ([string]$oldMeta.conversionFile)),
                            (Join-Path $workerCacheDir ([string]$oldMeta.todayFile)),
                            (Join-Path $workerCacheDir ([string]$oldMeta.issueFile)),
                            (Join-Path $workerCacheDir ([string]$oldMeta.xlnFile))
                        )
                        $previousDataHash=Get-CacheBundleHash $oldPaths
                    }
                    if($previousDataHash){ BuildLog ('PREVIOUS DATA HASH: '+$previousDataHash) }
                }
            }
        } catch { BuildLog ('PREVIOUS DATA HASH ERROR: '+$_.Exception.Message) }

        BuildLog 'STEP 1/10: Doc sheet cong don...'
        $rows=Read-XlsxWorkOrders $BuildExcelPath
        BuildLog ('STEP 1 OK: rows={0}' -f $rows.Count)
        if($null -eq $rows -or [int]$rows.Count -le 0){ throw 'VALIDATION: Excel tra ve 0 cong don. KHONG publish cache rong.' }

        BuildLog 'STEP 2/10: Doc quy doi...'
        $conv=Read-XlsxConversionMap $BuildExcelPath
        BuildLog ('STEP 2 OK: conversionKeys={0}' -f $conv.Count)

        BuildLog 'STEP 3/10: Doc XLN hom nay...'
        $today=Read-XlsxTodayXlnDetails $BuildExcelPath
        BuildLog ('STEP 3 OK: todayRows={0}' -f $today.rowCount)

        BuildLog 'STEP 4/10: Doc chi tiet linh lieu...'
        $issue=Build-IssueDetailsIndex $BuildExcelPath
        BuildLog ('STEP 4 OK: issueKeys={0}' -f $issue.Count)

        BuildLog 'STEP 5/10: Doc chi tiet chuyen XLN...'
        $xln=Build-XlnDetailsIndex $BuildExcelPath
        BuildLog ('STEP 5 OK: xlnKeys={0}' -f $xln.Count)
        $fiAfter=Get-Item $BuildExcelPath
        $excelContentHashAfter=Get-ExcelFileContentHash $BuildExcelPath
        if([string]::IsNullOrWhiteSpace($excelContentHashAfter)){ throw 'SAVE GATE: Khong doc duoc hash noi dung Excel sau khi build.' }
        if($excelContentHashAfter -ne $excelContentHashBefore){ throw 'SAVE GATE: Excel da thay doi trong luc worker dang doc. Huy cache nay va cho lan save on dinh tiep theo.' }
        BuildLog ('EXCEL CONTENT HASH AFTER: '+$excelContentHashAfter)

        $buildId=((Get-Date).ToString('yyyyMMddHHmmssfff'))+'_'+$PID
        $coreName='workorders.'+$buildId+'.cache.csv'
        $convName='conversion.'+$buildId+'.cache.csv'
        $todayName='todayxln.'+$buildId+'.cache.csv'
        $issueName='issue.'+$buildId+'.cache.csv'
        $xlnName='xln.'+$buildId+'.cache.csv'
        $corePath=Join-Path $workerCacheDir $coreName
        $convPath=Join-Path $workerCacheDir $convName
        $todayPath=Join-Path $workerCacheDir $todayName
        $issuePath=Join-Path $workerCacheDir $issueName
        $xlnPath=Join-Path $workerCacheDir $xlnName

        BuildLog 'STEP 6/10: Ghi workorders CSV...'
        $rows | Export-Csv -LiteralPath $corePath -NoTypeInformation -Encoding UTF8
        BuildLog ('STEP 6 OK: size={0}' -f (Get-Item $corePath).Length)

        BuildLog 'STEP 7/10: Ghi conversion + today CSV...'
        & {
            foreach($k in $conv.Keys){
                $v=$conv[$k]
                [pscustomobject]@{key=[string]$k;ratio=[double]$v.ratio;dateScore=[double]$v.dateScore}
            }
        } | Export-Csv -LiteralPath $convPath -NoTypeInformation -Encoding UTF8
        @($today.rows) | Export-Csv -LiteralPath $todayPath -NoTypeInformation -Encoding UTF8
        if(!(Test-Path $todayPath)){[IO.File]::WriteAllText($todayPath,'',(New-Object Text.UTF8Encoding($true)))}
        BuildLog 'STEP 7 OK'

        BuildLog 'STEP 8/10: Ghi issue CSV...'
        & {
            foreach($k in $issue.Keys){ foreach($r in $issue[$k]){ $r } }
        } | Export-Csv -LiteralPath $issuePath -NoTypeInformation -Encoding UTF8
        BuildLog ('STEP 8 OK: size={0}' -f (Get-Item $issuePath).Length)

        BuildLog 'STEP 9/10: Ghi XLN CSV...'
        & {
            foreach($k in $xln.Keys){ foreach($r in $xln[$k]){ $r } }
        } | Export-Csv -LiteralPath $xlnPath -NoTypeInformation -Encoding UTF8
        BuildLog ('STEP 9 OK: size={0}' -f (Get-Item $xlnPath).Length)

        # V2.75: deterministic fingerprint of the ACTUAL cache data, ignoring CSV row order.
        # This is computed in the background worker, so the HTTP process stays responsive.
        $dataHash=Get-CacheBundleHash @($corePath,$convPath,$todayPath,$issuePath,$xlnPath)
        if([string]::IsNullOrWhiteSpace($dataHash)){ throw 'Khong tao duoc dataHash cho cache moi.' }
        BuildLog ('DATA HASH: '+$dataHash)

        BuildLog 'STEP 10/10: Publish metadata...'
        $meta=[pscustomobject]@{
            schema=2
            builtAt=(Get-Date).ToString('o')
            excelPath=$fiAfter.FullName
            excelWriteUtcTicks=$fiAfter.LastWriteTimeUtc.ToFileTimeUtc()
            excelLength=$fiAfter.Length
            excelContentHash=[string]$excelContentHashAfter
            coreFile=$coreName
            conversionFile=$convName
            todayFile=$todayName
            issueFile=$issueName
            xlnFile=$xlnName
            rowCount=[int]$rows.Count
            issueKeyCount=[int]$issue.Count
            xlnKeyCount=[int]$xln.Count
            dataHash=[string]$dataHash
            previousDataHash=[string]$previousDataHash
            previousBuiltAt=[string]$previousBuiltAt
        }
        $metaTmp=$BuildCachePath+'.tmp.'+$PID
        $metaJson=$meta|ConvertTo-Json -Depth 4 -Compress
        [IO.File]::WriteAllText($metaTmp,$metaJson,(New-Object Text.UTF8Encoding($false)))
        Move-Item -Path $metaTmp -Destination $BuildCachePath -Force
        BuildLog ('BUILD OK rows={0} issueKeys={1} xlnKeys={2}' -f $rows.Count,$issue.Count,$xln.Count)

        # Metadata is committed last. Old versioned cache files can now be removed safely.
        try {
            $keep=@($coreName,$convName,$todayName,$issueName,$xlnName)
            Get-ChildItem -LiteralPath $workerCacheDir -Filter '*.cache.csv' -File -ErrorAction SilentlyContinue |
                Where-Object { $keep -notcontains $_.Name } |
                Remove-Item -Force -ErrorAction SilentlyContinue
        } catch {}
        exit 0
    } catch {
        try { if($workerCacheLog){Add-Content $workerCacheLog ('[{0}] BUILD ERROR: {1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'),$_.Exception.ToString()) -Encoding UTF8} } catch {}
        exit 2
    } finally {
        try { if($lockPath -and (Test-Path $lockPath)){Remove-Item $lockPath -Force -ErrorAction SilentlyContinue} } catch {}
    }
}

$cfg = Load-Config
if ([string]::IsNullOrWhiteSpace([string]$cfg.ExcelPath) -or !(Test-Path ([string]$cfg.ExcelPath))) {
    $picked = Select-ExcelFile
    if (!$picked) { Write-Host 'Chua chon file Excel.' -ForegroundColor Red; exit 1 }
    $cfg.ExcelPath = $picked
    Save-Config $cfg
}
if (!$cfg.Pin) { $cfg | Add-Member -NotePropertyName Pin -NotePropertyValue '5102' -Force; Save-Config $cfg }
$port = if ($cfg.Port) { [int]$cfg.Port } else { 8787 }

# V2.49: atomic cache guard + stable AI + fast persistent CSV cache.
# - CACHE\cache-meta.json + versioned CSV files survive STOP/START and Windows restart.
# - Server imports disk cache into RAM immediately, then Excel is refreshed in a hidden background process.
# - Requests never parse the Excel file directly anymore.
$CacheDir = Join-Path $Root 'CACHE'
if (!(Test-Path $CacheDir)) { New-Item -ItemType Directory -Path $CacheDir -Force | Out-Null }
$CachePath = Join-Path $CacheDir 'cache-meta.json'
$CacheLogPath = Join-Path $CacheDir 'cache-refresh.log'

$script:LastWrite = [datetime]::MinValue
$script:LoadedExcelWriteUtcTicks = 0L
$script:LoadedExcelLength = 0L
# V2.77: SHA256 of the actual XLSX file bytes at the last accepted SAVE.
$script:LoadedExcelContentHash = ''
# V2.75: fingerprint of the actual published cache contents, independent of Excel timestamp/size.
$script:LoadedDataHash = ''
$script:CacheFileStampUtc = [datetime]::MinValue
$script:CacheBuildProcess = $null
$script:CacheBuildStartedAt = [datetime]::MinValue
# V2.77: debounce metadata briefly, then verify actual XLSX bytes before treating it as a SAVE.
$script:ExcelChangeDebounceSec = 5
$script:PendingExcelFingerprint = ''
$script:PendingExcelSince = [datetime]::MinValue
$script:NextCacheRetryAt = [datetime]::MinValue
$script:NextRefreshCheckAt = [datetime]::MinValue
$script:CacheBuildTimeoutSec = 600
$script:Rows = @()
$script:ByWo = @{}
$script:ByMaterial = @{}
$script:ConversionByMaterial = @{}
$script:TodayXln = [pscustomobject]@{workOrderCount=0;rowCount=0;totalQty=0.0;totalKg=0.0;rows=@()}
$script:IssueDetailsByWo = @{}
$script:XlnDetailsByWo = @{}

# V2.71-V2.75: keep a compact history of what actually changed after each Excel cache reload.
$ExcelChangeHistoryPath = Join-Path $CacheDir 'excel-change-history.json'
$script:ExcelChangeHistory = @()
$script:LastBuildDurationSec = 0
$script:ExcelChangeHistoryMax = 20
$script:ExcelChangeDetailMax = 200

function Load-ExcelChangeHistory {
    try {
        if(!(Test-Path $ExcelChangeHistoryPath)){ $script:ExcelChangeHistory=@(); return }
        $raw=Get-Content -LiteralPath $ExcelChangeHistoryPath -Raw -Encoding UTF8
        if([string]::IsNullOrWhiteSpace($raw)){ $script:ExcelChangeHistory=@(); return }
        $obj=$raw|ConvertFrom-Json
        $script:ExcelChangeHistory=@($obj)
    } catch { $script:ExcelChangeHistory=@() }
}

function Save-ExcelChangeHistory {
    try {
        $tmp=$ExcelChangeHistoryPath+'.tmp'
        @($script:ExcelChangeHistory)|ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $tmp -Encoding UTF8
        Move-Item -LiteralPath $tmp -Destination $ExcelChangeHistoryPath -Force
    } catch { Write-CacheLog ('CHANGE HISTORY SAVE ERROR: '+$_.Exception.Message) }
}

function Get-ChangeText($v) {
    if($null -eq $v){return ''}
    if($v -is [double] -or $v -is [float] -or $v -is [decimal]){
        return ([double]$v).ToString('0.###',[Globalization.CultureInfo]::InvariantCulture)
    }
    return ([string]$v).Trim()
}

function Test-ChangeValue($a,$b,[bool]$numeric=$false) {
    if($numeric){ return ([math]::Abs((Num-OrZero $a)-(Num-OrZero $b)) -gt 0.0001) }
    return ((Get-ChangeText $a) -ne (Get-ChangeText $b))
}

function New-ExcelChangeRecord($oldRows,$newRows) {
    try {
        $oldMap=@{};$newMap=@{}
        foreach($r in @($oldRows)){ $k=([string]$r.workOrder).Trim().ToUpperInvariant();if($k){$oldMap[$k]=$r} }
        foreach($r in @($newRows)){ $k=([string]$r.workOrder).Trim().ToUpperInvariant();if($k){$newMap[$k]=$r} }
        $details=New-Object System.Collections.Generic.List[object]
        $affected=@{}
        $count=@{newOrders=0;removedOrders=0;statusChanges=0;finishChanges=0;notOkChanges=0;transferChanges=0;shipDateChanges=0;issuedChanges=0;ngChanges=0;otherChanges=0;totalChanges=0}
        function Add-ExcelDelta([string]$wo,[string]$type,[string]$label,[string]$field,$old,$new,[bool]$important=$false){
            $count.totalChanges++
            $affected[$wo]=$true
            if($details.Count -lt $script:ExcelChangeDetailMax){
                $details.Add([pscustomobject]@{workOrder=$wo;type=$type;label=$label;field=$field;old=(Get-ChangeText $old);new=(Get-ChangeText $new);important=$important})
            }
        }
        foreach($k in @($newMap.Keys)){
            if(!$oldMap.ContainsKey($k)){
                $count.newOrders++; Add-ExcelDelta $k 'new' 'Công đơn mới' 'workOrder' '' $k $true; continue
            }
            $o=$oldMap[$k];$n=$newMap[$k]
            if(Test-ChangeValue $o.status $n.status){
                $count.statusChanges++; if(([string]$n.status).ToUpperInvariant() -eq 'FINISH'){$count.finishChanges++}
                Add-ExcelDelta $k 'status' 'Trạng thái' 'status' $o.status $n.status $true
            }
            if(Test-ChangeValue $o.notOkQty $n.notOkQty $true){$count.notOkChanges++;Add-ExcelDelta $k 'notok' 'SL chưa OK' 'notOkQty' $o.notOkQty $n.notOkQty $true}
            if(Test-ChangeValue $o.transferredQty $n.transferredQty $true){$count.transferChanges++;Add-ExcelDelta $k 'transfer' 'Chuyển XLN/KH' 'transferredQty' $o.transferredQty $n.transferredQty $true}
            if(Test-ChangeValue $o.shipDate $n.shipDate){$count.shipDateChanges++;Add-ExcelDelta $k 'ship' 'Lịch xuất' 'shipDate' $o.shipDate $n.shipDate $true}
            if(Test-ChangeValue $o.issuedQty $n.issuedQty $true){$count.issuedChanges++;Add-ExcelDelta $k 'issued' 'Lĩnh liệu' 'issuedQty' $o.issuedQty $n.issuedQty $false}
            if(Test-ChangeValue $o.ngQty $n.ngQty $true){$count.ngChanges++;Add-ExcelDelta $k 'ng' 'NG' 'ngQty' $o.ngQty $n.ngQty $false}
            foreach($f in @(
                @('customer','Khách hàng',$false),@('material','Mã liệu',$false),@('materialName','Tên liệu',$false),@('spec','Quy cách',$false),
                @('orderQty','SL đơn hàng',$true),@('inputQty','SL đầu vào',$true),@('missingReturnXLN','Thiếu trả XLN',$true),@('issueDiff','Chênh lĩnh liệu',$true)
            )){
                $field=[string]$f[0];$label=[string]$f[1];$num=[bool]$f[2]
                if(Test-ChangeValue $o.$field $n.$field $num){$count.otherChanges++;Add-ExcelDelta $k 'other' $label $field $o.$field $n.$field $false}
            }
        }
        foreach($k in @($oldMap.Keys)){
            if(!$newMap.ContainsKey($k)){$count.removedOrders++;Add-ExcelDelta $k 'removed' 'Công đơn bị xóa/không còn trong dữ liệu' 'workOrder' $k '' $true}
        }
        # PowerShell 5.1 can be temperamental when Generic.List is embedded directly in PSCustomObject/ConvertTo-Json.
        # Materialize a plain object[] first so the history record is always serializable.
        [object[]]$detailArray=@()
        if($details.Count -gt 0){ [object[]]$detailArray=@($details | ForEach-Object { $_ }) }
        $rec=[pscustomobject]@{
            id=(Get-Date).ToString('yyyyMMddHHmmssfff'); at=(Get-Date).ToString('dd/MM/yyyy HH:mm:ss');
            durationSeconds=[int]$script:LastBuildDurationSec; oldRowCount=$oldMap.Count; newRowCount=$newMap.Count;
            workOrdersAffected=$affected.Count; totalChanges=[int]$count.totalChanges; detailCount=$detailArray.Count;
            detailTruncated=([int]$count.totalChanges -gt $detailArray.Count);
            summary=[pscustomobject]$count; details=$detailArray
        }
        $script:ExcelChangeHistory=@($rec)+@($script:ExcelChangeHistory)
        if($script:ExcelChangeHistory.Count -gt $script:ExcelChangeHistoryMax){$script:ExcelChangeHistory=@($script:ExcelChangeHistory|Select-Object -First $script:ExcelChangeHistoryMax)}
        Save-ExcelChangeHistory
        Write-CacheLog ("EXCEL CHANGE: total=$($rec.totalChanges), affected=$($rec.workOrdersAffected), new=$($count.newOrders), finish=$($count.finishChanges), notOk=$($count.notOkChanges), xln=$($count.transferChanges), ship=$($count.shipDateChanges)")
        return $rec
    } catch { Write-CacheLog ('EXCEL CHANGE DIFF ERROR: '+$_.Exception.ToString()); return $null }
}

function New-ZeroExcelChangeRecord([int]$oldRowCount,[int]$newRowCount,[string]$note='File Excel có thay đổi timestamp/metadata nhưng dữ liệu cache không đổi.') {
    try {
        $count=@{newOrders=0;removedOrders=0;statusChanges=0;finishChanges=0;notOkChanges=0;transferChanges=0;shipDateChanges=0;issuedChanges=0;ngChanges=0;otherChanges=0;totalChanges=0}
        $rec=[pscustomobject]@{
            id=(Get-Date).ToString('yyyyMMddHHmmssfff'); at=(Get-Date).ToString('dd/MM/yyyy HH:mm:ss');
            durationSeconds=[int]$script:LastBuildDurationSec; oldRowCount=$oldRowCount; newRowCount=$newRowCount;
            workOrdersAffected=0; totalChanges=0; detailCount=0; detailTruncated=$false;
            summary=[pscustomobject]$count; details=@(); note=$note; metadataOnly=$true
        }
        $script:ExcelChangeHistory=@($rec)+@($script:ExcelChangeHistory)
        if($script:ExcelChangeHistory.Count -gt $script:ExcelChangeHistoryMax){$script:ExcelChangeHistory=@($script:ExcelChangeHistory|Select-Object -First $script:ExcelChangeHistoryMax)}
        Save-ExcelChangeHistory
        Write-CacheLog ('EXCEL CHANGE: 0 actual data changes; metadata/timestamp only. RAM adopt skipped.')
        return $rec
    } catch { Write-CacheLog ('ZERO CHANGE HISTORY ERROR: '+$_.Exception.ToString()); return $null }
}


function New-ExcelBaselineRecord([int]$oldRowCount,[int]$newRowCount,[string]$note='Khởi tạo baseline dữ liệu công đơn. Không tính các công đơn hiện có là thay đổi.') {
    try {
        $count=@{newOrders=0;removedOrders=0;statusChanges=0;finishChanges=0;notOkChanges=0;transferChanges=0;shipDateChanges=0;issuedChanges=0;ngChanges=0;otherChanges=0;totalChanges=0}
        $rec=[pscustomobject]@{
            id=(Get-Date).ToString('yyyyMMddHHmmssfff'); at=(Get-Date).ToString('dd/MM/yyyy HH:mm:ss');
            durationSeconds=[int]$script:LastBuildDurationSec; oldRowCount=$oldRowCount; newRowCount=$newRowCount;
            workOrdersAffected=0; totalChanges=0; detailCount=0; detailTruncated=$false;
            summary=[pscustomobject]$count; details=@(); note=$note; baseline=$true; metadataOnly=$false
        }
        $script:ExcelChangeHistory=@($rec)+@($script:ExcelChangeHistory)
        if($script:ExcelChangeHistory.Count -gt $script:ExcelChangeHistoryMax){$script:ExcelChangeHistory=@($script:ExcelChangeHistory|Select-Object -First $script:ExcelChangeHistoryMax)}
        Save-ExcelChangeHistory
        Write-CacheLog ("V2.82 HISTORY BASELINE: old=$oldRowCount new=$newRowCount. Existing rows are NOT counted as changes.")
        return $rec
    } catch { Write-CacheLog ('BASELINE HISTORY ERROR: '+$_.Exception.ToString()); return $null }
}

function Repair-ExcelChangeHistoryBaseline {
    try {
        $changed=$false
        $fixed=New-Object System.Collections.Generic.List[object]
        foreach($h in @($script:ExcelChangeHistory)){
            $old=[int](Num-OrZero $h.oldRowCount); $new=[int](Num-OrZero $h.newRowCount)
            $newOrders=0; try{$newOrders=[int](Num-OrZero $h.summary.newOrders)}catch{}
            $looksLikeBrokenBaseline=(!$h.baseline -and $new -ge 500 -and $old -lt [math]::Max(100,[int]($new*0.25)) -and $newOrders -gt [int]($new*0.75))
            if($looksLikeBrokenBaseline){
                $count=@{newOrders=0;removedOrders=0;statusChanges=0;finishChanges=0;notOkChanges=0;transferChanges=0;shipDateChanges=0;issuedChanges=0;ngChanges=0;otherChanges=0;totalChanges=0}
                $fixed.Add([pscustomobject]@{
                    id=$h.id;at=$h.at;durationSeconds=$h.durationSeconds;oldRowCount=$old;newRowCount=$new;
                    workOrdersAffected=0;totalChanges=0;detailCount=0;detailTruncated=$false;
                    summary=[pscustomobject]$count;details=@();baseline=$true;metadataOnly=$false;
                    note='Baseline cũ được sửa tự động: snapshot trước không đầy đủ nên không tính toàn bộ công đơn hiện có là công đơn mới.'
                })
                $changed=$true
                Write-CacheLog ("V2.82 HISTORY REPAIR: converted impossible diff to baseline. old=$old new=$new previousNewOrders=$newOrders")
            } else { $fixed.Add($h) }
        }
        if($changed){ $script:ExcelChangeHistory=@($fixed.ToArray()); Save-ExcelChangeHistory }
    } catch { Write-CacheLog ('V2.82 HISTORY REPAIR ERROR: '+$_.Exception.ToString()) }
}

function Write-CacheLog([string]$message) {
    try {
        $line = ('[{0}] {1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $message)
        Add-Content -Path $CacheLogPath -Value $line -Encoding UTF8
    } catch {}
}

# V2.82: Write-CacheLog must exist before startup history repair uses it.
Load-ExcelChangeHistory
Repair-ExcelChangeHistoryBaseline

function Convert-DetailIndexToEntries($idx) {
    $out = New-Object System.Collections.Generic.List[object]
    foreach ($key in @($idx.Keys)) {
        [object[]]$arr = @()
        $list = $idx[$key]
        if ($null -ne $list) {
            if ($list.PSObject.Methods['ToArray']) { [object[]]$arr = $list.ToArray() }
            else { $tmp=New-Object System.Collections.Generic.List[object]; foreach($x in $list){$tmp.Add($x)}; [object[]]$arr=$tmp.ToArray() }
        }
        $out.Add([pscustomobject]@{key=[string]$key;rows=$arr})
    }
    return $out.ToArray()
}

function Convert-MapToEntries($map) {
    $out = New-Object System.Collections.Generic.List[object]
    foreach ($key in @($map.Keys)) { $out.Add([pscustomobject]@{key=[string]$key;value=$map[$key]}) }
    return $out.ToArray()
}

function Convert-EntriesToDetailIndex($entries) {
    $idx=@{}
    foreach($entry in @($entries)) {
        $key=([string]$entry.key).ToUpperInvariant()
        if([string]::IsNullOrWhiteSpace($key)){continue}
        $list=New-Object System.Collections.Generic.List[object]
        foreach($r in @($entry.rows)){ $list.Add($r) }
        $idx[$key]=$list
    }
    return $idx
}

function Convert-EntriesToMap($entries) {
    $map=@{}
    foreach($entry in @($entries)) {
        $key=([string]$entry.key).ToUpperInvariant()
        if(![string]::IsNullOrWhiteSpace($key)){ $map[$key]=$entry.value }
    }
    return $map
}

function Rebuild-CoreIndexes {
    $script:ByWo=@{}
    $script:ByMaterial=@{}
    foreach($r in @($script:Rows)) {
        $wo=([string]$r.workOrder).Trim().ToUpperInvariant()
        if(![string]::IsNullOrWhiteSpace($wo)){ $script:ByWo[$wo]=$r }
        $mk=([string]$r.material).Trim().ToUpperInvariant()
        if(![string]::IsNullOrWhiteSpace($mk)) {
            if(!$script:ByMaterial.ContainsKey($mk)){ $script:ByMaterial[$mk]=New-Object System.Collections.Generic.List[object] }
            $script:ByMaterial[$mk].Add($r)
        }
    }
}

function Import-PersistentCache {
    if(!(Test-Path $CachePath)){ return $false }
    try {
        $raw=Get-Content -Path $CachePath -Raw -Encoding UTF8
        if([string]::IsNullOrWhiteSpace($raw)){return $false}
        $data=$raw | ConvertFrom-Json
        if([int]$data.schema -ne 2){
            Write-CacheLog ('CACHE schema cu/khong hop le: '+[string]$data.schema+'. Se build lai CSV cache.')
            return $false
        }
        $corePath=Join-Path $CacheDir ([string]$data.coreFile)
        $convPath=Join-Path $CacheDir ([string]$data.conversionFile)
        $todayPath=Join-Path $CacheDir ([string]$data.todayFile)
        $issuePath=Join-Path $CacheDir ([string]$data.issueFile)
        $xlnPath=Join-Path $CacheDir ([string]$data.xlnFile)
        foreach($cp in @($corePath,$convPath,$todayPath,$issuePath,$xlnPath)){if(!(Test-Path $cp)){throw ('Thieu file cache: '+$cp)}}

        Write-CacheLog 'CACHE -> RAM: doc workorders CSV...'
        $coreList=New-Object System.Collections.Generic.List[object]
        foreach($r in @(Import-Csv -LiteralPath $corePath -Encoding UTF8)){
            $coreList.Add([pscustomobject]@{
                workOrder=[string]$r.workOrder;status=[string]$r.status;receivedDate=[string]$r.receivedDate;
                customer=[string]$r.customer;material=[string]$r.material;materialName=[string]$r.materialName;spec=[string]$r.spec;
                orderQty=Num-OrZero $r.orderQty;inputQty=Num-OrZero $r.inputQty;issuedQty=Num-OrZero $r.issuedQty;
                transferredQty=Num-OrZero $r.transferredQty;missingReturnXLN=Num-OrZero $r.missingReturnXLN;ngQty=Num-OrZero $r.ngQty;
                notOkQty=Num-OrZero $r.notOkQty;shipDate=[string]$r.shipDate;issueDiff=Num-OrZero $r.issueDiff
            })
        }
        [object[]]$newRows=$coreList.ToArray()
        if($newRows.Count -le 0){ throw 'CACHE INVALID: workorders CSV co 0 dong. Giu nguyen RAM hien tai.' }
        if([int]$data.rowCount -gt 0 -and $newRows.Count -ne [int]$data.rowCount){ throw ('CACHE INVALID: rowCount metadata='+[int]$data.rowCount+' nhung CSV='+$newRows.Count) }

        # V2.71/V2.72: compare the previous RAM snapshot with the newly published cache before swapping.
        [object[]]$oldRowsForDiff=@($script:Rows)
        $shouldRecordExcelChange=($script:CacheFileStampUtc -ne [datetime]::MinValue -and $oldRowsForDiff.Count -gt 0)
        if($shouldRecordExcelChange){
            # V2.81: never compare a partial/empty previous snapshot against a full workbook.
            # That situation used to make almost every existing work order look like a newly-added order.
            $oldCountForGuard=[int]$oldRowsForDiff.Count; $newCountForGuard=[int]$newRows.Count
            $baselineInvalid=($newCountForGuard -ge 500 -and $oldCountForGuard -lt [math]::Max(100,[int]($newCountForGuard*0.25)))
            if($baselineInvalid){
                [void](New-ExcelBaselineRecord $oldCountForGuard $newCountForGuard 'Snapshot trước không đầy đủ sau khi đổi version/cache. Đã khởi tạo baseline mới; không tính các công đơn hiện có là thay đổi.')
            } else {
                [void](New-ExcelChangeRecord $oldRowsForDiff $newRows)
            }
        }

        # Chi swap core RAM sau khi bo cache moi da duoc xac nhan co du lieu.
        [object[]]$script:Rows=$newRows

        $script:ConversionByMaterial=@{}
        foreach($r in @(Import-Csv -LiteralPath $convPath -Encoding UTF8)){
            $k=([string]$r.key).ToUpperInvariant();if([string]::IsNullOrWhiteSpace($k)){continue}
            $script:ConversionByMaterial[$k]=[pscustomobject]@{ratio=Num-OrZero $r.ratio;dateScore=Num-OrZero $r.dateScore}
        }

        $todayRows=New-Object System.Collections.Generic.List[object];$todayWo=@{};$todayQty=0.0;$todayKg=0.0
        foreach($r in @(Import-Csv -LiteralPath $todayPath -Encoding UTF8)){
            if($null -eq $r){continue}
            $o=[pscustomobject]@{rowNumber=[int](Num-OrZero $r.rowNumber);date=[string]$r.date;workOrder=[string]$r.workOrder;material=[string]$r.material;spec=[string]$r.spec;qty=Num-OrZero $r.qty;kg=Num-OrZero $r.kg;status=[string]$r.status;note=[string]$r.note;pcsPerKg=Num-OrZero $r.pcsPerKg}
            $todayRows.Add($o);$todayQty+=[double]$o.qty;$todayKg+=[double]$o.kg
            if(![string]::IsNullOrWhiteSpace($o.workOrder)){$todayWo[$o.workOrder.ToUpperInvariant()]=$true}
        }
        $script:TodayXln=[pscustomobject]@{workOrderCount=$todayWo.Count;rowCount=$todayRows.Count;totalQty=$todayQty;totalKg=$todayKg;rows=$todayRows.ToArray()}

        Write-CacheLog 'CACHE -> RAM: doc issue CSV...'
        $script:IssueDetailsByWo=@{}
        foreach($r in @(Import-Csv -LiteralPath $issuePath -Encoding UTF8)){
            $wo=([string]$r.workOrder).Trim();if([string]::IsNullOrWhiteSpace($wo)){continue};$k=$wo.ToUpperInvariant()
            if(!$script:IssueDetailsByWo.ContainsKey($k)){$script:IssueDetailsByWo[$k]=New-Object System.Collections.Generic.List[object]}
            $script:IssueDetailsByWo[$k].Add([pscustomobject]@{date=[string]$r.date;workOrder=$wo;material=[string]$r.material;productName=[string]$r.productName;spec=[string]$r.spec;inputQty=Num-OrZero $r.inputQty;issuedQty=Num-OrZero $r.issuedQty;kg=Num-OrZero $r.kg;erp=[string]$r.erp;customer=[string]$r.customer;rowNumber=[int](Num-OrZero $r.rowNumber)})
        }

        Write-CacheLog 'CACHE -> RAM: doc XLN CSV...'
        $script:XlnDetailsByWo=@{}
        # V2.79: 5 lan quy doi gan nhat duoc suy ra truc tiep tu XLN cache hien co.
        # Khong doi cache schema -> cache V2.77 van nap binh thuong, khong lam rong ByWo.
        $recentConvByMaterial=@{}
        foreach($r in @(Import-Csv -LiteralPath $xlnPath -Encoding UTF8)){
            $wo=([string]$r.workOrder).Trim();if([string]::IsNullOrWhiteSpace($wo)){continue};$k=$wo.ToUpperInvariant()
            $material=([string]$r.material).Trim();$rate=Num-OrZero $r.pcsPerKg;$rowNo=[int](Num-OrZero $r.rowNumber)
            if(!$script:XlnDetailsByWo.ContainsKey($k)){$script:XlnDetailsByWo[$k]=New-Object System.Collections.Generic.List[object]}
            $script:XlnDetailsByWo[$k].Add([pscustomobject]@{date=[string]$r.date;workOrder=$wo;material=$material;productName=[string]$r.productName;spec=[string]$r.spec;unit=[string]$r.unit;qty=Num-OrZero $r.qty;kg=Num-OrZero $r.kg;status=[string]$r.status;note=[string]$r.note;line=[string]$r.line;pcsPerKg=$rate;rowNumber=$rowNo})
            if($rate -gt 0 -and ![string]::IsNullOrWhiteSpace($material)){
                $mk=$material.ToUpperInvariant();if(!$recentConvByMaterial.ContainsKey($mk)){$recentConvByMaterial[$mk]=New-Object System.Collections.Generic.List[object]}
                $ds=0L;try{$ds=[datetime]::ParseExact(([string]$r.date).Trim(),'dd/MM/yyyy',[Globalization.CultureInfo]::InvariantCulture).Ticks}catch{$ds=0L}
                $recentConvByMaterial[$mk].Add([pscustomobject]@{ratio=[double]$rate;dateScore=$ds;rowNumber=$rowNo})
            }
        }
        foreach($mk in @($recentConvByMaterial.Keys)){
            $top=@($recentConvByMaterial[$mk] | Sort-Object @{Expression='dateScore';Descending=$true},@{Expression='rowNumber';Descending=$true} | Select-Object -First 5)
            $rounded=New-Object System.Collections.Generic.List[double]
            foreach($cv in $top){$rounded.Add([Math]::Round([double]$cv.ratio,1,[MidpointRounding]::AwayFromZero))}
            if($script:ConversionByMaterial.ContainsKey($mk)){
                $script:ConversionByMaterial[$mk] | Add-Member -NotePropertyName recent -NotePropertyValue ([double[]]$rounded.ToArray()) -Force
            } elseif($rounded.Count -gt 0) {
                $script:ConversionByMaterial[$mk]=[pscustomobject]@{ratio=[double]$top[0].ratio;dateScore=[double]$top[0].dateScore;recent=[double[]]$rounded.ToArray()}
            }
        }

        Rebuild-CoreIndexes
        $script:LoadedExcelWriteUtcTicks=[long]$data.excelWriteUtcTicks
        $script:LoadedExcelLength=[long]$data.excelLength
        $script:LoadedExcelContentHash=([string]$data.excelContentHash).Trim().ToUpperInvariant()
        $script:LoadedDataHash=([string]$data.dataHash).Trim().ToUpperInvariant()
        try { $script:LastWrite=[datetime]::FromFileTimeUtc($script:LoadedExcelWriteUtcTicks).ToLocalTime() } catch { $script:LastWrite=[datetime]::MinValue }
        $script:CacheFileStampUtc=(Get-Item $CachePath).LastWriteTimeUtc
        Write-Host ("Da nap CACHE CSV: {0:N0} cong don, {1:N0} linh lieu index, {2:N0} XLN index." -f $script:Rows.Count,$script:IssueDetailsByWo.Count,$script:XlnDetailsByWo.Count) -ForegroundColor Green
        Write-CacheLog ("CACHE -> RAM OK. WorkOrders=$($script:Rows.Count)")
        return $true
    } catch {
        Write-Warning ("Khong doc duoc CACHE CSV: " + $_.Exception.Message)
        Write-CacheLog ("CACHE IMPORT ERROR: " + $_.Exception.ToString())
        return $false
    }
}

function Test-CacheMatchesExcel {
    try {
        # Cache rong khong bao gio duoc coi la hop le, ke ca timestamp Excel trung nhau.
        if($null -eq $script:Rows -or [int]$script:Rows.Count -le 0){ return $false }
        $fi=Get-Item ([string]$cfg.ExcelPath)
        return ($script:LoadedExcelWriteUtcTicks -eq $fi.LastWriteTimeUtc.ToFileTimeUtc() -and $script:LoadedExcelLength -eq $fi.Length)
    } catch { return $false }
}

function Get-PublishedCacheMeta {
    try {
        if(!(Test-Path $CachePath)){ return $null }
        $raw=Get-Content -LiteralPath $CachePath -Raw -Encoding UTF8
        if([string]::IsNullOrWhiteSpace($raw)){ return $null }
        $m=$raw|ConvertFrom-Json
        if([int]$m.schema -ne 2){ return $null }
        return $m
    } catch {
        Write-CacheLog ('READ CACHE META ERROR: '+$_.Exception.Message)
        return $null
    }
}

function Save-V277SaveGateMeta([long]$writeTicks,[long]$length,[string]$contentHash) {
    try {
        $m=Get-PublishedCacheMeta
        if($null -eq $m){ return $false }
        $m | Add-Member -NotePropertyName excelWriteUtcTicks -NotePropertyValue $writeTicks -Force
        $m | Add-Member -NotePropertyName excelLength -NotePropertyValue $length -Force
        $m | Add-Member -NotePropertyName excelContentHash -NotePropertyValue $contentHash -Force
        $tmp=$CachePath+'.savegate.tmp.'+$PID
        [IO.File]::WriteAllText($tmp,($m|ConvertTo-Json -Depth 6 -Compress),(New-Object Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tmp -Destination $CachePath -Force
        $script:CacheFileStampUtc=(Get-Item $CachePath).LastWriteTimeUtc
        return $true
    } catch {
        Write-CacheLog ('V2.77 SAVE GATE META WRITE ERROR: '+$_.Exception.Message)
        return $false
    }
}

function Adopt-MetadataOnlyCache($meta) {
    try {
        if($null -eq $meta){ return $false }
        $newHash=([string]$meta.dataHash).Trim().ToUpperInvariant()
        if([string]::IsNullOrWhiteSpace($newHash)){ return $false }
        $sameData=$false
        if(![string]::IsNullOrWhiteSpace($script:LoadedDataHash)){
            $sameData=($newHash -eq $script:LoadedDataHash)
        } else {
            # First V2.75 reload after upgrading from an older cache: the worker hashed the old bundle too.
            $previousHash=([string]$meta.previousDataHash).Trim().ToUpperInvariant()
            if(![string]::IsNullOrWhiteSpace($previousHash)){ $sameData=($newHash -eq $previousHash) }
        }
        if(!$sameData){ return $false }
        $oldCount=[int]$script:Rows.Count
        $newCount=[int]$meta.rowCount
        [void](New-ZeroExcelChangeRecord $oldCount $newCount)
        $script:LoadedExcelWriteUtcTicks=[long]$meta.excelWriteUtcTicks
        $script:LoadedExcelLength=[long]$meta.excelLength
        $script:LoadedExcelContentHash=([string]$meta.excelContentHash).Trim().ToUpperInvariant()
        $script:LoadedDataHash=$newHash
        try { $script:LastWrite=[datetime]::FromFileTimeUtc($script:LoadedExcelWriteUtcTicks).ToLocalTime() } catch { $script:LastWrite=[datetime]::MinValue }
        try { $script:CacheFileStampUtc=(Get-Item $CachePath).LastWriteTimeUtc } catch {}
        $script:PendingExcelFingerprint=''
        $script:PendingExcelSince=[datetime]::MinValue
        $script:NextCacheRetryAt=[datetime]::MinValue
        Write-CacheLog ('V2.75 FAST PATH OK: dataHash unchanged. Updated Excel fingerprint without RAM re-import.')
        return $true
    } catch {
        Write-CacheLog ('V2.75 FAST PATH ERROR: '+$_.Exception.ToString())
        return $false
    }
}

function Monitor-BackgroundCacheBuild {
    try {
        if(!$script:CacheBuildProcess){ return }
        if($script:CacheBuildProcess.HasExited) {
            $code=$script:CacheBuildProcess.ExitCode
            if($script:CacheBuildStartedAt -ne [datetime]::MinValue){$script:LastBuildDurationSec=[int]((Get-Date)-$script:CacheBuildStartedAt).TotalSeconds}else{$script:LastBuildDurationSec=0}
            Write-CacheLog ("BACKGROUND BUILD EXIT code=$code PID=$($script:CacheBuildProcess.Id) duration=$($script:LastBuildDurationSec)s")
            $script:CacheBuildProcess=$null
            $script:CacheBuildStartedAt=[datetime]::MinValue
            if($code -eq 0) {
                # V2.75 fast path: compare a worker-generated hash of ALL cache CSV data first.
                # When only Excel timestamp/metadata changed, do NOT import thousands of CSV rows again.
                # That avoids the 10-20s HTTP freeze previously seen near the end of a reload.
                $meta=Get-PublishedCacheMeta
                $adopted=$false
                if($meta -and (Adopt-MetadataOnlyCache $meta)){
                    $adopted=$true
                } else {
                    # Real data changed (or this is an older cache without dataHash): perform the validated RAM swap.
                    $adopted=Import-PersistentCache
                    if($adopted){
                        $script:PendingExcelFingerprint=''
                        $script:PendingExcelSince=[datetime]::MinValue
                        Write-CacheLog 'V2.75 REAL DATA ADOPT OK after successful background build.'
                    }
                }
                if(!$adopted){
                    Write-CacheLog 'V2.75 CACHE ADOPT FAILED after successful background build; retry in 30s.'
                    $script:NextCacheRetryAt=(Get-Date).AddSeconds(30)
                } else {
                    $script:NextCacheRetryAt=[datetime]::MinValue
                }
            } else {
                $script:NextCacheRetryAt=(Get-Date).AddSeconds(30)
            }
            return
        }
        if($script:CacheBuildStartedAt -ne [datetime]::MinValue) {
            $elapsed=((Get-Date)-$script:CacheBuildStartedAt).TotalSeconds
            if($elapsed -gt $script:CacheBuildTimeoutSec) {
                $pid=$script:CacheBuildProcess.Id
                try { $script:CacheBuildProcess.Kill() } catch {}
                Write-CacheLog ("BACKGROUND BUILD TIMEOUT ${elapsed}s - killed PID=$pid")
                Write-Warning ("Nap Excel nen qua {0}s. Da dung worker PID {1}; server van tiep tuc dung CACHE cu." -f $script:CacheBuildTimeoutSec,$pid)
                $script:CacheBuildProcess=$null
                $script:CacheBuildStartedAt=[datetime]::MinValue
                $script:NextCacheRetryAt=(Get-Date).AddSeconds(30)
            }
        }
    } catch {
        Write-CacheLog ("MONITOR BUILD ERROR: " + $_.Exception.Message)
    }
}

function Start-BackgroundCacheBuild([bool]$force=$false) {
    try {
        Monitor-BackgroundCacheBuild
        if($script:CacheBuildProcess -and !$script:CacheBuildProcess.HasExited){ return }
        if(!$force -and $script:NextCacheRetryAt -ne [datetime]::MinValue -and (Get-Date) -lt $script:NextCacheRetryAt){ return }
        if(!$force -and (Test-CacheMatchesExcel)){ return }
        $exe=(Get-Command powershell.exe -ErrorAction Stop).Source
        $psi=New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName=$exe
        $scriptPath=$PSCommandPath
        $args=@('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$scriptPath+'"'),'-BuildCacheOnly','-BuildExcelPath',('"'+[string]$cfg.ExcelPath+'"'),'-BuildCachePath',('"'+$CachePath+'"'))
        $psi.Arguments=($args -join ' ')
        $psi.UseShellExecute=$false
        $psi.CreateNoWindow=$true
        $script:CacheBuildProcess=[System.Diagnostics.Process]::Start($psi)
        $script:CacheBuildStartedAt=Get-Date
        Write-Host ("Dang cap nhat Excel nen... PID {0}" -f $script:CacheBuildProcess.Id) -ForegroundColor DarkYellow
        Write-CacheLog ("START BACKGROUND BUILD PID=$($script:CacheBuildProcess.Id)")
    } catch {
        $script:NextCacheRetryAt=(Get-Date).AddSeconds(30)
        Write-CacheLog ("START BUILD ERROR: " + $_.Exception.Message)
    }
}

function Try-AdoptNewPersistentCache {
    try {
        if(!(Test-Path $CachePath)){return}
        # V2.75: cache-meta is published just before the worker exits. Do not race the worker by
        # importing here while it is still alive; Monitor-BackgroundCacheBuild will handle it after exit
        # and can take the zero-change fast path without blocking HTTP.
        if($script:CacheBuildProcess -and !$script:CacheBuildProcess.HasExited){ return }
        $stamp=(Get-Item $CachePath).LastWriteTimeUtc
        if($stamp -gt $script:CacheFileStampUtc){ [void](Import-PersistentCache) }
    } catch {}
}

function Refresh-DataIfNeeded([bool]$force=$false) {
    # V2.42: only the main server loop may schedule/adopt Excel cache updates.
    # V2.77: wait until the metadata fingerprint is stable for 5s, then compare actual XLSX bytes.
    # Metadata-only churn while a workbook is open no longer starts a reload.
    Monitor-BackgroundCacheBuild
    Try-AdoptNewPersistentCache
    if(!$force -and (Get-Date) -lt $script:NextRefreshCheckAt){ return }
    $script:NextRefreshCheckAt=(Get-Date).AddSeconds(2)

    if($force){
        $script:PendingExcelFingerprint=''
        $script:PendingExcelSince=[datetime]::MinValue
        Start-BackgroundCacheBuild $true
        return
    }

    if(Test-CacheMatchesExcel){
        $script:PendingExcelFingerprint=''
        $script:PendingExcelSince=[datetime]::MinValue
        return
    }

    try {
        $fi=Get-Item ([string]$cfg.ExcelPath)
        $fp=('{0}:{1}' -f $fi.LastWriteTimeUtc.ToFileTimeUtc(),$fi.Length)
    } catch { return }

    if($script:PendingExcelFingerprint -ne $fp){
        $script:PendingExcelFingerprint=$fp
        $script:PendingExcelSince=Get-Date
        Write-CacheLog ("EXCEL CHANGE DETECTED fingerprint=$fp - wait ${script:ExcelChangeDebounceSec}s stable before reload")
        return
    }

    if($script:PendingExcelSince -eq [datetime]::MinValue){ $script:PendingExcelSince=Get-Date; return }
    $stableSec=((Get-Date)-$script:PendingExcelSince).TotalSeconds
    if($stableSec -lt $script:ExcelChangeDebounceSec){ return }

    # V2.77 SAVE GATE: timestamp/length changes alone are NOT a save.
    # Hash the actual XLSX bytes only after the metadata fingerprint has settled for a few seconds.
    # If the bytes are unchanged, acknowledge the new metadata and do not start the expensive worker.
    $contentHash=Get-ExcelFileContentHash ([string]$cfg.ExcelPath)
    if([string]::IsNullOrWhiteSpace($contentHash)){
        Write-CacheLog 'V2.77 SAVE GATE: cannot hash Excel yet; wait for next check.'
        $script:PendingExcelSince=Get-Date
        return
    }

    if(![string]::IsNullOrWhiteSpace($script:LoadedExcelContentHash) -and $contentHash -eq $script:LoadedExcelContentHash){
        try {
            $fi=Get-Item ([string]$cfg.ExcelPath)
            $script:LoadedExcelWriteUtcTicks=$fi.LastWriteTimeUtc.ToFileTimeUtc()
            $script:LoadedExcelLength=$fi.Length
            [void](Save-V277SaveGateMeta $script:LoadedExcelWriteUtcTicks $script:LoadedExcelLength $script:LoadedExcelContentHash)
            $script:PendingExcelFingerprint=''
            $script:PendingExcelSince=[datetime]::MinValue
            Write-CacheLog 'V2.77 SAVE GATE: metadata changed but XLSX bytes are identical -> NO RELOAD.'
        } catch {}
        return
    }

    # For an old V2.75 cache there may be no excelContentHash yet. If its timestamp/length still match
    # the current Excel, it is safe to establish the current file hash as the baseline without rebuilding.
    if([string]::IsNullOrWhiteSpace($script:LoadedExcelContentHash)){
        try {
            $fi=Get-Item ([string]$cfg.ExcelPath)
            if($script:LoadedExcelWriteUtcTicks -eq $fi.LastWriteTimeUtc.ToFileTimeUtc() -and $script:LoadedExcelLength -eq $fi.Length){
                $script:LoadedExcelContentHash=$contentHash
                $script:PendingExcelFingerprint=''
                $script:PendingExcelSince=[datetime]::MinValue
                Write-CacheLog 'V2.77 SAVE GATE: initialized XLSX content hash baseline from matching V2.75 cache.'
                return
            }
        } catch {}
    }

    Write-CacheLog 'V2.77 SAVE GATE: XLSX bytes changed -> real SAVE detected, start reload.'
    # Keep the pending fingerprint while a worker runs. If Excel changes again, the next check
    # will replace it and restart the stability timer instead of immediately starting another worker.
    Start-BackgroundCacheBuild $false
}

# Load old persistent cache first so HTTP can become usable immediately.
$loadedDiskCache=Import-PersistentCache
if(!$loadedDiskCache){
    Write-Host 'Chua co CACHE CSV. Server van ONLINE; Excel se nap nen lan dau. AI/API khong duoc phep mo Excel truc tiep.' -ForegroundColor Yellow
} elseif([string]::IsNullOrWhiteSpace($script:LoadedExcelContentHash)) {
    # Upgrade from V2.75: if the existing cache still matches the current Excel timestamp/length,
    # bind its current file bytes as the SAVE GATE baseline. No unnecessary first reload is needed.
    try {
        if(Test-CacheMatchesExcel){
            $baselineHash=Get-ExcelFileContentHash ([string]$cfg.ExcelPath)
            if(![string]::IsNullOrWhiteSpace($baselineHash)){
                $script:LoadedExcelContentHash=$baselineHash
                [void](Save-V277SaveGateMeta $script:LoadedExcelWriteUtcTicks $script:LoadedExcelLength $script:LoadedExcelContentHash)
                Write-CacheLog 'V2.77 SAVE GATE: startup baseline initialized from matching V2.75 cache.'
            }
        }
    } catch {}
}
Refresh-DataIfNeeded $false

# Save this server process ID so STOP_SERVER.bat can stop only CNC Mobile.
$pidFile = Join-Path $Root 'cnc-server.pid'
[IO.File]::WriteAllText($pidFile, [string]$PID, (New-Object Text.UTF8Encoding($false)))

# V2.70: device tracking in RAM. A device is online when seen within 45 seconds.
$script:ActiveDevices = @{}
$script:DeviceOnlineSeconds = 45

function Get-QueryMap($uri) {
    $m=@{}
    try {
        $q=[string]$uri.Query
        if($q.StartsWith('?')){$q=$q.Substring(1)}
        foreach($pair in @($q -split '&')) {
            if([string]::IsNullOrWhiteSpace($pair)){continue}
            $eq=$pair.IndexOf('=')
            if($eq -lt 0){$k=[Uri]::UnescapeDataString($pair);$v=''}else{$k=[Uri]::UnescapeDataString($pair.Substring(0,$eq));$v=[Uri]::UnescapeDataString($pair.Substring($eq+1))}
            if($k){$m[$k]=$v}
        }
    } catch {}
    return $m
}

$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Any, $port)
$listener.Start()
Write-Host ''
Write-Host '=========================================' -ForegroundColor Cyan
Write-Host ' CNC Mobile 5102 dang chay' -ForegroundColor Cyan
Write-Host " Local: http://127.0.0.1:$port" -ForegroundColor Green
$lanIps = @([Net.Dns]::GetHostAddresses([Net.Dns]::GetHostName()) | Where-Object { $_.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork -and !$_.IPAddressToString.StartsWith('127.') })
foreach ($ip in $lanIps) { Write-Host (" LAN  : http://" + $ip.IPAddressToString + ":" + $port) -ForegroundColor Yellow }
Write-Host " Excel: $($cfg.ExcelPath)" -ForegroundColor Gray
Write-Host ' Ctrl+C de dung server' -ForegroundColor Gray
Write-Host '=========================================' -ForegroundColor Cyan

while ($true) {
    try { Refresh-DataIfNeeded $false } catch {}
    if (!$listener.Pending()) { Start-Sleep -Milliseconds 150; continue }
    $client = $listener.AcceptTcpClient()
    $client.NoDelay = $true
    try {
        $stream = $client.GetStream()
        $reader = New-Object IO.StreamReader($stream, [Text.Encoding]::ASCII, $false, 4096, $true)
        $requestLine = $reader.ReadLine()
        if ([string]::IsNullOrWhiteSpace($requestLine)) { continue }
        $headers = @{}
        while ($true) {
            $line = $reader.ReadLine(); if ($null -eq $line -or $line -eq '') { break }
            $ix = $line.IndexOf(':'); if ($ix -gt 0) { $headers[$line.Substring(0,$ix).Trim().ToLower()] = $line.Substring($ix+1).Trim() }
        }
        $parts = $requestLine.Split(' ')
        if ($parts.Count -lt 2 -or $parts[0] -ne 'GET') {
            Send-Response $stream 400 'text/plain; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes('Bad request')); continue
        }
        $rawTarget = $parts[1]
        $uri = [Uri]("http://localhost" + $rawTarget)
        $path = [Uri]::UnescapeDataString($uri.AbsolutePath)


        # V2.70 DEVICE TRACKING -------------------------------------------------
        if ($path -eq '/api/device-ping') {
            if (!$headers.ContainsKey('x-cnc-pin') -or $headers['x-cnc-pin'] -ne [string]$cfg.Pin) {
                $json=@{ok=$false;error='PIN không đúng'}|ConvertTo-Json -Compress
                Send-Response $stream 401 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $q=Get-QueryMap $uri
            $id=([string]$q['id']).Trim(); if($id.Length -gt 80){$id=$id.Substring(0,80)}
            if([string]::IsNullOrWhiteSpace($id)){$id=[Guid]::NewGuid().ToString('N')}
            $name=([string]$q['name']).Trim(); if($name.Length -gt 60){$name=$name.Substring(0,60)}
            $page=([string]$q['page']).Trim(); if($page.Length -gt 40){$page=$page.Substring(0,40)}
            $ua='';if($headers.ContainsKey('user-agent')){$ua=[string]$headers['user-agent']};if($ua.Length -gt 240){$ua=$ua.Substring(0,240)}
            $ip='';try{$ip=[string]$client.Client.RemoteEndPoint.Address}catch{}
            if($headers.ContainsKey('cf-connecting-ip')){$ip=[string]$headers['cf-connecting-ip']}
            elseif($headers.ContainsKey('x-forwarded-for')){$ip=([string]$headers['x-forwarded-for']).Split(',')[0].Trim()}
            $now=Get-Date
            $script:ActiveDevices[$id]=[pscustomobject]@{id=$id;name=$name;page=$page;ip=$ip;userAgent=$ua;lastSeen=$now;firstSeen=$(if($script:ActiveDevices.ContainsKey($id)){$script:ActiveDevices[$id].firstSeen}else{$now})}
            # prune stale entries older than 24h
            foreach($dk in @($script:ActiveDevices.Keys)){try{if(($now-$script:ActiveDevices[$dk].lastSeen).TotalHours -gt 24){$script:ActiveDevices.Remove($dk)}}catch{}}
            $json=@{ok=$true;id=$id;serverTime=$now.ToString('s')}|ConvertTo-Json -Compress
            Send-Response $stream 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
        }

        if ($path -eq '/api/devices') {
            if (!$headers.ContainsKey('x-cnc-pin') -or $headers['x-cnc-pin'] -ne [string]$cfg.Pin) {
                $json=@{ok=$false;error='PIN không đúng'}|ConvertTo-Json -Compress
                Send-Response $stream 401 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $now=Get-Date;$items=New-Object System.Collections.Generic.List[object]
            foreach($d in @($script:ActiveDevices.Values)){
                $age=[Math]::Max(0,[int]($now-$d.lastSeen).TotalSeconds)
                $items.Add([pscustomobject]@{id=$d.id;name=$d.name;page=$d.page;ip=$d.ip;userAgent=$d.userAgent;lastSeen=$d.lastSeen.ToString('yyyy-MM-dd HH:mm:ss');secondsAgo=$age;online=($age -le $script:DeviceOnlineSeconds)})
            }
            $arr=@($items.ToArray()|Sort-Object @{Expression='online';Descending=$true},@{Expression='secondsAgo';Ascending=$true})
            $json=@{ok=$true;onlineCount=@($arr|Where-Object {$_.online}).Count;totalCount=$arr.Count;onlineSeconds=$script:DeviceOnlineSeconds;devices=$arr}|ConvertTo-Json -Depth 5 -Compress
            Send-Response $stream 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
        }
        # ----------------------------------------------------------------------

        
        if ($path -eq '/api/excel-change-history') {
            if (!$headers.ContainsKey('x-cnc-pin') -or $headers['x-cnc-pin'] -ne [string]$cfg.Pin) {
                $json=@{ok=$false;error='PIN không đúng'}|ConvertTo-Json -Compress
                Send-Response $stream 401 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $json=@{ok=$true;history=@($script:ExcelChangeHistory)}|ConvertTo-Json -Depth 9 -Compress
            Send-Response $stream 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
        }

        if ($path -eq '/api/today-xln') {
            try {
                # V2.63: cho phep chon ngay ?date=yyyy-MM-dd. Neu khong co date thi mac dinh hom nay.
                $targetDate=(Get-Date).Date
                $dateParam=''
                # V2.66: parse query theo tung cap key=value. Ban cu cast ca mang Split('&') sang [string]
                # nen tham so date co the bi bo qua va API luon quay ve ngay hom nay.
                try {
                    $queryText=[string]$uri.Query
                    if($queryText.StartsWith('?')){$queryText=$queryText.Substring(1)}
                    foreach($pair in @($queryText -split '&')) {
                        if([string]::IsNullOrWhiteSpace($pair)){continue}
                        $eq=$pair.IndexOf('=')
                        if($eq -lt 0){continue}
                        $qk=[Uri]::UnescapeDataString($pair.Substring(0,$eq))
                        if($qk -ieq 'date') {
                            $dateParam=[Uri]::UnescapeDataString($pair.Substring($eq+1))
                            break
                        }
                    }
                } catch {}
                if(![string]::IsNullOrWhiteSpace($dateParam)) {
                    $parsed=[datetime]::MinValue
                    if([datetime]::TryParseExact($dateParam,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$parsed)){$targetDate=$parsed.Date}
                }
                $targetText=$targetDate.ToString('dd/MM/yyyy')
                $allRows=New-Object System.Collections.Generic.List[object]
                if($null -ne $script:XlnDetailsByWo) {
                    foreach($k in @($script:XlnDetailsByWo.Keys)) {
                        $lst=$script:XlnDetailsByWo[$k]
                        if($null -eq $lst){continue}
                        foreach($xr in $lst) {
                            if(([string]$xr.date).Trim() -ne $targetText){continue}
                            $finished=$false;$remaining=0.0;$currentStatus='';$customer=''
                            try {
                                $key=([string]$xr.workOrder).Trim().ToUpperInvariant()
                                if($script:ByWo.ContainsKey($key)) {
                                    $woRow=$script:ByWo[$key]
                                    $customer=([string]$woRow.customer).Trim()
                                    $currentStatus=([string]$woRow.status).Trim()
                                    $finished=$currentStatus.Equals('FINISH',[StringComparison]::OrdinalIgnoreCase)
                                    if(!$finished){$remaining=[Math]::Abs([double]$woRow.notOkQty)}
                                }
                            } catch {}
                            $allRows.Add([pscustomobject]@{
                                rowNumber=$xr.rowNumber;date=$xr.date;workOrder=$xr.workOrder;customer=$customer;
                                material=$xr.material;productName=$xr.productName;spec=$xr.spec;unit=$xr.unit;
                                qty=[double]$xr.qty;kg=[double]$xr.kg;status=$xr.status;note=$xr.note;line=$xr.line;pcsPerKg=[double]$xr.pcsPerKg;
                                orderFinished=$finished;currentOrderStatus=$currentStatus;remainingQty=$remaining
                            })
                        }
                    }
                }
                [object[]]$rows=@($allRows.ToArray() | Sort-Object workOrder,rowNumber)
                $woSet=@{};$totalQty=0.0;$totalKg=0.0
                foreach($r in $rows){$woSet[([string]$r.workOrder).ToUpperInvariant()]=$true;$totalQty += [double]$r.qty;$totalKg += [double]$r.kg}
                $json=@{ok=$true;date=$targetText;workOrderCount=$woSet.Count;rowCount=$rows.Count;totalQty=$totalQty;totalKg=$totalKg;rows=$rows}|ConvertTo-Json -Compress -Depth 6
                Send-Response $stream 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json));continue
            } catch {
                $json=@{ok=$false;error=$_.Exception.Message}|ConvertTo-Json -Compress
                Send-Response $stream 500 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json));continue
            }
        }

        # V2.62: Dashboard + CNC Assistant dung nguon ByWo.Values on dinh.
        # ByWo la index cong don da publish hoan chinh; khong phu thuoc $script:Rows co the rong tam thoi khi refresh.
        function Get-CncStatusRows([string]$kind) {
            $result = @()
            $sourceRows = @()
            if ($null -ne $script:ByWo -and $script:ByWo.Count -gt 0) {
                $sourceRows = @($script:ByWo.Values | ForEach-Object { $_ })
            }
            foreach ($r in $sourceRows) {
                if ($null -eq $r) { continue }
                $st = ([string]$r.status).Trim().ToUpperInvariant()
                if ($kind -eq 'waiting') {
                    if ($st -eq 'WAITING') { $result += $r }
                } elseif ($kind -eq 'shortage') {
                    if ($st -eq 'WAITING' -and [double]$r.issueDiff -lt 0) { $result += $r }
                } elseif ($kind -eq 'finish') {
                    if ($st -eq 'FINISH') { $result += $r }
                } elseif ($kind -eq 'all') {
                    $result += $r
                }
            }
            return $result
        }

        if ($path -eq '/api/dashboard') {
            if (!$headers.ContainsKey('x-cnc-pin') -or $headers['x-cnc-pin'] -ne [string]$cfg.Pin) {
                $json = @{ok=$false; error='PIN không đúng'} | ConvertTo-Json -Compress
                Send-Response $stream 401 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $waiting = @(Get-CncStatusRows 'waiting')
            $shortage = @(Get-CncStatusRows 'shortage')
            $today = (Get-Date).Date
            $todayCount = 0
            $futureDates = New-Object System.Collections.Generic.List[datetime]
            foreach ($r in $waiting) {
                if (![string]::IsNullOrWhiteSpace([string]$r.shipDate)) {
                    $d = [datetime]::MinValue
                    if ([datetime]::TryParseExact([string]$r.shipDate,'dd/MM/yyyy',[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::None,[ref]$d)) {
                        if ($d.Date -eq $today) { $todayCount++ }
                        if ($d.Date -ge $today) { $futureDates.Add($d.Date) }
                    }
                }
            }
            $nearestDate = ''
            $nearestCount = 0
            if ($futureDates.Count -gt 0) {
                $near = @($futureDates | Sort-Object)[0]
                $nearestDate = $near.ToString('dd/MM/yyyy')
                $nearestCount = @($futureDates | Where-Object { $_ -eq $near }).Count
            }
            $sft = Load-SftSettingsFromFixed92
            $sftOk = (![string]::IsNullOrWhiteSpace($sft.UserId) -and ![string]::IsNullOrWhiteSpace($sft.Password))
            $printer = ''
            try { Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue; $printer = (New-Object System.Drawing.Printing.PrinterSettings).PrinterName } catch {}
            $excelOk = Test-Path ([string]$cfg.ExcelPath) -PathType Leaf
            $payload = @{
                ok=$true
                waitingTotal=$waiting.Count
                shortageCount=$shortage.Count
                shipTodayCount=$todayCount
                nearestShipDate=$nearestDate
                nearestShipCount=$nearestCount
                sourceUpdated=$script:LastWrite.ToString('dd/MM/yyyy HH:mm')
                excelReloading=($null -ne $script:CacheBuildProcess -and !$script:CacheBuildProcess.HasExited)
                excelReloadSeconds=$(if($null -ne $script:CacheBuildProcess -and !$script:CacheBuildProcess.HasExited -and $script:CacheBuildStartedAt -ne [datetime]::MinValue){[int]((Get-Date)-$script:CacheBuildStartedAt).TotalSeconds}else{0})
                latestExcelChange=$(if(@($script:ExcelChangeHistory).Count -gt 0){$c=$script:ExcelChangeHistory[0];[pscustomobject]@{id=$c.id;at=$c.at;durationSeconds=$c.durationSeconds;workOrdersAffected=$c.workOrdersAffected;totalChanges=$c.totalChanges;summary=$c.summary;baseline=[bool]$c.baseline;note=[string]$c.note}}else{$null})
                system=@{server=$true; excel=$excelOk; sft=$sftOk; printer=(![string]::IsNullOrWhiteSpace($printer)); printerName=$printer}
            } | ConvertTo-Json -Depth 5 -Compress
            Send-Response $stream 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($payload)); continue
        }


        if ($path -eq '/api/issue-details' -or $path -eq '/api/xln-details') {
            if (!$headers.ContainsKey('x-cnc-pin') -or $headers['x-cnc-pin'] -ne [string]$cfg.Pin) {
                $json = @{ok=$false; error='PIN không đúng'} | ConvertTo-Json -Compress
                Send-Response $stream 401 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            try {
                $q=[System.Web.HttpUtility]::ParseQueryString($uri.Query)
                $wo=Normalize-WorkOrder $q['workOrder']
                if([string]::IsNullOrWhiteSpace($wo)){
                    $json=@{ok=$false;error='Chưa nhập công đơn'}|ConvertTo-Json -Compress
                    Send-Response $stream 400 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json));continue
                }
                if($path -eq '/api/issue-details'){$d=Get-IssueDetailsFromCache $wo;$kind='issue'}else{$d=Get-XlnDetailsFromCache $wo;$kind='xln'}
                $payload=@{ok=$true;kind=$kind;workOrder=$wo;count=$d.count;totalQty=$d.totalQty;totalKg=$d.totalKg;rows=$d.rows}
                if($kind -eq 'xln'){$payload['rate']=$d.rate}
                $json=$payload|ConvertTo-Json -Depth 6 -Compress
                Send-Response $stream 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json));continue
            } catch {
                $json=@{ok=$false;error=$_.Exception.Message}|ConvertTo-Json -Compress
                Send-Response $stream 500 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json));continue
            }
        }

        if ($path -eq '/api/assistant') {
            if (!$headers.ContainsKey('x-cnc-pin') -or $headers['x-cnc-pin'] -ne [string]$cfg.Pin) {
                $json = @{ok=$false; error='PIN không đúng'} | ConvertTo-Json -Compress
                Send-Response $stream 401 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            try {
                $qv = [System.Web.HttpUtility]::ParseQueryString($uri.Query)
                $text = ([string]$qv['q']).Trim()
                $offset = 0
                try { $offset = [Math]::Max(0,[int]$qv['offset']) } catch { $offset = 0 }
                $limit = 15

                # V2.69: conversational context sent by the Assistant client.
                $ctxMaterial = ([string]$qv['ctxMaterial']).Trim()
                $ctxCustomer = ([string]$qv['ctxCustomer']).Trim()
                $ctxIntent = ([string]$qv['ctxIntent']).Trim()
                $ctxWorkOrder = ([string]$qv['ctxWorkOrder']).Trim()
                if ([string]::IsNullOrWhiteSpace($text)) {
                    $json=@{ok=$false;error='Hãy nhập câu hỏi cho CNC Assistant'}|ConvertTo-Json -Compress
                    Send-Response $stream 400 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
                }

                $lower=$text.ToLowerInvariant()
                $rows=@(); $answer=''; $mode='list'; $target=$null
                $totalCount=0; $nextOffset=$null; $intent=''

                # V2.52: diagnostic rieng cho CNC Assistant. Ghi UTF-8 de bat dung cho loi
                # intent -> pool -> paging -> JSON ma khong phu thuoc stdout cua launcher.
                $aiLogDir = Join-Path $PSScriptRoot 'LOGS'
                if (!(Test-Path $aiLogDir)) { New-Item -ItemType Directory -Path $aiLogDir -Force | Out-Null }
                $aiLog = Join-Path $aiLogDir 'assistant-debug.log'
                function Write-AiDebug([string]$msg) {
                    try { Add-Content -LiteralPath $aiLog -Value ("[{0}] {1}" -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'),$msg) -Encoding UTF8 } catch {}
                }
                Write-AiDebug ("REQUEST q=[{0}] lower=[{1}] offset={2} Rows={3} ByWo={4}" -f $text,$lower,$offset,@($script:Rows).Count,$script:ByWo.Count)

                # V2.53: Assistant lay truc tiep tu ByWo.Values.
                # Diagnostic V2.52 da xac nhan Rows=0 trong khi ByWo co day du cong don.
                function Get-CncAssistantRows([string]$kind) {
                    $result = New-Object System.Collections.Generic.List[object]
                    foreach ($entry in $script:ByWo.GetEnumerator()) {
                        $r = $entry.Value
                        if ($null -eq $r) { continue }
                        $st = ([string]$r.status).Trim().ToUpperInvariant()
                        if ($kind -eq 'waiting') {
                            if ($st -eq 'WAITING') { $result.Add($r) }
                        } elseif ($kind -eq 'shortage') {
                            if ($st -eq 'WAITING' -and [double]$r.issueDiff -lt 0) { $result.Add($r) }
                        } elseif ($kind -eq 'finish') {
                            if ($st -eq 'FINISH') { $result.Add($r) }
                        } elseif ($kind -eq 'all') {
                            $result.Add($r)
                        }
                    }
                    return $result.ToArray()
                }

                # Chỉ coi là tra một công đơn cụ thể khi câu có đúng 9 số hoặc 5102-xxxxxxxxx.
                $m=[regex]::Match($text,'(?<!\d)(\d{9})(?!\d)')
                $mf=[regex]::Match($text,'5102-?\d{9}',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
                $wo=''
                if($mf.Success){$wo=$mf.Value;if($wo -notmatch '-'){ $wo='5102-'+$wo.Substring(4) }}elseif($m.Success){$wo='5102-'+$m.Groups[1].Value}

                # V2.69: follow-up language can reuse the previous context.
                $useContext = ($lower -match '(chỉ|chi|đơn đó|don do|đơn này|don nay|nhóm đó|nhom do|thế|the|vậy|vay|tiếp|tiep|còn bao nhiêu|con bao nhieu|nếu|neu|giả\s*sử|gia\s*su|mô\s*phỏng|mo\s*phong|chia|phân\s*bổ|phan\s*bo)')
                $nearestOnly = ($lower -match '(gần\s*nhất|gan\s*nhat|sớm\s*nhất|som\s*nhat|ưu\s*tiên\s*nhất|uu\s*tien\s*nhat|đơn\s*nào\s*trước|don\s*nao\s*truoc)')
                $effectiveWo=$wo
                if([string]::IsNullOrWhiteSpace($effectiveWo) -and $useContext -and -not [string]::IsNullOrWhiteSpace($ctxWorkOrder)){
                    $effectiveWo=$ctxWorkOrder
                }

                # Context returned to the client after this request.
                $responseCtxMaterial=$ctxMaterial
                $responseCtxCustomer=$ctxCustomer
                $responseCtxIntent=$ctxIntent
                $responseCtxWorkOrder=$ctxWorkOrder

                # V2.68: hiểu câu phân bổ/chia số lượng tự nhiên.
                # Ví dụ: "Tôi có 850 PCS thì nên chia vào công đơn nào trước?"
                $isAllocation = ($lower -match '(chia|phân\s*bổ|phan\s*bo|nên\s*chia|nen\s*chia|xếp\s*vào|xep\s*vao|ưu\s*tiên\s*đơn|uu\s*tien\s*don)')
                $allocationQty = 0.0
                $qm=[regex]::Match($text,'(?i)(\d[\d\s.,]*)\s*(?:pcs|pc)\b')
                if($qm.Success){
                    $rawQty=($qm.Groups[1].Value -replace '\s','')
                    # PCS thường là số nguyên; chấp nhận 1.000 / 1,000 như phân cách hàng nghìn.
                    if($rawQty -match '^\d{1,3}([.,]\d{3})+$'){ $rawQty=$rawQty -replace '[.,]','' }
                    else { $rawQty=$rawQty -replace ',','.' }
                    [void][double]::TryParse($rawQty,[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$allocationQty)
                }
                if($isAllocation -and $allocationQty -le 0){
                    $qn=[regex]::Match($text,'(?i)(?:có|co|chia|phân\s*bổ|phan\s*bo)\s*(\d[\d\s.,]*)')
                    if($qn.Success){
                        $rawQty=($qn.Groups[1].Value -replace '\s','')
                        if($rawQty -match '^\d{1,3}([.,]\d{3})+$'){ $rawQty=$rawQty -replace '[.,]','' } else { $rawQty=$rawQty -replace ',','.' }
                        [void][double]::TryParse($rawQty,[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$allocationQty)
                    }
                }

                # V2.69: simulation is read-only. It never changes Excel/cache data.
                $isSimulation = ($lower -match '(mô\s*phỏng|mo\s*phong|giả\s*sử|gia\s*su|nếu|neu|thử\s*chia|thu\s*chia)' -and $lower -match '(chia|chuyển|chuyen)') -or
                                ($lower -match '(chia|chuyển|chuyen).*(còn\s*bao\s*nhiêu|con\s*bao\s*nhieu|thì\s*còn|thi\s*con)')
                if($isSimulation -and $allocationQty -le 0){
                    $simQ=[regex]::Match($text,'(?i)(\d[\d\s.,]*)\s*(?:pcs|pc)\b')
                    if($simQ.Success){
                        $rawQty=($simQ.Groups[1].Value -replace '\s','')
                        if($rawQty -match '^\d{1,3}([.,]\d{3})+$'){ $rawQty=$rawQty -replace '[.,]','' } else { $rawQty=$rawQty -replace ',','.' }
                        [void][double]::TryParse($rawQty,[Globalization.NumberStyles]::Any,[Globalization.CultureInfo]::InvariantCulture,[ref]$allocationQty)
                    }
                }

                if($isSimulation -and $allocationQty -gt 0) {
                    $intent='simulate';$mode='simulation'
                    if([string]::IsNullOrWhiteSpace($effectiveWo)){
                        $answer="Em hiểu sếp muốn mô phỏng chia $([Math]::Round($allocationQty,0)) PCS, nhưng chưa biết công đơn nào. Sếp nói số công đơn hoặc hỏi tiếp sau khi vừa tra một công đơn."
                        $rows=@();$totalCount=0;$mode='need-order'
                    } elseif(-not $script:ByWo.ContainsKey($effectiveWo.ToUpperInvariant())){
                        $answer="Không tìm thấy công đơn $effectiveWo để mô phỏng.";$rows=@();$totalCount=0;$mode='empty'
                    } else {
                        $src=$script:ByWo[$effectiveWo.ToUpperInvariant()]
                        $sim=$src | Select-Object *
                        $need=[Math]::Abs([double]$src.notOkQty)
                        if(([string]$src.status).Trim().ToUpperInvariant() -eq 'FINISH'){
                            $after=0
                            $surplus=$need+$allocationQty
                        } else {
                            $after=[Math]::Max(0,$need-$allocationQty)
                            $surplus=[Math]::Max(0,$allocationQty-$need)
                        }
                        $sim|Add-Member -NotePropertyName simulationQty -NotePropertyValue $allocationQty -Force
                        $sim|Add-Member -NotePropertyName simulationRemaining -NotePropertyValue $after -Force
                        $sim|Add-Member -NotePropertyName simulationSurplus -NotePropertyValue $surplus -Force
                        $rows=@($sim);$totalCount=1;$nextOffset=$null
                        $responseCtxWorkOrder=[string]$src.workOrder
                        $responseCtxMaterial=[string]$src.material
                        $responseCtxCustomer=[string]$src.customer
                        $responseCtxIntent='order'
                        if(([string]$src.status).Trim().ToUpperInvariant() -eq 'FINISH'){
                            $answer="Công đơn $effectiveWo đã FINISH. Mô phỏng thêm $([Math]::Round($allocationQty,0)) PCS sẽ chỉ làm tăng phần dư; em không thay đổi dữ liệu thật."
                        } elseif($surplus -gt 0){
                            $answer="Mô phỏng ${effectiveWo}: hiện còn $([Math]::Round($need,0)) PCS. Nếu chia $([Math]::Round($allocationQty,0)) PCS thì đơn đủ và dư $([Math]::Round($surplus,0)) PCS. Đây chỉ là mô phỏng, không sửa Excel."
                        } elseif($after -eq 0){
                            $answer="Mô phỏng ${effectiveWo}: nếu chia $([Math]::Round($allocationQty,0)) PCS thì đơn vừa đủ. Đây chỉ là mô phỏng, không sửa Excel."
                        } else {
                            $answer="Mô phỏng ${effectiveWo}: hiện còn $([Math]::Round($need,0)) PCS. Nếu chia $([Math]::Round($allocationQty,0)) PCS thì còn thiếu $([Math]::Round($after,0)) PCS. Đây chỉ là mô phỏng, không sửa Excel."
                        }
                    }
                } elseif($isAllocation -and $allocationQty -gt 0) {
                    $intent='allocate';$mode='allocation'
                    $pool=@(Get-CncAssistantRows 'waiting')

                    # Có thể suy ra mã liệu từ công đơn được nhắc trong câu.
                    $allocationMaterial=''
                    if($effectiveWo -and $script:ByWo.ContainsKey($effectiveWo.ToUpperInvariant())){
                        $allocationMaterial=[string]$script:ByWo[$effectiveWo.ToUpperInvariant()].material
                    }
                    $mat=[regex]::Match($text,'(?:mã liệu|ma lieu)\s*[:\-]?\s*([A-Za-z0-9._\-/]+)',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
                    if($mat.Success){ $allocationMaterial=$mat.Groups[1].Value.Trim() }
                    elseif($useContext -and -not [string]::IsNullOrWhiteSpace($ctxMaterial)){ $allocationMaterial=$ctxMaterial }

                    if(-not [string]::IsNullOrWhiteSpace($allocationMaterial)){
                        $needleMat=$allocationMaterial.ToUpperInvariant()
                        $pool=@($pool|Where-Object{([string]$_.material).ToUpperInvariant().Contains($needleMat)})
                    }

                    # Hỗ trợ thêm khách hàng trong cùng câu phân bổ.
                    $allocationCustomer=''
                    $custAlloc=[regex]::Match($text,'(?:khách\s*hàng|khach\s*hang|customer)\s*[:\-]?\s*(.+?)(?=\s+(?:mã\s*liệu|ma\s*lieu)\b|$)',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
                    if($custAlloc.Success){ $allocationCustomer=$custAlloc.Groups[1].Value.Trim() }
                    elseif($useContext -and -not [string]::IsNullOrWhiteSpace($ctxCustomer)){ $allocationCustomer=$ctxCustomer }
                    if(-not [string]::IsNullOrWhiteSpace($allocationCustomer)){
                        $normNeed=($allocationCustomer.ToLowerInvariant() -replace '[^a-z0-9]','')
                        $pool=@($pool|Where-Object{ (([string]$_.customer).ToLowerInvariant() -replace '[^a-z0-9]','').Contains($normNeed) })
                    }

                    $distinctMaterials=@($pool|ForEach-Object{([string]$_.material).Trim()}|Where-Object{$_}|Sort-Object -Unique)
                    if(-not [string]::IsNullOrWhiteSpace($allocationCustomer)){ $responseCtxCustomer=$allocationCustomer }
                    if(-not [string]::IsNullOrWhiteSpace($allocationMaterial)){ $responseCtxMaterial=$allocationMaterial }
                    elseif($distinctMaterials.Count -eq 1){ $responseCtxMaterial=[string]$distinctMaterials[0] }
                    $responseCtxIntent='waiting'
                    if($effectiveWo){$responseCtxWorkOrder=$effectiveWo}
                    if([string]::IsNullOrWhiteSpace($allocationMaterial) -and $distinctMaterials.Count -gt 1){
                        $answer="Em đã hiểu sếp có $([Math]::Round($allocationQty,0)) PCS cần chia, nhưng các đơn WAITING đang có nhiều mã liệu khác nhau. Sếp thêm mã liệu để em chia chính xác, ví dụ: '850 PCS mã liệu 8205... nên chia đơn nào trước?'."
                        $rows=@();$totalCount=0;$mode='need-material'
                    } else {
                        $sorted=@($pool|Where-Object{[Math]::Abs([double]$_.notOkQty) -gt 0}|Sort-Object @{Expression={if($_.shipDate){try{[datetime]::ParseExact($_.shipDate,'dd/MM/yyyy',$null)}catch{[datetime]::MaxValue}}else{[datetime]::MaxValue}}}, @{Expression={$_.workOrder}})
                        $remain=$allocationQty
                        $plan=New-Object System.Collections.Generic.List[object]
                        foreach($r in $sorted){
                            if($remain -le 0){break}
                            $need=[Math]::Abs([double]$r.notOkQty)
                            if($need -le 0){continue}
                            $put=[Math]::Min($remain,$need)
                            $planRow=$r | Select-Object *
                            $planRow|Add-Member -NotePropertyName allocationQty -NotePropertyValue $put -Force
                            $planRow|Add-Member -NotePropertyName remainingAfter -NotePropertyValue ([Math]::Max(0,$need-$put)) -Force
                            $plan.Add($planRow)
                            $remain-=$put
                        }
                        $rows=$plan.ToArray();$totalCount=$rows.Count;$nextOffset=$null
                        if($rows.Count -eq 0){
                            $answer='Không có đơn WAITING phù hợp để chia số lượng này.';$mode='empty'
                        } else {
                            $used=$allocationQty-$remain
                            $matLabel=if($distinctMaterials.Count -eq 1){" mã liệu $($distinctMaterials[0])"}else{''}
                            $answer="Với $([Math]::Round($allocationQty,0)) PCS$matLabel, em ưu tiên theo lịch xuất gần nhất và SL chưa OK. Có thể chia $([Math]::Round($used,0)) PCS vào $($rows.Count) công đơn."
                            if($remain -gt 0){$answer += " Sau khi bù hết các đơn phù hợp vẫn còn dư $([Math]::Round($remain,0)) PCS."}
                            else{$answer += ' Các thẻ bên dưới đã ghi rõ số PCS đề xuất cho từng công đơn.'}
                        }
                    }
                } elseif($wo -and $script:ByWo.ContainsKey($wo.ToUpperInvariant())) {
                    $target=$script:ByWo[$wo.ToUpperInvariant()]
                    $mk=([string]$target.material).ToUpperInvariant();$ratio=0.0;$recentRatios=@()
                    if($script:ConversionByMaterial.ContainsKey($mk)){$ratio=[double]$script:ConversionByMaterial[$mk].ratio;$recentRatios=@($script:ConversionByMaterial[$mk].recent)}
                    $target|Add-Member -NotePropertyName conversionRatio -NotePropertyValue $ratio -Force
                    $target|Add-Member -NotePropertyName conversionRecent -NotePropertyValue @($recentRatios) -Force
                    $rows=@($target);$mode='order';$intent='order';$totalCount=1
                    $responseCtxWorkOrder=[string]$target.workOrder
                    $responseCtxMaterial=[string]$target.material
                    $responseCtxCustomer=[string]$target.customer
                    $responseCtxIntent='order'
                    if (([string]$target.status).Trim().ToUpperInvariant() -eq 'FINISH') {
                        $answer="Công đơn ${wo}: $($target.status). Đang dư $([Math]::Abs([double]$target.notOkQty)) PCS; đã lĩnh $([double]$target.issuedQty) PCS; chuyển KH $([double]$target.transferredQty) PCS; NG $([double]$target.ngQty) PCS."
                    } else {
                        $answer="Công đơn ${wo}: $($target.status). SL chưa OK $([Math]::Abs([double]$target.notOkQty)) PCS; đã lĩnh $([double]$target.issuedQty) PCS; chuyển KH $([double]$target.transferredQty) PCS; NG $([double]$target.ngQty) PCS."
                    }
                    if([double]$target.issueDiff -lt 0){$answer += " Đang thiếu liệu $([Math]::Abs([double]$target.issueDiff)) PCS."}
                    elseif([double]$target.issueDiff -gt 0){$answer += " Có lĩnh bù $([double]$target.issueDiff) PCS."}
                    if($target.shipDate){$answer += " Lịch xuất $($target.shipDate)."}
                } elseif($wo) {
                    $answer="Không tìm thấy công đơn $wo trong dữ liệu 5102 hiện tại.";$mode='empty';$intent='order';$totalCount=0
                } else {
                    # QUAN TRỌNG: Assistant dùng trực tiếp cùng nguồn/cùng điều kiện với /api/dashboard.
                    # Không đi qua collection trung gian để tránh sai lệch trên Windows PowerShell 5.1.
                    $pool=@()
                    $hasFilter=$false

                    if($lower -match 'thiếu liệu|thieu lieu|lĩnh chưa đủ|linh chua du'){
                        $pool=@(Get-CncAssistantRows 'shortage')
                        $intent='shortage';$hasFilter=$true
                    } elseif($lower -match 'waiting|chưa xong|chua xong|còn đơn|con don'){
                        $pool=@(Get-CncAssistantRows 'waiting')
                        $intent='waiting';$hasFilter=$true
                    } elseif($lower -match 'finish|hoàn thành|hoan thanh|đã xong|da xong'){
                        $pool=@(Get-CncAssistantRows 'finish')
                        $intent='finish';$hasFilter=$true
                    } elseif($nearestOnly -and $useContext){
                        $pool=@(Get-CncAssistantRows 'waiting')
                        $intent='waiting';$hasFilter=$true
                    } else {
                        $pool=@(Get-CncAssistantRows 'all')
                    }
                    Write-AiDebug ("INTENT={0} source=ByWo.Values hasFilter={1} poolAfterIntent={2}" -f $intent,$hasFilter,@($pool).Count)

                    $day=$null
                    if($lower -match 'ngày mai|ngay mai'){$day=(Get-Date).Date.AddDays(1);$hasFilter=$true}
                    elseif($lower -match 'hôm nay|hom nay'){$day=(Get-Date).Date;$hasFilter=$true}
                    if($day){$ds=$day.ToString('dd/MM/yyyy');$pool=@($pool|Where-Object{$_.shipDate -eq $ds});if(!$intent){$intent='shipdate'}}

                    $mat=[regex]::Match($text,'(?:mã liệu|ma lieu)\s*[:\-]?\s*([A-Za-z0-9._\-/]+)',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
                    if($mat.Success){
                        $needle=$mat.Groups[1].Value.ToUpperInvariant();$pool=@($pool|Where-Object{([string]$_.material).ToUpperInvariant().Contains($needle)});$hasFilter=$true;if(!$intent){$intent='material'}
                        $responseCtxMaterial=$mat.Groups[1].Value.Trim()
                    } elseif($useContext -and -not [string]::IsNullOrWhiteSpace($ctxMaterial)){
                        $needle=$ctxMaterial.ToUpperInvariant();$pool=@($pool|Where-Object{([string]$_.material).ToUpperInvariant().Contains($needle)});$hasFilter=$true
                        $responseCtxMaterial=$ctxMaterial
                    }

                    # V2.56: tim khach hang theo 3 kieu:
                    #   "khach hang mkt-246", "waiting khach hang mkt-246", hoac chi "mkt-246".
                    # Tim fuzzy theo cac cum chu/so dung thu tu: mkt-246 khop 222MKT-PI-246.
                    function Normalize-AiSearchText([string]$s){
                        if([string]::IsNullOrWhiteSpace($s)){ return '' }
                        $d=$s.Normalize([Text.NormalizationForm]::FormD)
                        $sb=New-Object Text.StringBuilder
                        foreach($ch in $d.ToCharArray()){
                            if([Globalization.CharUnicodeInfo]::GetUnicodeCategory($ch) -ne [Globalization.UnicodeCategory]::NonSpacingMark){ [void]$sb.Append($ch) }
                        }
                        return $sb.ToString().Normalize([Text.NormalizationForm]::FormC).ToLowerInvariant().Trim()
                    }
                    function Test-AiCustomerMatch([string]$customer,[string]$needle){
                        $hay=Normalize-AiSearchText $customer
                        $n=Normalize-AiSearchText $needle
                        $parts=@([regex]::Matches($n,'[a-z0-9]+') | ForEach-Object { $_.Value } | Where-Object { $_ })
                        if($parts.Count -le 0){ return $false }
                        $pattern=(($parts | ForEach-Object { [regex]::Escape($_) }) -join '.*')
                        return ($hay -match $pattern)
                    }

                    $customerText=''
                    $cust=[regex]::Match($text,'(?:khách\s*hàng|khach\s*hang|customer)\s*[:\-]?\s*(.+?)(?=\s+(?:mã\s*liệu|ma\s*lieu|hôm\s*nay|hom\s*nay|ngày\s*mai|ngay\s*mai)\b|$)',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
                    if($cust.Success){
                        $customerText=$cust.Groups[1].Value.Trim()
                    } else {
                        # Neu khong co tu "khach hang", bo cac tu lenh da biet de lay phan con lai lam tu khoa KH.
                        # VD: "waiting mkt-246" -> "mkt-246"; "mkt-246" -> "mkt-246".
                        $candidate=$text
                        $candidate=[regex]::Replace($candidate,'(?i)\b(waiting|finish)\b',' ')
                        $candidate=[regex]::Replace($candidate,'(?i)(tìm\s*đơn\s*của|tim\s*don\s*cua|tìm\s*đơn|tim\s*don|tra\s*đơn|tra\s*don|xem\s*đơn|xem\s*don|cho\s*tôi|cho\s*toi|của|cua)',' ')
                        $candidate=[regex]::Replace($candidate,'(?i)(thiếu\s*liệu|thieu\s*lieu|lĩnh\s*chưa\s*đủ|linh\s*chua\s*du|chưa\s*xong|chua\s*xong|còn\s*đơn|con\s*don|hoàn\s*thành|hoan\s*thanh|đã\s*xong|da\s*xong)',' ')
                        $candidate=[regex]::Replace($candidate,'(?i)(xuất\s*hôm\s*nay|xuat\s*hom\s*nay|hôm\s*nay|hom\s*nay|xuất\s*ngày\s*mai|xuat\s*ngay\s*mai|ngày\s*mai|ngay\s*mai)',' ')
                        # Follow-up commands are not customer names.
                        $candidate=[regex]::Replace($candidate,'(?i)(chỉ\s*lấy|chi\s*lay|đơn\s*xuất\s*gần\s*nhất|don\s*xuat\s*gan\s*nhat|gần\s*nhất|gan\s*nhat|sớm\s*nhất|som\s*nhat|ưu\s*tiên\s*nhất|uu\s*tien\s*nhat|đơn\s*nào\s*trước|don\s*nao\s*truoc)',' ')
                        $candidate=$candidate.Trim(' ',':','-')
                        if(-not [string]::IsNullOrWhiteSpace($candidate)){
                            # Khong bien cac cau lenh/tra cuu ma lieu thanh bo loc khach hang ngoai y muon.
                            if($candidate -notmatch '(?i)^(đơn|don)$' -and $candidate -notmatch '(?i)(mã\s*liệu|ma\s*lieu)'){
                                $customerText=$candidate
                            }
                        }
                    }
                    if([string]::IsNullOrWhiteSpace($customerText) -and $useContext -and -not [string]::IsNullOrWhiteSpace($ctxCustomer)){
                        $customerText=$ctxCustomer
                    }
                    if(-not [string]::IsNullOrWhiteSpace($customerText)){
                        $beforeCustomer=@($pool).Count
                        $pool=@($pool|Where-Object{ Test-AiCustomerMatch ([string]$_.customer) $customerText })
                        # Tim KH don le nhu "mkt-246" phai duoc xem la mot bo loc hop le.
                        $hasFilter=$true
                        if(!$intent){$intent='customer'}
                        $responseCtxCustomer=$customerText
                        Write-AiDebug ("FILTER customer=[{0}] mode=fuzzy-sequence poolBefore={1} poolAfterCustomer={2}" -f $customerText,$beforeCustomer,@($pool).Count)
                    }

                    if(!$hasFilter){
                        $answer='Sếp hỏi rõ hơn giúp em: WAITING, đơn thiếu liệu, FINISH, xuất hôm nay/ngày mai, mã liệu hoặc nhập số công đơn.'
                        $mode='help';$rows=@();$totalCount=0
                    } else {
                        # Ưu tiên đơn có lịch xuất gần nhất; đơn không có ngày xuất nằm cuối.
                        $sorted=@($pool|Sort-Object @{Expression={if($_.shipDate){try{[datetime]::ParseExact($_.shipDate,'dd/MM/yyyy',$null)}catch{[datetime]::MaxValue}}else{[datetime]::MaxValue}}}, @{Expression={$_.workOrder}})
                        $totalCount=$sorted.Count
                        if($offset -gt $totalCount){$offset=$totalCount}
                        if($nearestOnly -and $offset -eq 0){
                            $rows=@($sorted|Select-Object -First 1)
                            $nextOffset=$null
                        } else {
                            $rows=@($sorted|Select-Object -Skip $offset -First $limit)
                        }
                        Write-AiDebug ("RESULT intent={0} sorted={1} returned={2} offset={3} limit={4}" -f $intent,$totalCount,@($rows).Count,$offset,$limit)
                        $shownEnd=[Math]::Min($offset+$rows.Count,$totalCount)
                        if(-not $nearestOnly -and $shownEnd -lt $totalCount){$nextOffset=$shownEnd}

                        if($totalCount -eq 0){
                            $answer='Không tìm thấy công đơn phù hợp với câu hỏi này.';$mode='empty'
                        } else {
                            switch($intent){
                                'waiting'  { $label='đơn WAITING' }
                                'shortage' { $label='đơn thiếu liệu' }
                                'finish'   { $label='đơn FINISH' }
                                'shipdate' { $label='đơn theo lịch xuất' }
                                'material' { $label='đơn theo mã liệu' }
                                'customer' { $label='đơn theo khách hàng' }
                                default    { $label='công đơn phù hợp' }
                            }
                            if(-not [string]::IsNullOrWhiteSpace($customerText)){
                                if($intent -eq 'waiting'){ $label="đơn WAITING của khách hàng $customerText" }
                                elseif($intent -eq 'shortage'){ $label="đơn thiếu liệu của khách hàng $customerText" }
                                elseif($intent -eq 'finish'){ $label="đơn FINISH của khách hàng $customerText" }
                                elseif($intent -eq 'shipdate'){ $label="đơn theo lịch xuất của khách hàng $customerText" }
                                else { $label="đơn của khách hàng $customerText" }
                            }
                            if($nearestOnly -and $rows.Count -gt 0){
                                $answer="Đơn nên ưu tiên gần lịch xuất nhất là $($rows[0].workOrder), lịch xuất $($rows[0].shipDate)."
                            } elseif($offset -eq 0){
                                $answer="Có $totalCount $label. Đang hiển thị $($rows.Count) đơn ưu tiên gần lịch xuất nhất."
                            } else {
                                $answer="Hiển thị thêm $($rows.Count) đơn ($($offset+1)-$shownEnd / $totalCount)."
                            }
                        }
                    }
                }

                # Refresh conversational context from the result set where it is unambiguous.
                if($intent){$responseCtxIntent=$intent}
                if(@($rows).Count -gt 0){
                    $ctxMats=@($rows|ForEach-Object{([string]$_.material).Trim()}|Where-Object{$_}|Sort-Object -Unique)
                    $ctxCusts=@($rows|ForEach-Object{([string]$_.customer).Trim()}|Where-Object{$_}|Sort-Object -Unique)
                    if($ctxMats.Count -eq 1){$responseCtxMaterial=[string]$ctxMats[0]} elseif($mode -eq 'list'){$responseCtxMaterial=''}
                    if($ctxCusts.Count -eq 1){$responseCtxCustomer=[string]$ctxCusts[0]} elseif($mode -eq 'list'){$responseCtxCustomer=''}
                    if(@($rows).Count -eq 1){$responseCtxWorkOrder=[string]$rows[0].workOrder} else {$responseCtxWorkOrder=''}
                }
                $context=@{
                    material=$responseCtxMaterial;customer=$responseCtxCustomer;
                    intent=$responseCtxIntent;workOrder=$responseCtxWorkOrder
                }

                Write-AiDebug ("RESPONSE mode={0} intent={1} total={2} count={3} nextOffset={4} ctxMat=[{5}] ctxCust=[{6}] ctxWo=[{7}] answer=[{8}]" -f $mode,$intent,$totalCount,@($rows).Count,$nextOffset,$responseCtxMaterial,$responseCtxCustomer,$responseCtxWorkOrder,$answer)
                $payload=@{
                    ok=$true;answer=$answer;mode=$mode;intent=$intent;rows=$rows;count=$rows.Count;
                    totalCount=$totalCount;nextOffset=$nextOffset;query=$text;context=$context;
                    sourceUpdated=$script:LastWrite.ToString('dd/MM/yyyy HH:mm')
                }|ConvertTo-Json -Depth 6 -Compress
                Send-Response $stream 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($payload));continue
            } catch {
                $json=@{ok=$false;error=$_.Exception.Message}|ConvertTo-Json -Compress
                Send-Response $stream 500 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json));continue
            }
        }

        if ($path -eq '/api/search') {
            if (!$headers.ContainsKey('x-cnc-pin') -or $headers['x-cnc-pin'] -ne [string]$cfg.Pin) {
                $json = @{ok=$false; error='PIN không đúng'} | ConvertTo-Json -Compress
                Send-Response $stream 401 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $q = [System.Web.HttpUtility]::ParseQueryString($uri.Query)
            $wo = Normalize-WorkOrder $q['workOrder']
            if ([string]::IsNullOrWhiteSpace($wo)) {
                $json = @{ok=$false; error='Chưa nhập công đơn'} | ConvertTo-Json -Compress
                Send-Response $stream 400 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $key = $wo.ToUpperInvariant()
            if (!$script:ByWo.ContainsKey($key)) {
                $json = @{ok=$false; error='Không tìm thấy công đơn'; workOrder=$wo} | ConvertTo-Json -Compress
                Send-Response $stream 404 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $target = $script:ByWo[$key]
            $mk = ([string]$target.material).ToUpperInvariant()
            $ratio = 0.0
            $recentRatios = @()
            if ($script:ConversionByMaterial.ContainsKey($mk)) { $ratio = [double]$script:ConversionByMaterial[$mk].ratio; $recentRatios=@($script:ConversionByMaterial[$mk].recent) }
            $target | Add-Member -NotePropertyName conversionRatio -NotePropertyValue $ratio -Force
            $target | Add-Member -NotePropertyName conversionRecent -NotePropertyValue @($recentRatios) -Force
            $same = @()
            if ($script:ByMaterial.ContainsKey($mk)) {
                $same = @($script:ByMaterial[$mk] | Where-Object { $_.status -eq 'WAITING' -and $_.workOrder -ne $target.workOrder } | Sort-Object @{Expression={ if ($_.shipDate) { try {[datetime]::ParseExact($_.shipDate,'dd/MM/yyyy',$null)} catch {[datetime]::MaxValue} } else {[datetime]::MaxValue} }} )
            }
            $payload = @{ok=$true; target=$target; waitingSameMaterial=$same; sourceUpdated=$script:LastWrite.ToString('dd/MM/yyyy HH:mm')} | ConvertTo-Json -Depth 6 -Compress
            Send-Response $stream 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($payload)); continue
        }



        # V2.32: Mobile SFT PDF preview for /in. This endpoint does not depend on
        # the CNC 5102 Excel file, so it can print 5100 / 5101 / 5102 orders.
        if ($path -eq '/api/sft-pdf') {
            if (!$headers.ContainsKey('x-cnc-pin') -or $headers['x-cnc-pin'] -ne [string]$cfg.Pin) {
                $json = @{ok=$false; error='PIN không đúng'} | ConvertTo-Json -Compress
                Send-Response $stream 401 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $q = [System.Web.HttpUtility]::ParseQueryString($uri.Query)
            $wo = ([string]$q['workOrder']).Trim().ToUpperInvariant()
            if ($wo -notmatch '^510[012]-\d{9}$') {
                $json = @{ok=$false; error='Công đơn phải có dạng 5100/5101/5102-xxxxxxxxx'} | ConvertTo-Json -Compress
                Send-Response $stream 400 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            try {
                $pdfPath = Create-SftPdf $wo
                $pdfBytes = [IO.File]::ReadAllBytes($pdfPath)
                # V2.36: /in chi can bytes PDF de xem tren dien thoai. Xoa ngay ban local
                # sau khi da doc vao RAM, tranh de lai PDF preview trong SFT_PDF.
                try {
                    if (Test-Path -LiteralPath $pdfPath) {
                        Remove-Item -LiteralPath $pdfPath -Force -ErrorAction Stop
                        Write-SftLog 'INFO' ('MOBILE PREVIEW PDF DELETED=' + $pdfPath)
                    }
                } catch {
                    Write-SftLog 'WARN' ('MOBILE PREVIEW PDF DELETE FAILED=' + $pdfPath + '; ' + $_.Exception.Message)
                }
                $downloadName = ('SFT_' + $wo + '.pdf')
                $extra = @{
                    'Content-Disposition' = ('inline; filename="' + $downloadName + '"')
                    'X-Work-Order' = $wo
                }
                Send-Response $stream 200 'application/pdf' $pdfBytes $extra; continue
            } catch {
                $err = $_.Exception.Message
                Write-SftLog 'ERROR' ('MOBILE PDF; cong don=' + $wo + '; ' + $err)
                $json = @{ok=$false; error=$err; workOrder=$wo} | ConvertTo-Json -Compress
                Send-Response $stream 500 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
        }

        if ($path -eq '/api/print-sft') {
            if (!$headers.ContainsKey('x-cnc-pin') -or $headers['x-cnc-pin'] -ne [string]$cfg.Pin) {
                $json = @{ok=$false; error='PIN không đúng'} | ConvertTo-Json -Compress
                Send-Response $stream 401 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $q = [System.Web.HttpUtility]::ParseQueryString($uri.Query)
            $wo = Normalize-WorkOrder $q['workOrder']
            if ([string]::IsNullOrWhiteSpace($wo)) {
                $json = @{ok=$false; error='Chưa nhập công đơn'} | ConvertTo-Json -Compress
                Send-Response $stream 400 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            $copies = 1
            $tmpCopies = 1
            if ([int]::TryParse([string]$q['copies'], [ref]$tmpCopies)) { $copies = $tmpCopies }
            if ($copies -lt 1) { $copies = 1 }
            if ($copies -gt 10) { $copies = 10 }
            if ($wo -notmatch '^510[012]-\d{9}$') {
                $json = @{ok=$false; error='Công đơn phải có dạng 5100/5101/5102-xxxxxxxxx'} | ConvertTo-Json -Compress
                Send-Response $stream 400 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
            try {
                # V2.33: SFT standalone printing does not depend on the CNC 5102 Excel cache.
                # This allows direct server printing for 5100 / 5101 / 5102 from /in.
                Write-Host ('SFT V2.33: xep hang in nen ' + $copies + ' ban cong don ' + $wo) -ForegroundColor Yellow
                $job = Start-SftPrintBackground $wo $copies
                $json = @{
                    ok=$true
                    queued=$true
                    workOrder=$wo
                    copies=$copies
                    jobPid=$job.pid
                    message='Da nhan lenh in. Web co the tiep tuc su dung binh thuong.'
                } | ConvertTo-Json -Compress
                Send-Response $stream 202 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            } catch {
                $err = $_.Exception.Message
                Write-SftLog 'ERROR' ('Cong don=' + $wo + '; copies=' + $copies + '; ' + $err)
                try { Write-SftLog 'ERROR' ($_.ScriptStackTrace) } catch {}
                $json = @{ok=$false; error=$err; workOrder=$wo; copies=$copies; log='logs\SFT_PRINT.log'} | ConvertTo-Json -Compress
                Send-Response $stream 500 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
            }
        }

        if ($path -eq '/health') {
            $json = @{ok=$true; rows=$script:Rows.Count; updated=$script:LastWrite.ToString('s')} | ConvertTo-Json -Compress
            Send-Response $stream 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes($json)); continue
        }

        if ($path -eq '/') { $path = '/index.html' }
        if ($path -eq '/in' -or $path -eq '/in/') { $path = '/in/index.html' }
        if ($path -eq '/ai' -or $path -eq '/ai/') { $path = '/ai/index.html' }
        if ($path -eq '/admin' -or $path -eq '/admin/') { $path = '/admin/index.html' }
        $safe = $path.TrimStart('/').Replace('/',[IO.Path]::DirectorySeparatorChar)
        if ($safe.Contains('..')) { Send-Response $stream 404 'text/plain' ([Text.Encoding]::UTF8.GetBytes('Not found')); continue }
        $file = Join-Path $Www $safe
        if (!(Test-Path $file -PathType Leaf)) { Send-Response $stream 404 'text/plain; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes('Not found')); continue }
        $bytes = [IO.File]::ReadAllBytes($file)
        Send-Response $stream 200 (Mime-Type $file) $bytes
    } catch [System.IO.IOException] {
        # Client disconnected/cancelled request (common on Safari/Chrome).
    } catch [System.Net.Sockets.SocketException] {
        # Client disconnected/cancelled request.
    } catch [System.ObjectDisposedException] {
        # Connection was already closed by the client.
    } catch {
        try { Send-Response $stream 500 'text/plain; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes(('Server error: ' + $_.Exception.Message))) | Out-Null } catch {}
        Write-Host $_ -ForegroundColor Red
    } finally {
        $client.Close()
    }
}

