@echo off
cd /d "%~dp0"
title CNC Mobile 5102 - Company Cloudflare Setup
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup-Cloudflare.ps1"
exit /b %errorlevel%
