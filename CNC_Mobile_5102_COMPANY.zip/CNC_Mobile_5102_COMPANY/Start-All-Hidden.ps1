﻿$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$serverScript = Join-Path $Root 'Run-Server-With-Log.ps1'
$cloudflared = Join-Path $Root 'tools\cloudflared.exe'
$cloudCfg = Join-Path $Root 'cloudflare-config.yml'
$serverPidFile = Join-Path $Root 'cnc-server.pid'
$cloudPidFile = Join-Path $Root 'cloudflare.pid'
$manualStopFlag = Join-Path $Root 'MANUAL_STOP.flag'

if (Test-Path $manualStopFlag) { exit 30 }

function Test-AlivePidFile([string]$path) {
    if (!(Test-Path $path)) { return $false }
    $txt = (Get-Content $path -Raw -ErrorAction SilentlyContinue).Trim()
    $id = 0
    if (![int]::TryParse($txt,[ref]$id)) { return $false }
    return $null -ne (Get-Process -Id $id -ErrorAction SilentlyContinue)
}

function Test-ServerPort {
    try {
        $c=New-Object Net.Sockets.TcpClient
        $ar=$c.BeginConnect('127.0.0.1',8787,$null,$null)
        $ok=$ar.AsyncWaitHandle.WaitOne(700,$false)
        if($ok -and $c.Connected){ $c.EndConnect($ar); $c.Close(); return $true }
        $c.Close()
    } catch {}
    return $false
}

# Start server only if PID and port 8787 are both not already alive.
if (!(Test-AlivePidFile $serverPidFile) -and !(Test-ServerPort)) {
    Remove-Item $serverPidFile -Force -ErrorAction SilentlyContinue
    $p = Start-Process -FilePath 'powershell.exe' `
        -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$serverScript`"") `
        -WindowStyle Hidden -PassThru
    Start-Sleep -Milliseconds 900
}

# Cloudflare must already be configured once.
if (!(Test-Path $cloudflared)) { exit 20 }
if (!(Test-Path $cloudCfg)) { exit 21 }

# Start cloudflare only if not already alive.
if (!(Test-AlivePidFile $cloudPidFile)) {
    Remove-Item $cloudPidFile -Force -ErrorAction SilentlyContinue
    $p = Start-Process -FilePath $cloudflared `
        -ArgumentList @('tunnel','--config',"`"$cloudCfg`"",'run') `
        -WindowStyle Hidden -PassThru
    [IO.File]::WriteAllText($cloudPidFile,[string]$p.Id,(New-Object Text.UTF8Encoding($false)))
}

exit 0
