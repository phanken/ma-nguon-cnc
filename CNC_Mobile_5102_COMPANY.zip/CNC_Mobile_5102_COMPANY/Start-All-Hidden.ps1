﻿$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$serverScript = Join-Path $Root 'Run-Server-With-Log.ps1'
$cloudflared = Join-Path $Root 'tools\cloudflared.exe'
$cloudCfg = Join-Path $Root 'cloudflare-config.yml'
$serverPidFile = Join-Path $Root 'cnc-server.pid'
$cloudPidFile = Join-Path $Root 'cloudflare.pid'

function Test-AlivePidFile([string]$path) {
    if (!(Test-Path $path)) { return $false }
    $txt = (Get-Content $path -Raw -ErrorAction SilentlyContinue).Trim()
    $id = 0
    if (![int]::TryParse($txt,[ref]$id)) { return $false }
    return $null -ne (Get-Process -Id $id -ErrorAction SilentlyContinue)
}

# Start server only if not already alive.
if (!(Test-AlivePidFile $serverPidFile)) {
    Remove-Item $serverPidFile -Force -ErrorAction SilentlyContinue
    $p = Start-Process -FilePath 'powershell.exe' `
        -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$serverScript`"") `
        -WindowStyle Hidden -PassThru
    Start-Sleep -Milliseconds 900
}

# Cloudflare must already be configured once.
if (!(Test-Path $cloudflared)) { exit 20 }
if (!(Test-Path $cloudCfg)) { exit 21 }

# Start cloudflare only if not already alive.
if (!(Test-AlivePidFile $cloudPidFile)) {
    Remove-Item $cloudPidFile -Force -ErrorAction SilentlyContinue
    $p = Start-Process -FilePath $cloudflared `
        -ArgumentList @('tunnel','--config',"`"$cloudCfg`"",'run') `
        -WindowStyle Hidden -PassThru
    [IO.File]::WriteAllText($cloudPidFile,[string]$p.Id,(New-Object Text.UTF8Encoding($false)))
}

exit 0
