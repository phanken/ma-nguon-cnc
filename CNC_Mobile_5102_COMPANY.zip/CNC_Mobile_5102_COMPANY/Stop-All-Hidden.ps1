﻿$ErrorActionPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$cloudPidFile = Join-Path $Root 'cloudflare.pid'
$serverPidFile = Join-Path $Root 'cnc-server.pid'

function Stop-PidSafe([int]$PidToStop) {
    if ($PidToStop -le 0 -or $PidToStop -eq $PID) { return $false }
    $p = Get-Process -Id $PidToStop -ErrorAction SilentlyContinue
    if ($p) {
        Stop-Process -Id $PidToStop -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 250
        return $true
    }
    return $false
}

# 1) Stop the server recorded in cnc-server.pid (when valid).
if (Test-Path $serverPidFile) {
    $txt = (Get-Content $serverPidFile -Raw -ErrorAction SilentlyContinue).Trim()
    $sid = 0
    if ([int]::TryParse($txt,[ref]$sid)) { Stop-PidSafe $sid | Out-Null }
    Remove-Item $serverPidFile -Force -ErrorAction SilentlyContinue
}

# 2) IMPORTANT: also stop the REAL process listening on TCP 8787.
# This fixes stale/missing PID files and servers left behind by older versions.
$listenerPids = @()
try {
    $listenerPids = @(Get-NetTCPConnection -State Listen -LocalPort 8787 -ErrorAction Stop | Select-Object -ExpandProperty OwningProcess -Unique)
} catch {
    try {
        $lines = netstat -ano -p tcp | Select-String ':8787\s+.*LISTENING\s+(\d+)'
        foreach ($line in $lines) {
            if ($line.Matches.Count -gt 0) { $listenerPids += [int]$line.Matches[0].Groups[1].Value }
        }
        $listenerPids = @($listenerPids | Select-Object -Unique)
    } catch {}
}
foreach ($lp in $listenerPids) {
    if ($lp -le 0 -or $lp -eq $PID) { continue }
    $proc = Get-CimInstance Win32_Process -Filter ("ProcessId=$lp") -ErrorAction SilentlyContinue
    # Port 8787 is reserved for this app. Prefer matching Start-Server.ps1,
    # but if a stale PowerShell host owns 8787, stop it as well.
    if ($proc -and (([string]$proc.CommandLine -match 'Start-Server\.ps1') -or ([string]$proc.Name -match 'powershell|pwsh'))) {
        Stop-PidSafe $lp | Out-Null
    }
}

# 3) Stop cloudflared recorded in cloudflare.pid.
if (Test-Path $cloudPidFile) {
    $txt = (Get-Content $cloudPidFile -Raw -ErrorAction SilentlyContinue).Trim()
    $cid = 0
    if ([int]::TryParse($txt,[ref]$cid)) { Stop-PidSafe $cid | Out-Null }
    Remove-Item $cloudPidFile -Force -ErrorAction SilentlyContinue
}

# 4) Also stop this app's cloudflared if its PID file was stale/missing.
try {
    $cf = Get-CimInstance Win32_Process -Filter "Name='cloudflared.exe'" -ErrorAction SilentlyContinue
    foreach ($p in $cf) {
        $cmd = [string]$p.CommandLine
        if ($cmd -match 'cnc-mobile-5102-company' -or $cmd -match 'cloudflare-config\.yml' -or $cmd -match 'cnc\.phanken\.io\.vn') {
            Stop-PidSafe ([int]$p.ProcessId) | Out-Null
        }
    }
} catch {}

# 5) Cleanup and give Windows a moment to release the port.
Remove-Item $serverPidFile,$cloudPidFile -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 500
exit 0
