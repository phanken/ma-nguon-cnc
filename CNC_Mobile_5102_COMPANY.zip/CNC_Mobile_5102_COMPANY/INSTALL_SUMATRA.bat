@echo off
title CNC 5102 - Cai SumatraPDF
echo ==========================================
echo   CAI SUMATRAPDF - PRINT ENGINE CNC 5102
echo ==========================================
echo.
where winget >nul 2>nul
if %errorlevel%==0 (
  echo Dang cai SumatraPDF bang winget...
  winget install --id SumatraPDF.SumatraPDF -e --silent --accept-source-agreements --accept-package-agreements
  echo.
  echo Neu da cai xong, hay chay CHECK_PRINT_ENGINE.bat.
  pause
  exit /b
)
echo May khong co winget. Se mo trang tai chinh thuc SumatraPDF.
start "" "https://www.sumatrapdfreader.org/download-free-pdf-viewer"
echo Tai va cai SumatraPDF, sau do chay CHECK_PRINT_ENGINE.bat.
pause
