﻿param(
 [Parameter(Mandatory=$true)][string]$AppRoot,
 [Parameter(Mandatory=$true)][string]$WorkOrder,
 [int]$Copies=1,
 [Parameter(Mandatory=$true)][string]$LogPath
)
$ErrorActionPreference='Stop'
$SftHost='http://192.168.3.5:8100'; $SftRoot=$SftHost+'/SFT'
$SftCenterPage=$SftRoot+'/main/centerPage/centerPage.jsp?locale=vi_VN'
$SftUserAgent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
$SftRegistryPath='HKCU:\Software\TraCuuMaLieuTongHopNative\CNC5102'

function Log([string]$level,[string]$msg){
 try { Add-Content -LiteralPath $LogPath -Value ("[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [$level] BGPRINT31 $msg") -Encoding UTF8 } catch {}
}
function Load-SftSettings {
 $r=[pscustomobject]@{UserId='';Password='';CompanyId='EXWIN2026'}
 if(Test-Path $SftRegistryPath){
  $p=Get-ItemProperty $SftRegistryPath -ErrorAction Stop
  $r.UserId=[string]$p.SftUser
  if($p.SftCompany){$r.CompanyId=[string]$p.SftCompany}
  if($p.SftPassword){
   Add-Type -AssemblyName System.Security -ErrorAction SilentlyContinue
   $b=[Convert]::FromBase64String([string]$p.SftPassword)
   $c=[Security.Cryptography.ProtectedData]::Unprotect($b,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
   $r.Password=[Text.Encoding]::UTF8.GetString($c)
  }
 }
 return $r
}
function Req([string]$url,$cookies,[string]$referer){
 $q=[Net.HttpWebRequest]::Create($url);$q.CookieContainer=$cookies;$q.UserAgent=$SftUserAgent
 $q.Accept='*/*';$q.AllowAutoRedirect=$true;$q.Timeout=15000;$q.ReadWriteTimeout=15000;$q.KeepAlive=$true
 if($referer){$q.Referer=$referer}; return $q
}
function GetText($url,$cookies,$referer){
 $q=Req $url $cookies $referer;$q.Method='GET';$r=$q.GetResponse()
 try{$sr=New-Object IO.StreamReader($r.GetResponseStream(),[Text.Encoding]::UTF8,$true);try{$sr.ReadToEnd()}finally{$sr.Dispose()}}finally{$r.Dispose()}
}
function PostText($url,$body,$cookies,$referer){
 $d=[Text.Encoding]::UTF8.GetBytes([string]$body);$q=Req $url $cookies $referer;$q.Method='POST';$q.ContentType='text/plain';$q.ContentLength=$d.Length
 $o=$q.GetRequestStream();try{$o.Write($d,0,$d.Length)}finally{$o.Dispose()}
 $r=$q.GetResponse();try{$sr=New-Object IO.StreamReader($r.GetResponseStream(),[Text.Encoding]::UTF8,$true);try{$sr.ReadToEnd()}finally{$sr.Dispose()}}finally{$r.Dispose()}
}
function GetBytes($url,$cookies,$referer){
 $q=Req $url $cookies $referer;$q.Method='GET';$r=$q.GetResponse()
 try{$i=$r.GetResponseStream();try{$m=New-Object IO.MemoryStream;try{$i.CopyTo($m);$m.ToArray()}finally{$m.Dispose()}}finally{$i.Dispose()}}finally{$r.Dispose()}
}
function DwrBody($company,$wo,$sid,$script,$batch){
 $safe=$wo.Replace("'",'');$a=@(
 'callCount=1','page=/SFT/main/centerPage/centerPage.jsp?locale=vi_VN',"httpSessionId=$sid","scriptSessionId=$script",
 'c0-scriptName=RouteForm','c0-methodName=createForm','c0-id=0',"c0-param0=string:$company",'c0-param1=string:perpendi',
 'c0-e2=string:PLANPROCESSST','c0-e3=string:','c0-e1=Array:[reference:c0-e2,reference:c0-e3]',
 'c0-e5=string:PLANPROCESSST','c0-e6=string:','c0-e4=Array:[reference:c0-e5,reference:c0-e6]',
 'c0-e8=string:CMOID','c0-e9=string:','c0-e7=Array:[reference:c0-e8,reference:c0-e9]',
 'c0-e11=string:CMOID','c0-e12=string:','c0-e10=Array:[reference:c0-e11,reference:c0-e12]',
 'c0-e14=string:CMOID',"c0-e15=string:'$safe'",'c0-e13=Array:[reference:c0-e14,reference:c0-e15]',
 'c0-e17=string:moStatusStr','c0-e18=string:','c0-e16=Array:[reference:c0-e17,reference:c0-e18]',
 'c0-e20=string:EXECUTEQTY','c0-e21=string:','c0-e19=Array:[reference:c0-e20,reference:c0-e21]',
 'c0-e23=string:MO040','c0-e24=string:N','c0-e22=Array:[reference:c0-e23,reference:c0-e24]',
 'c0-param2=Array:[reference:c0-e1,reference:c0-e4,reference:c0-e7,reference:c0-e10,reference:c0-e13,reference:c0-e16,reference:c0-e19,reference:c0-e22]',
 'c0-param3=string:%7B%22isWithNetFlow%22%3A%22-1%22%2C%22withDataCollector%22%3Afalse%2C%22printtype%22%3A%22normal%22%2C%22language%22%3A%22vi_VN%22%2C%22PRINTUSERINFORM%22%3Atrue%2C%22checksplit_checkbox%22%3Afalse%2C%22PRINTSTAFFINFORM%22%3Afalse%7D',
 "batchId=$batch")
 [string]::Join("`n",$a)
}
function FindSumatra {
 $c=@((Join-Path $AppRoot 'tools\SumatraPDF.exe'),(Join-Path $env:LOCALAPPDATA 'SumatraPDF\SumatraPDF.exe'),(Join-Path $env:ProgramFiles 'SumatraPDF\SumatraPDF.exe'))
 if(${env:ProgramFiles(x86)}){$c+=(Join-Path ${env:ProgramFiles(x86)} 'SumatraPDF\SumatraPDF.exe')}
 foreach($x in $c){if($x -and (Test-Path $x)){return $x}}; return $null
}

try{
 Log INFO "WORKER START; wo=$WorkOrder; copies=$Copies"
 if($Copies -lt 1){$Copies=1};if($Copies -gt 10){$Copies=10}
 $st=Load-SftSettings
 if(!$st.UserId -or !$st.Password -or !$st.CompanyId){throw 'Chua co tai khoan SFT trong Registry FIXED92.'}
 Log INFO "SFT config user=$($st.UserId); company=$($st.CompanyId)"
 [Net.ServicePointManager]::Expect100Continue=$false;$cookies=New-Object Net.CookieContainer
 [void](GetText ($SftRoot+'/login.jsp?locale=vi_VN') $cookies $null)
 $login=$SftRoot+'/loginInside.jsp?loginTo=SFT&language=vi_VN&password='+[Uri]::EscapeDataString($st.Password)+'&userID='+[Uri]::EscapeDataString($st.UserId)+'&AUTH_ID='+[Uri]::EscapeDataString($st.UserId)+'&companyid='+[Uri]::EscapeDataString($st.CompanyId)
 [void](GetText $login $cookies ($SftRoot+'/login.jsp?locale=vi_VN'))
 $sid='';foreach($c in $cookies.GetCookies([Uri]($SftRoot+'/'))){if($c.Name -ieq 'JSESSIONID'){$sid=$c.Value;break}}
 if(!$sid){throw 'SFT khong tra JSESSIONID.'};Log INFO 'SFT LOGIN OK'
 try{$cookies.Add([Uri]($SftRoot+'/'),(New-Object Net.Cookie('company_select',$st.CompanyId,'/SFT')))}catch{}
 $batch=Get-Date -Format 'HHmmssfff';$script=([Guid]::NewGuid().ToString('N').ToUpperInvariant()+(Get-Random -Minimum 1000 -Maximum 9999))
 $resp=PostText ($SftRoot+'/dwr/call/plaincall/RouteForm.createForm.dwr') (DwrBody $st.CompanyId $WorkOrder.Trim() $sid $script $batch) $cookies $SftCenterPage
 $m=[regex]::Match([string]$resp,'["'']([^"'']*SFTC01[^"'']*\.pdf)["'']',[Text.RegularExpressions.RegexOptions]::IgnoreCase)
 if(!$m.Success){throw 'SFT khong tao duoc PDF.'}
 $name=$m.Groups[1].Value;Log INFO "PDF SFT=$name"
 $pdf=GetBytes ($SftRoot+'/report/'+[Uri]::EscapeDataString($name)) $cookies $SftCenterPage
 if($pdf.Length -lt 4 -or $pdf[0] -ne 0x25 -or $pdf[1] -ne 0x50){throw 'File tai ve khong phai PDF.'}
 $dir=Join-Path $AppRoot 'SFT_PDF';if(!(Test-Path $dir)){New-Item -ItemType Directory $dir -Force|Out-Null}
 $safe=[regex]::Replace($WorkOrder,'[^0-9A-Za-z_-]','_');$path=Join-Path $dir ("SFT_${safe}_"+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.pdf')
 [IO.File]::WriteAllBytes($path,$pdf);Log INFO "PDF LOCAL=$path"
 $sum=FindSumatra;if(!$sum){throw 'Khong tim thay SumatraPDF.'}
 Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
 $printer=(New-Object Drawing.Printing.PrinterSettings).PrinterName;if(!$printer){throw 'Khong co may in mac dinh.'}
 $settings='paperkind=11,duplexlong,fit,ignore-pdf-print-settings'
 Log INFO "PRINT printer=$printer; settings=$settings"
 for($i=1;$i -le $Copies;$i++){
   $a=@('-print-to',('"'+$printer+'"'),'-print-settings',('"'+$settings+'"'),'-silent',('"'+$path+'"'))
   $p=Start-Process $sum -ArgumentList $a -PassThru -WindowStyle Hidden -ErrorAction Stop
   if(!$p.WaitForExit(30000)){try{$p.Kill()}catch{};throw 'Sumatra timeout 30s.'}
   if($p.ExitCode -ne 0){throw "Sumatra ExitCode=$($p.ExitCode)"}
   Log INFO "PRINT COPY $i/$Copies OK"
 }
 # V2.36: sau khi Sumatra ket thuc, cho spooler nha file va thu xoa nhieu lan.
 # Neu in loi o phia tren thi se khong chay toi day, PDF van duoc giu lai.
 $deleted=$false
 for($delTry=1;$delTry -le 10;$delTry++){
   if(!(Test-Path -LiteralPath $path)){$deleted=$true;break}
   try{
     Start-Sleep -Milliseconds 700
     Remove-Item -LiteralPath $path -Force -ErrorAction Stop
     $deleted=$true
     Log INFO "PDF LOCAL DELETE OK try=$delTry path=$path"
     break
   }catch{
     Log WARN ("PDF DELETE RETRY $delTry/10: "+$_.Exception.Message)
     Start-Sleep -Milliseconds 800
   }
 }
 if(!$deleted -and (Test-Path -LiteralPath $path)){
   Log WARN "PDF DELETE FAILED AFTER 10 TRIES=$path"
 }
 Log INFO 'WORKER DONE'
 exit 0
}catch{
 Log ERROR ("WORKER ERROR: "+$_.Exception.Message)
 try{Log ERROR $_.ScriptStackTrace}catch{}
 exit 31
}
