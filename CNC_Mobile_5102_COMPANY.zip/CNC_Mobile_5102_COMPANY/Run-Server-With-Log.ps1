﻿$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Logs = Join-Path $Root 'LOGS'
$ServerScript = Join-Path $Root 'Start-Server.ps1'
$MainLog = Join-Path $Logs 'server.log'
$ErrorLog = Join-Path $Logs 'server-error.log'

if (!(Test-Path $Logs)) { New-Item -ItemType Directory -Path $Logs -Force | Out-Null }

function Write-Diag([string]$message, [string]$level='INFO') {
    try {
        $line = '[{0}] [{1}] {2}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'), $level, $message
        Add-Content -LiteralPath $MainLog -Value $line -Encoding UTF8
        if ($level -eq 'ERROR') { Add-Content -LiteralPath $ErrorLog -Value $line -Encoding UTF8 }
    } catch {}
}

Write-Diag ('SERVER LAUNCHER START PID={0} PowerShell={1} OS={2}' -f $PID,$PSVersionTable.PSVersion.ToString(),[Environment]::OSVersion.VersionString)
Write-Diag ('ROOT=' + $Root)
Write-Diag ('SCRIPT=' + $ServerScript)

try {
    if (!(Test-Path -LiteralPath $ServerScript)) { throw "Khong tim thay Start-Server.ps1: $ServerScript" }

    # Capture every PowerShell stream from the real server into server.log while
    # keeping the wrapper alive long enough to record startup/parser/runtime failures.
    & $ServerScript *>> $MainLog
    $code = $LASTEXITCODE
    Write-Diag ('Start-Server.ps1 da thoat. LASTEXITCODE=' + [string]$code) 'ERROR'
    exit 10
}
catch {
    $ex = $_
    $msg = New-Object System.Collections.Generic.List[string]
    $msg.Add('SERVER CRASH')
    $msg.Add('Message: ' + $ex.Exception.Message)
    if ($ex.FullyQualifiedErrorId) { $msg.Add('ErrorId: ' + $ex.FullyQualifiedErrorId) }
    if ($ex.CategoryInfo) { $msg.Add('Category: ' + [string]$ex.CategoryInfo) }
    if ($ex.InvocationInfo) {
        if ($ex.InvocationInfo.ScriptName) { $msg.Add('Script: ' + $ex.InvocationInfo.ScriptName) }
        if ($ex.InvocationInfo.ScriptLineNumber) { $msg.Add('Line: ' + [string]$ex.InvocationInfo.ScriptLineNumber) }
        if ($ex.InvocationInfo.OffsetInLine) { $msg.Add('Column: ' + [string]$ex.InvocationInfo.OffsetInLine) }
        if ($ex.InvocationInfo.Line) { $msg.Add('Code: ' + $ex.InvocationInfo.Line.Trim()) }
        if ($ex.InvocationInfo.PositionMessage) { $msg.Add('Position: ' + ($ex.InvocationInfo.PositionMessage -replace "`r?`n",' | ')) }
    }
    if ($ex.ScriptStackTrace) { $msg.Add('Stack: ' + ($ex.ScriptStackTrace -replace "`r?`n",' | ')) }
    try { $msg.Add('Exception: ' + $ex.Exception.ToString()) } catch {}
    foreach($m in $msg) { Write-Diag $m 'ERROR' }
    exit 11
}
finally {
    Write-Diag ('SERVER LAUNCHER END PID=' + $PID)
}
