@echo off
setlocal
cd /d "%~dp0"
set "TASKNAME=CNC Mobile 5102 Auto Start"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
set "SCRIPT=%~dp0AutoStart-Watchdog.ps1"

echo ==============================================
echo   CNC MOBILE 5102 - INSTALL AUTO START V2.93
echo ==============================================
echo.

rem Remove the older Registry startup entry to avoid duplicate launches.
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "CNC_Mobile_5102" /f >nul 2>&1

schtasks /Delete /TN "%TASKNAME%" /F >nul 2>&1
schtasks /Create /TN "%TASKNAME%" /SC ONLOGON /RL LIMITED /TR "\"%PS%\" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File \"%SCRIPT%\"" /F >nul 2>&1
if errorlevel 1 (
  echo [LOI] Khong tao duoc Scheduled Task.
  echo Hay bam chuot phai INSTALL_AUTO_START.bat ^> Run as administrator roi thu lai.
  pause
  exit /b 1
)

echo [OK] Da bat tu khoi dong cung Windows.
echo [OK] Sau khi dang nhap Windows, watchdog doi 20 giay roi tu bat Server + Cloudflare.
echo [OK] Watchdog se kiem tra lai moi 30 giay va tu khoi dong thanh phan bi tat.
echo.
echo Dang khoi dong watchdog ngay bay gio...
start "" /min "%PS%" -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%SCRIPT%"
echo.
echo XONG. Chi can chay file nay 1 lan tren may server.
pause
