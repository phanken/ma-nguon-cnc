Option Explicit
Dim sh, fso, folder, cmd
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
cmd = "cmd.exe /c """ & folder & "\START_ALL.bat"""
sh.Run cmd, 0, False
