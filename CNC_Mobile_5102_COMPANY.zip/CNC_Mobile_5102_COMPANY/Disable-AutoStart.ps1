﻿$ErrorActionPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path

# Stop only watchdog PowerShell processes that belong to this CNC package.
try {
    $items = Get-CimInstance -ClassName Win32_Process -Filter "Name='powershell.exe'" -ErrorAction SilentlyContinue
    foreach ($p in $items) {
        $cmd = [string]$p.CommandLine
        if ($cmd -and $cmd.IndexOf('AutoStart-Watchdog.ps1',[StringComparison]::OrdinalIgnoreCase) -ge 0) {
            if ([int]$p.ProcessId -ne $PID) {
                Stop-Process -Id ([int]$p.ProcessId) -Force -ErrorAction SilentlyContinue
            }
        }
    }
} catch {}

# Old manual-stop flag is no longer needed in manual-only mode.
Remove-Item (Join-Path $Root 'MANUAL_STOP.flag') -Force -ErrorAction SilentlyContinue
exit 0
