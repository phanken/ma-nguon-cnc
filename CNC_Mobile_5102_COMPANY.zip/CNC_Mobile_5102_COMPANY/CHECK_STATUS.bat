@echo off
cd /d "%~dp0"
title CNC Mobile 5102 - Status
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Check-Status.ps1"
echo.
pause
