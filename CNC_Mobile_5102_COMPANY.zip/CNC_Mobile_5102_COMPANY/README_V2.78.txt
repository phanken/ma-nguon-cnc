CNC MOBILE 5102 - V2.78 RECENT CONVERSION PICKER

Moi trong V2.78:
- Khu Chia don hien thi 5 so quy doi gan nhat cua dung ma lieu.
- Lay dung 5 dong quy doi gan nhat, KE CA GIA TRI TRUNG NHAU; khong distinct.
- Tat ca he so hien thi theo quy che lam tron len 1 chu so thap phan (vd 14.692 -> 14.7).
- Bam truc tiep vao mot trong 5 he so de dung ngay lam So quy doi cho phep tinh KG/PCS hien tai.
- He so dang chon duoc danh dau va dong So quy doi phia tren cap nhat ngay.
- Cache schema 3 de lan dau chay V2.78 tu dong build lai conversion cache, bao dam co du 5 gia tri.
- Giu nguyen V2.77 Save Gate va cac chuc nang on dinh truoc do.

Luu y:
- Lan dau chay V2.78 se can build cache lai mot lan do schema moi.
- Cac file PowerShell duoc luu UTF-8 BOM cho Windows PowerShell 5.1.
- Chay UNBLOCK_ALL.bat neu Windows chan file sau khi giai nen.
