@echo off
title CNC 5102 - Check Print Engine
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$c=@('%~dp0tools\SumatraPDF.exe', \"$env:LOCALAPPDATA\SumatraPDF\SumatraPDF.exe\", \"$env:ProgramFiles\SumatraPDF\SumatraPDF.exe\", \"${env:ProgramFiles(x86)}\SumatraPDF\SumatraPDF.exe\"); $f=$c|Where-Object{$_ -and (Test-Path $_)}|Select-Object -First 1; if($f){Write-Host 'SUMATRAPDF : OK' -ForegroundColor Green; Write-Host $f}else{Write-Host 'SUMATRAPDF : CHUA CAI' -ForegroundColor Red; Write-Host 'Hay chay INSTALL_SUMATRA.bat'}; Add-Type -AssemblyName System.Drawing; $p=(New-Object System.Drawing.Printing.PrinterSettings).PrinterName; Write-Host ('MAY IN     : '+$p)"
echo.
pause
