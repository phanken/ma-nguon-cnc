@echo off
setlocal
set "TASKNAME=CNC Mobile 5102 Auto Start"
schtasks /Delete /TN "%TASKNAME%" /F >nul 2>&1
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "CNC_Mobile_5102" /f >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process -Filter \"Name='powershell.exe'\" -ErrorAction SilentlyContinue ^| Where-Object { $_.CommandLine -like '*AutoStart-Watchdog.ps1*' } ^| ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }"
echo [OK] Da tat Auto Start CNC Mobile 5102.
pause
