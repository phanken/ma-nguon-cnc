@echo off
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "CNC_Mobile_5102" /f >nul 2>&1
exit /b 0
