Thu muc cache ben vung cua CNC Mobile V2.41.
Khong can xoa. cnc-data-cache.json se duoc tao/cap nhat tu dong sau khi server doc Excel.
