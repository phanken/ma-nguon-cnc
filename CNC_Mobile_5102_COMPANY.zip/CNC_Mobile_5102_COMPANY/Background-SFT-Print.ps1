﻿param(
    [Parameter(Mandatory=$true)][string]$ServerScript,
    [Parameter(Mandatory=$true)][string]$WorkOrder,
    [int]$Copies = 1,
    [string]$LogPath = ""
)

$ErrorActionPreference = 'Stop'

function BgLog([string]$level,[string]$msg) {
    $line = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] [$level] BGPRINT $msg"
    if ($LogPath) {
        try { Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8 } catch {}
    }
}

try {
    BgLog 'INFO' "V2.30 process nen da khoi dong; workOrder=$WorkOrder; copies=$Copies"
    $env:CNC_BACKGROUND_PRINT_ONLY = '1'
    . $ServerScript
    Remove-Item Env:CNC_BACKGROUND_PRINT_ONLY -ErrorAction SilentlyContinue
    BgLog 'INFO' 'Da nap cac ham SFT/Print tu Start-Server.ps1; KHONG khoi dong web server thu hai.'

    if ($Copies -lt 1) { $Copies = 1 }
    if ($Copies -gt 10) { $Copies = 10 }

    BgLog 'INFO' "Bat dau SFT nen; workOrder=$WorkOrder; copies=$Copies"
    $pdfPath = Create-SftPdf $WorkOrder
    BgLog 'INFO' ("Da co PDF: " + $pdfPath)

    $printInfo = Invoke-SftPdfPrint $pdfPath $Copies
    BgLog 'INFO' ("Da gui in; printer=" + $printInfo.printer + "; method=" + $printInfo.method)
    BgLog 'INFO' "Hoan thanh $WorkOrder"
    exit 0
}
catch {
    BgLog 'ERROR' ("Loi job $WorkOrder: " + $_.Exception.Message)
    try { BgLog 'ERROR' $_.ScriptStackTrace } catch {}
    exit 29
}
