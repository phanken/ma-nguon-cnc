CNC MOBILE 5102 - V2.77 SAVE GATE
=================================

Muc tieu cua V2.77:
- Chi reload cache khi NOI DUNG file XLSX that su thay doi (tuong ung mot lan Save/AutoSave ghi vao file).
- Neu Excel/ổ Z chi thay doi timestamp/length/metadata trong luc nguoi dung dang mo/nhap nhung byte file XLSX chua doi: KHONG reload.
- Sau khi fingerprint metadata dung yen 5 giay, server moi tinh SHA256 cua file XLSX de xac nhan co Save that hay khong.
- Neu SHA256 giong ban dang dung: cap nhat metadata fingerprint va bo qua reload.
- Neu SHA256 khac: coi la Save that, chay worker reload 1 lan.
- Worker tu kiem tra hash truoc va sau khi doc Excel. Neu file bi Save tiep trong luc dang build, cache dang build bi huy de tranh publish du lieu lai/khong dong nhat.

Ke thua V2.75:
- Fast Path neu cache dataHash khong doi, khong import lai hang nghin dong vao RAM.
- Excel Change History.
- Device Tracking / Server Center.
- CNC Assistant, SFT print va cac tinh nang truoc do.

LOG CAN QUAN SAT:
- V2.77 SAVE GATE: metadata changed but XLSX bytes are identical -> NO RELOAD.
  => Excel/ổ Z chi rung metadata, server khong reload.

- V2.77 SAVE GATE: XLSX bytes changed -> real SAVE detected, start reload.
  => File da duoc Save that, server bat dau reload.

LUU Y:
- Neu Excel dang bat AutoSave va AutoSave ghi noi dung vao XLSX, do duoc tinh la mot lan Save that va server se reload.
- Tat ca file .ps1 duoc luu UTF-8 BOM de tuong thich Windows PowerShell 5.1.
