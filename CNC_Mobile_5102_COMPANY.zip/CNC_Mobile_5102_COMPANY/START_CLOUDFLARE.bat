@echo off
cd /d "%~dp0"
if not exist "%~dp0tools\cloudflared.exe" exit /b 2
if not exist "%~dp0cloudflare-config.yml" exit /b 3
powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -Command "$p=Start-Process -FilePath '%~dp0tools\cloudflared.exe' -ArgumentList 'tunnel --config ""%~dp0cloudflare-config.yml"" run' -WindowStyle Hidden -PassThru; Set-Content -Path '%~dp0cloudflare.pid' -Value $p.Id -Encoding ASCII"
exit /b 0
