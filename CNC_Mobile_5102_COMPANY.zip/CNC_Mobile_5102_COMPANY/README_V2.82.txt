﻿CNC Mobile 5102 - V2.82 HISTORY STARTUP FIX

Sua loi V2.81 server crash luc khoi dong:
- Repair-ExcelChangeHistoryBaseline goi Write-CacheLog truoc khi ham nay duoc khai bao.
- V2.82 chuyen thu tu khoi tao: khai bao Write-CacheLog truoc, sau do moi Load/Repair history.
- Giu nguyen HISTORY BASELINE FIX cua V2.81 va toan bo tinh nang V2.80.
- Khong doi cache schema. Khong can build lai cache chi vi nang V2.82.
- Tat ca PowerShell script tiep tuc dung UTF-8 BOM de tuong thich Windows PowerShell 5.1.
