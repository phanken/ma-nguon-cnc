@echo off
setlocal
schtasks /Query /TN "CNC Mobile 5102 Auto Start" >nul 2>&1
if %errorlevel%==0 (
 echo CNC Mobile 5102: AUTO START V2.92 = BAT
 schtasks /Query /TN "CNC Mobile 5102 Auto Start" /FO LIST /V | findstr /I /C:"Status" /C:"Trang thai" /C:"Last Run Time" /C:"Lan chay cuoi"
) else (
 echo CNC Mobile 5102: AUTO START V2.92 = CHUA CAI
 echo Chay INSTALL_AUTO_START.bat mot lan.
)
pause
