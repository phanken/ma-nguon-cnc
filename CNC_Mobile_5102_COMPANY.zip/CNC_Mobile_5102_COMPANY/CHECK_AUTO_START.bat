@echo off
reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "CNC_Mobile_5102" >nul 2>&1
if %errorlevel%==0 (
 echo CNC Mobile 5102: TU KHOI DONG CUNG WINDOWS = BAT
) else (
 echo CNC Mobile 5102: TU KHOI DONG CUNG WINDOWS = TAT
)
pause
