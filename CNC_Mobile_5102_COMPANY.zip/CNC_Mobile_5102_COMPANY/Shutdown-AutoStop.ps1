$ErrorActionPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$stopScript = Join-Path $Root 'Stop-All-Hidden.ps1'
if (Test-Path $stopScript) {
    & powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $stopScript
}
exit 0
