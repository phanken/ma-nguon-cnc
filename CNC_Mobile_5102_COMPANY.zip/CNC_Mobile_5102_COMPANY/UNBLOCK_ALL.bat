@echo off
setlocal
cd /d "%~dp0"
echo Dang Unblock tat ca file trong thu muc...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath '%CD%' -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue"
echo.
echo Da Unblock xong.
pause
