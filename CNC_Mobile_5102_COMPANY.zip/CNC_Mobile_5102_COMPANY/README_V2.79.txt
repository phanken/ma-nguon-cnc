CNC Mobile 5102 - V2.79 RECENT 5 CONVERSION FIX

Nen tang: V2.77 SAVE GATE (giu nguyen co che cache/schema 2 on dinh).

Sua V2.79:
- Them 5 so quy doi gan nhat cua dung ma lieu trong muc Chia don.
- GIU CA GIA TRI TRUNG NHAU, khong distinct.
- Bam vao bat ky he so nao de chon lam he so quy doi dang dung.
- Lam tron 1 chu so theo gia tri Excel: vi du 14.705882 -> 14.7.
- So quy doi mac dinh lay lan gan nhat trong danh sach neu co.
- KHONG nang cache schema. Cache V2.77 nap ngay, khong con tinh trang tra don bao khong tim thay do doi schema.
- 5 he so duoc suy ra tu XLN cache hien co, khong can doc Excel truc tiep khi tra don.
- Giu nguyen SAVE GATE V2.77, Assistant, SFT, Device Tracking, lich su Excel.

Luu y PowerShell 5.1: cac file .ps1 duoc dong goi UTF-8 BOM.
