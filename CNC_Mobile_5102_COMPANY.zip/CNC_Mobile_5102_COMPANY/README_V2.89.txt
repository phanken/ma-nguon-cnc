CNC Mobile 5102 V2.89
- Baseline: V2.88.
- Nang cap /qd: them chieu PCS -> KG.
- Sau khi tinh KG/PCS, nhap "PCS can tinh" de tinh Tong KG = PCS x KG/PCS.
- Tong KG hien 3 chu so thap phan va co nut Copy Tong KG.
- Vi du KG/PCS = 0.01748, 850 PCS -> 14.858 KG.
- Giu nguyen cong cu gram/PCS + KG/PCS cua V2.88.
- Khong thay doi cache schema hay logic Excel/SFT/Assistant/Chia don.
