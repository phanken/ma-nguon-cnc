﻿$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Get-ChildItem -Path $Root -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
    try { Unblock-File -LiteralPath $_.FullName -ErrorAction SilentlyContinue } catch {}
}
Write-Host 'Da go chan tat ca file trong thu muc CNC Mobile 5102.' -ForegroundColor Green
