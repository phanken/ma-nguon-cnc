@echo off
cd /d "%~dp0"
if not exist "%~dp0cloudflare-config.yml" (
  start "" "%~dp0SETUP_CLOUDFLARE.bat"
  exit /b 0
)
if not exist "%~dp0tools\cloudflared.exe" (
  start "" "%~dp0SETUP_CLOUDFLARE.bat"
  exit /b 0
)
powershell -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0Start-All-Hidden.ps1"
exit /b 0
