CNC Mobile 5102 V2.90
- Baseline: V2.89.
- /qd tro thanh PWA offline rieng, scope /qd/.
- Lan dau mo /qd khi co mang se cache HTML/CSS/JS/manifest/icon tren iPhone.
- Sau khi da nap thanh cong, /qd van tinh Gram/PCS, KG/PCS va PCS -> KG khi mat mang/server CNC khong truy cap duoc.
- Ho tro Safari: Share -> Add to Home Screen, ten app "Quy Doi PCS", display standalone.
- Khong thay doi cache schema hay logic Excel/SFT/Assistant/Chia don.
