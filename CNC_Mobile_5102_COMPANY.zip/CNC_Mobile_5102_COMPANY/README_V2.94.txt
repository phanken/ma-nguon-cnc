CNC Mobile 5102 - V2.94 MANUAL START / STOP FIX

- Bo Auto Start/Watchdog cung Windows. Server chi khoi dong khi bam START_ALL.bat.
- STOP_ALL.bat duoc viet lai de tat sach Server port 8787 va Cloudflare.
- STOP_ALL tu dong xoa Scheduled Task/Registry Auto Start con sot lai tu V2.92/V2.93.
- Sua loi Get-CimInstance nhan ky tu ^ khi tat Auto Start.
- STOP chi bao [OK] sau khi kiem tra thuc te port 8787 / cloudflared da dung.
- Khong thay doi Excel cache, Chia don, SFT, Assistant, /qd hay cac chuc nang CNC hien tai.

Su dung:
1. START_ALL.bat: bat server + Cloudflare bang tay.
2. STOP_ALL.bat: tat server + Cloudflare va vo hieu hoa Auto Start cu.
3. Sau khi restart Windows, server se KHONG tu bat. Bam START_ALL.bat khi can.

AUTO STOP SHUTDOWN / RESTART:
- Chay INSTALL_AUTO_STOP_SHUTDOWN.bat MOT LAN bang quyen Administrator.
- Khi Windows Shutdown hoac Restart, he thong se tu goi Shutdown-AutoStop.ps1.
- Script dung CNC server port 8787 va Cloudflare bang Stop-All-Hidden.ps1, khong co PAUSE.
- Sau khi Windows khoi dong lai, server VAN KHONG tu START. Bam START_ALL.bat khi can.
