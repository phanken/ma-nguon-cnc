﻿$ErrorActionPreference = 'SilentlyContinue'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$StartScript = Join-Path $Root 'Start-All-Hidden.ps1'
$LogPath = Join-Path $Root 'AUTO_START.log'
$ManualStopFlag = Join-Path $Root 'MANUAL_STOP.flag'

function Write-AutoLog([string]$msg) {
    try { Add-Content -LiteralPath $LogPath -Value ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),$msg) -Encoding UTF8 } catch {}
}

function Get-BootToken {
    try { return [string](Get-CimInstance Win32_OperatingSystem -ErrorAction Stop).LastBootUpTime.ToUniversalTime().Ticks } catch { return '' }
}
function Test-ManualStop {
    if (!(Test-Path $ManualStopFlag)) { return $false }
    $saved = (Get-Content $ManualStopFlag -Raw -ErrorAction SilentlyContinue).Trim()
    $boot = Get-BootToken
    if ($saved -and $boot -and $saved -eq $boot) { return $true }
    # Flag belongs to an older Windows boot (or is invalid): clear it so auto-start works after reboot.
    Remove-Item $ManualStopFlag -Force -ErrorAction SilentlyContinue
    Write-AutoLog 'V2.93 cleared stale MANUAL_STOP flag after Windows reboot.'
    return $false
}

function Test-Port8787 {
    try {
        $c = New-Object Net.Sockets.TcpClient
        $ar = $c.BeginConnect('127.0.0.1',8787,$null,$null)
        $ok = $ar.AsyncWaitHandle.WaitOne(700,$false)
        if ($ok -and $c.Connected) { $c.EndConnect($ar); $c.Close(); return $true }
        $c.Close()
    } catch {}
    return $false
}
function Test-CloudflareAlive {
    $pidFile = Join-Path $Root 'cloudflare.pid'
    if (Test-Path $pidFile) {
        $n=0; $t=(Get-Content $pidFile -Raw -ErrorAction SilentlyContinue).Trim()
        if ([int]::TryParse($t,[ref]$n) -and (Get-Process -Id $n -ErrorAction SilentlyContinue)) { return $true }
    }
    return $null -ne (Get-Process -Name 'cloudflared' -ErrorAction SilentlyContinue | Select-Object -First 1)
}

Write-AutoLog 'V2.93 watchdog started. Manual STOP aware. Waiting for Windows/network...'
Start-Sleep -Seconds 20

while ($true) {
    if (Test-ManualStop) {
        # User intentionally pressed STOP_ALL. Do not recover until START_ALL or a new Windows boot.
        Start-Sleep -Seconds 30
        continue
    }
    $serverOk = Test-Port8787
    $cloudOk = Test-CloudflareAlive
    if (!$serverOk -or !$cloudOk) {
        Write-AutoLog ('Recovery requested. Server8787={0}; Cloudflare={1}' -f $serverOk,$cloudOk)
        try { & $StartScript | Out-Null } catch { Write-AutoLog ('Start error: '+$_.Exception.Message) }
        Start-Sleep -Seconds 8
    }
    Start-Sleep -Seconds 30
}
