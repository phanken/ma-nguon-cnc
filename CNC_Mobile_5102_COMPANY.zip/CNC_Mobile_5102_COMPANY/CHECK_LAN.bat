@echo off
setlocal
title CNC Mobile 5102 - Check LAN

echo ===== SERVER PORT 8787 =====
powershell -NoProfile -Command "$x=Get-NetTCPConnection -LocalPort 8787 -State Listen -ErrorAction SilentlyContinue; if($x){$x | Format-Table LocalAddress,LocalPort,State,OwningProcess -AutoSize}else{Write-Host 'SERVER CHUA LISTEN PORT 8787' -ForegroundColor Red}"
echo.
echo ===== DIA CHI LAN =====
powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | Sort-Object InterfaceMetric | ForEach-Object { Write-Host ('http://' + $_.IPAddress + ':8787   [' + $_.InterfaceAlias + ']') }"
echo.
echo ===== FIREWALL RULE =====
netsh advfirewall firewall show rule name="CNC Mobile 5102 Port 8787"
echo.
echo Neu LocalAddress hien 0.0.0.0 va Firewall Enabled=Yes thi LAN server da san sang.
pause
