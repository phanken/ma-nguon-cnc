(()=>{
 const $=id=>document.getElementById(id); let prefix='5102', pdfUrl='', pdfBlob=null, currentWo='';
 const wo=$('wo'), pin=$('pin'), status=$('status'), result=$('result'), find=$('find'), copies=$('copies');
 try{pin.value=localStorage.getItem('cncPin')||''}catch(e){}
 document.querySelectorAll('.factory-btn').forEach(b=>b.onclick=()=>{document.querySelectorAll('.factory-btn').forEach(x=>x.classList.remove('active'));b.classList.add('active');prefix=b.dataset.prefix;$('prefix').textContent=prefix+'-';wo.focus()});
 wo.addEventListener('input',()=>{let v=wo.value.replace(/\D/g,'');if(v.length>9)v=v.slice(-9);wo.value=v});
 wo.addEventListener('keydown',e=>{if(e.key==='Enter')find.click()}); pin.addEventListener('keydown',e=>{if(e.key==='Enter')find.click()});
 function setStatus(t,err=false,ok=false){status.textContent=t;status.className='status'+(err?' error':ok?' success':'')}
 function clearPdf(){if(pdfUrl){URL.revokeObjectURL(pdfUrl);pdfUrl=''} pdfBlob=null;currentWo='';result.classList.add('hidden')}
 function getCopies(){let n=parseInt(copies.value||'1',10);if(!Number.isFinite(n))n=1;n=Math.max(1,Math.min(10,n));copies.value=n;return n}
 $('minusCopy').onclick=()=>{copies.value=Math.max(1,getCopies()-1)};
 $('plusCopy').onclick=()=>{copies.value=Math.min(10,getCopies()+1)};
 copies.addEventListener('change',getCopies);

 // Nhận công đơn từ CNC Assistant: /in/?workOrder=5102-260814006
 // Tự chọn xưởng, điền 9 số và tự bấm TÌM sau khi trang sẵn sàng.
 function loadWorkOrderFromUrl(){
   try{
     const params=new URLSearchParams(window.location.search);
     const raw=(params.get('workOrder')||params.get('wo')||'').trim();
     const m=raw.match(/^(510[012])[-\s]?(\d{9})$/);
     if(!m)return;
     prefix=m[1];
     document.querySelectorAll('.factory-btn').forEach(x=>x.classList.toggle('active',x.dataset.prefix===prefix));
     $('prefix').textContent=prefix+'-';
     wo.value=m[2];
     // PIN đã được nạp từ localStorage ở đầu file; tự tìm luôn nếu có PIN.
     setTimeout(()=>{
       if(pin.value.trim()) find.click();
       else { setStatus('Đã nhận công đơn '+prefix+'-'+m[2]+'. Nhập PIN CNC để tự tìm.',false,false); pin.focus(); }
     },120);
   }catch(e){}
 }

 find.onclick=async()=>{
   clearPdf(); const digits=wo.value.replace(/\D/g,''); const p=pin.value.trim();
   if(digits.length!==9){setStatus('Nhập đủ 9 số công đơn.',true);wo.focus();return}
   if(!p){setStatus('Nhập PIN CNC.',true);pin.focus();return}
   const full=prefix+'-'+digits; find.disabled=true; find.textContent='ĐANG TÌM...'; setStatus('Đang kết nối SFT và tạo PDF...');
   try{
     localStorage.setItem('cncPin',p);
     const r=await fetch('/api/sft-pdf?workOrder='+encodeURIComponent(full),{headers:{'X-CNC-PIN':p},cache:'no-store'});
     if(!r.ok){let msg='Không tìm thấy / không tạo được PDF.';try{const j=await r.json();if(j.error)msg=j.error}catch(e){}throw new Error(msg)}
     const blob=await r.blob(); if(blob.type && !blob.type.includes('pdf'))throw new Error('Server không trả về PDF.');
     pdfBlob=blob; pdfUrl=URL.createObjectURL(blob); currentWo=full; $('fullWo').textContent=full; result.classList.remove('hidden'); setStatus('Công đơn đã sẵn sàng.',false,true);
   }catch(e){setStatus(e.message||'Có lỗi khi kết nối SFT.',true)}finally{find.disabled=false;find.textContent='TÌM CÔNG ĐƠN'}
 };

 $('printDirect').onclick=async()=>{
   if(!currentWo)return;
   const btn=$('printDirect'), p=pin.value.trim(), n=getCopies();
   btn.disabled=true;btn.textContent='ĐANG GỬI LỆNH IN...';setStatus('Đang gửi lệnh in tới máy in công ty...');
   try{
     const r=await fetch('/api/print-sft?workOrder='+encodeURIComponent(currentWo)+'&copies='+n,{headers:{'X-CNC-PIN':p},cache:'no-store'});
     let j={};try{j=await r.json()}catch(e){}
     if(!r.ok)throw new Error(j.error||'Không gửi được lệnh in.');
     setStatus('✓ Đã gửi lệnh in '+n+' bản. Có thể tiếp tục tìm công đơn khác.',false,true);
   }catch(e){setStatus(e.message||'Có lỗi khi gửi lệnh in.',true)}finally{btn.disabled=false;btn.textContent='IN TRỰC TIẾP'}
 };

 $('openPdf').onclick=()=>{if(pdfUrl)window.open(pdfUrl,'_blank')};
 $('sharePdf').onclick=async()=>{
   if(!pdfBlob||!currentWo)return;
   try{
     const f=new File([pdfBlob],'SFT_'+currentWo+'.pdf',{type:'application/pdf'});
     if(navigator.canShare&&navigator.canShare({files:[f]})&&navigator.share){await navigator.share({files:[f],title:'Công đơn '+currentWo});return}
   }catch(e){if(e&&e.name==='AbortError')return}
   if(pdfUrl)window.open(pdfUrl,'_blank');
 };
 $('newSearch').onclick=()=>{clearPdf();wo.value='';setStatus('');wo.focus()};
 loadWorkOrderFromUrl();
})();
