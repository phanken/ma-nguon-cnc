﻿const chat=document.querySelector('#chat'),q=document.querySelector('#q'),form=document.querySelector('#form'),modal=document.querySelector('#pinModal');
let pin=localStorage.getItem('cnc_pin')||'';
let aiCtx={};
try{aiCtx=JSON.parse(localStorage.getItem('cnc_ai_context_v2')||'{}')||{}}catch(e){aiCtx={}}

const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const fmt=n=>new Intl.NumberFormat('vi-VN',{maximumFractionDigits:2}).format(Number(n||0));

function saveCtx(ctx){
  if(!ctx||typeof ctx!=='object')return;
  aiCtx={
    material:String(ctx.material||'').trim(),
    customer:String(ctx.customer||'').trim(),
    intent:String(ctx.intent||'').trim(),
    workOrder:String(ctx.workOrder||'').trim()
  };
  try{localStorage.setItem('cnc_ai_context_v2',JSON.stringify(aiCtx))}catch(e){}
}
function clearCtx(){
  aiCtx={};
  try{localStorage.removeItem('cnc_ai_context_v2')}catch(e){}
}
function needPin(){modal.classList.remove('hidden');document.querySelector('#pin').value=pin;setTimeout(()=>document.querySelector('#pin').focus(),50)}
if(!pin)needPin();
document.querySelector('#savePin').onclick=()=>{pin=document.querySelector('#pin').value.trim();if(pin){localStorage.setItem('cnc_pin',pin);modal.classList.add('hidden');q.focus()}};

function add(html,cls='botmsg'){const d=document.createElement('div');d.className='bubble '+cls;d.innerHTML=html;chat.appendChild(d);scroll();return d}
function scroll(){setTimeout(()=>window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'}),30)}

function cards(rows){
  if(!rows?.length)return '';
  return `<div class="result">${rows.map(x=>{
    const simQty=Number(x.simulationQty||0),simRemain=Number(x.simulationRemaining||0),simSurplus=Number(x.simulationSurplus||0);
    const sim=simQty>0?`<div class="sim">🧪 Mô phỏng <b>${fmt(simQty)} PCS</b> → ${simSurplus>0?`dư <b>${fmt(simSurplus)} PCS</b>`:simRemain>0?`còn thiếu <b>${fmt(simRemain)} PCS</b>`:`<b>vừa đủ</b>`}<small>Không sửa dữ liệu thật</small></div>`:'';
    const alloc=Number(x.allocationQty)>0?`<div class="alloc">✅ Đề xuất chia <b>${fmt(x.allocationQty)} PCS</b>${Number(x.remainingAfter)>0?` · Còn thiếu ${fmt(x.remainingAfter)} PCS sau chia`:' · Đủ sau chia'}</div>`:'';
    return `<div class="card"><div class="top"><span class="wo">${esc(x.workOrder)}</span><span class="status ${esc(x.status)}">${esc(x.status)}</span></div><div class="mat">${esc(x.material||'')}</div>${sim}${alloc}<div class="grid"><span>Đơn hàng <b>${fmt(x.orderQty)}</b></span><span>${String(x.status||'').toUpperCase()==='FINISH'?'Đang dư':'Chưa OK'} <b>${fmt(Math.abs(Number(x.notOkQty)||0))}</b></span><span>Đã lĩnh <b>${fmt(x.issuedQty)}</b></span><span>Chuyển KH <b>${fmt(x.transferredQty)}</b></span><span>Thiếu liệu <b>${Number(x.issueDiff)<0?fmt(Math.abs(x.issueDiff)):'0'}</b></span><span>NG <b>${fmt(x.ngQty)}</b></span><span>Lịch xuất <b>${esc(x.shipDate||'-')}</b></span></div><div class="actions"><button class="action" onclick="location.href='/?workOrder=${encodeURIComponent(x.workOrder)}'">🔎 Tra đơn</button><button class="action" onclick="location.href='/in/?workOrder=${encodeURIComponent(x.workOrder)}'">🖨️ SFT</button><button class="action ghost" onclick="ask('Nếu chia 500 PCS cho ${esc(x.workOrder)} thì còn bao nhiêu?')">🧪 Mô phỏng</button></div></div>`
  }).join('')}</div>`
}
function footer(j){
  const c=j.context||{};
  const bits=[];
  if(c.customer)bits.push('KH '+esc(c.customer));
  if(c.material)bits.push('Mã '+esc(c.material));
  return `<div class="source">Excel: ${esc(j.sourceUpdated||'')}${bits.length?` · Ngữ cảnh: ${bits.join(' · ')}`:''}</div>`
}
function moreButton(j){if(j.nextOffset===null||j.nextOffset===undefined)return '';return `<button class="more" data-q="${esc(j.query)}" data-offset="${j.nextOffset}">Xem thêm (${fmt(j.totalCount-j.nextOffset)} còn lại)</button>`}

async function getAnswer(text,offset=0){
  const u=new URLSearchParams({q:text,offset:String(offset)});
  if(aiCtx.material)u.set('ctxMaterial',aiCtx.material);
  if(aiCtx.customer)u.set('ctxCustomer',aiCtx.customer);
  if(aiCtx.intent)u.set('ctxIntent',aiCtx.intent);
  if(aiCtx.workOrder)u.set('ctxWorkOrder',aiCtx.workOrder);
  const r=await fetch('/api/assistant?'+u.toString(),{headers:{'X-CNC-PIN':pin},cache:'no-store'});
  const j=await r.json();
  if(r.status===401){needPin();throw Error('PIN không đúng')}
  if(!r.ok)throw Error(j.error||'Không xử lý được câu hỏi');
  if(offset===0&&j.context)saveCtx(j.context);
  return j
}
function bindMore(scope){
  const b=scope.querySelector('.more');if(!b)return;
  b.onclick=async()=>{
    const text=b.dataset.q,offset=Number(b.dataset.offset||0);b.disabled=true;b.textContent='Đang tải...';
    try{const j=await getAnswer(text,offset);const holder=document.createElement('div');holder.innerHTML=cards(j.rows)+moreButton(j);b.replaceWith(holder);bindMore(holder);scroll()}
    catch(e){b.disabled=false;b.textContent='Xem thêm';add('<span class="error">❌ '+esc(e.message)+'</span>')}
  }
}
async function ask(text){
  text=(text||'').trim();if(!text)return;
  if(/^(x[oó]a|reset|bắt đầu lại|bat dau lai)\s*(ngữ cảnh|ngu canh)?$/i.test(text)){
    clearCtx();add(esc(text),'usermsg');q.value='';add('<b>🤖 CNC Assistant</b><br><div class="answer">Đã bắt đầu ngữ cảnh mới.</div>');return
  }
  if(!pin){needPin();return}
  add(esc(text),'usermsg');q.value='';
  const wait=add('🤖 <span class="typing">Đang kiểm tra dữ liệu...</span>');
  try{
    const j=await getAnswer(text,0);
    wait.innerHTML=`<b>🤖 CNC Assistant</b><br><div class="answer">${esc(j.answer)}</div>${cards(j.rows)}${moreButton(j)}${footer(j)}`;
    bindMore(wait)
  }catch(e){wait.innerHTML='<span class="error">❌ '+esc(e.message)+'</span>'}
  scroll()
}
form.onsubmit=e=>{e.preventDefault();ask(q.value)};
document.querySelectorAll('.chips button[data-q]').forEach(b=>b.onclick=()=>ask(b.dataset.q||b.textContent));
document.querySelector('#clearCtx')?.addEventListener('click',()=>{clearCtx();add('<b>🤖 CNC Assistant</b><br><div class="answer">Đã xóa ngữ cảnh hội thoại.</div>')});
window.ask=ask;
