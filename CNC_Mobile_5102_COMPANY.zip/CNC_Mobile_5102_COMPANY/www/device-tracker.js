(()=>{
  const page=location.pathname.startsWith('/ai')?'Assistant':location.pathname.startsWith('/in')?'SFT':location.pathname.startsWith('/admin')?'Admin':'CNC Mobile';
  let id=localStorage.getItem('cnc_device_id');if(!id){id=(crypto.randomUUID?crypto.randomUUID():Date.now().toString(36)+Math.random().toString(36).slice(2));localStorage.setItem('cnc_device_id',id)}
  function guess(){const ua=navigator.userAgent; if(/iPhone/i.test(ua))return 'iPhone';if(/iPad/i.test(ua))return 'iPad';if(/Android/i.test(ua))return 'Android';if(/Windows/i.test(ua))return 'Windows PC';if(/Macintosh/i.test(ua))return 'Mac';return 'Thiết bị';}
  let name=localStorage.getItem('cnc_device_name')||guess();localStorage.setItem('cnc_device_name',name);
  window.CNCDevice={id,get name(){return localStorage.getItem('cnc_device_name')||name},setName(v){v=String(v||'').trim();if(v){localStorage.setItem('cnc_device_name',v);name=v;ping()}}};
  async function ping(){const pin=localStorage.getItem('cnc_pin')||localStorage.getItem('cncPin')||'';if(!pin)return;try{await fetch('/api/device-ping?id='+encodeURIComponent(id)+'&name='+encodeURIComponent(window.CNCDevice.name)+'&page='+encodeURIComponent(page)+'&_='+Date.now(),{headers:{'X-CNC-PIN':pin},cache:'no-store'})}catch{}}
  window.CNCDevice.ping=ping;ping();setInterval(ping,20000);document.addEventListener('visibilitychange',()=>{if(!document.hidden)ping()});
})();
